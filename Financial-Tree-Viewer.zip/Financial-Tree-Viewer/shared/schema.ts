import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export * from "./models/auth";

// ── Plan4Life tables ────────────────────────────────────────────

export const clients = pgTable("clients", {
  id: varchar("id", { length: 32 }).primaryKey(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
  maritalStatus: text("marital_status").notNull(), // Single | Married | Divorced | Widowed
  lastReviewISO: text("last_review_iso").notNull(),
  // Profile
  initials: text("initials").notNull().default(""),
  idNumber: text("id_number").notNull().default(""),
  addressHome: text("address_home").notNull().default(""),
  addressPostal: text("address_postal").notNull().default(""),
  contactCell: text("contact_cell").notNull().default(""),
  contactEmail: text("contact_email").notNull().default(""),
  taxReference: text("tax_reference").notNull().default(""),
  taxOffice: text("tax_office").notNull().default(""),
  // Household
  annualSpend: integer("annual_spend").notNull().default(0),
  monthlySpend: integer("monthly_spend").notNull().default(0),
  existingMonthlyIncome: integer("existing_monthly_income").notNull().default(0),
  liquidAssets: integer("liquid_assets").notNull().default(0),
  // Risk cover
  lifeCover: integer("life_cover").notNull().default(0),
  disabilityIncomeMonthly: integer("disability_income_monthly").notNull().default(0),
  disabilityLumpSum: integer("disability_lump_sum").notNull().default(0),
  dreadDisease: integer("dread_disease").notNull().default(0),
  // Medical
  medicalPlanName: text("medical_plan_name").notNull().default(""),
  gapCover: boolean("gap_cover").notNull().default(false),
  // Estate
  willStatus: text("will_status").notNull().default("none"), // in_place | draft | none
  executorNamed: boolean("executor_named").notNull().default(false),
  beneficiaryAlignment: text("beneficiary_alignment").notNull().default("unknown"),
  liquidityAdequate: boolean("liquidity_adequate").notNull().default(false),
  // Documents
  ficaStatus: text("fica_status").notNull().default("missing"),
  ficaLastUpdatedISO: text("fica_last_updated_iso").notNull().default(""),
  // Tax
  raAnnualContribution: integer("ra_annual_contribution").notNull().default(0),
  raAnnualLimit: integer("ra_annual_limit").notNull().default(350000),
  tfsaContributionLifetime: integer("tfsa_contribution_lifetime").notNull().default(0),
  tfsaLifetimeLimit: integer("tfsa_lifetime_limit").notNull().default(500000),
});

export const insertClientSchema = createInsertSchema(clients).omit({ });
export type InsertClient = z.infer<typeof insertClientSchema>;
export type SelectClient = typeof clients.$inferSelect;

export const dependants = pgTable("dependants", {
  id: varchar("id", { length: 32 }).primaryKey(),
  clientId: varchar("client_id", { length: 32 }).notNull(),
  name: text("name").notNull(),
  age: integer("age").notNull(),
});

export const insertDependantSchema = createInsertSchema(dependants).omit({});
export type InsertDependant = z.infer<typeof insertDependantSchema>;
export type SelectDependant = typeof dependants.$inferSelect;

export const assets = pgTable("assets", {
  id: varchar("id", { length: 32 }).primaryKey(),
  clientId: varchar("client_id", { length: 32 }).notNull(),
  category: text("category").notNull(), // Business interests, Personal effects, etc
  description: text("description").notNull(),
  currency: text("currency").notNull().default("ZAR"),
  baseCost: integer("base_cost").notNull().default(0),
  marketValue: integer("market_value").notNull().default(0),
  ownerShare: integer("owner_share").notNull().default(100),
  included: boolean("included").notNull().default(true),
  assetClass: text("asset_class").notNull().default("Other"), // Equity, Balanced, etc
  provider: text("provider").notNull().default(""),
  accountType: text("account_type").notNull().default("Other"), // RA, TFSA, Unit Trust, etc
  accountName: text("account_name").notNull().default(""),
  beneficiary: text("beneficiary").notNull().default(""),
});

export const insertAssetSchema = createInsertSchema(assets).omit({});
export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type SelectAsset = typeof assets.$inferSelect;

export const liabilities = pgTable("liabilities", {
  id: varchar("id", { length: 32 }).primaryKey(),
  clientId: varchar("client_id", { length: 32 }).notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  currency: text("currency").notNull().default("ZAR"),
  amount: integer("amount").notNull().default(0),
  ownerShare: integer("owner_share").notNull().default(100),
  included: boolean("included").notNull().default(true),
  interestRate: real("interest_rate"),
});

export const insertLiabilitySchema = createInsertSchema(liabilities).omit({});
export type InsertLiability = z.infer<typeof insertLiabilitySchema>;
export type SelectLiability = typeof liabilities.$inferSelect;

export const meetingRequests = pgTable("meeting_requests", {
  id: varchar("id", { length: 64 }).primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id", { length: 32 }).notNull(),
  preferredDate: text("preferred_date").notNull().default(""),
  preferredTime: text("preferred_time").notNull().default(""),
  reason: text("reason").notNull().default(""),
  createdISO: text("created_iso").notNull().default(sql`now()::text`),
});

export const insertMeetingRequestSchema = createInsertSchema(meetingRequests).omit({ id: true, createdISO: true });
export type InsertMeetingRequest = z.infer<typeof insertMeetingRequestSchema>;
export type SelectMeetingRequest = typeof meetingRequests.$inferSelect;

export const riskQuestionnaires = pgTable("risk_questionnaires", {
  id: varchar("id", { length: 64 }).primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id", { length: 32 }).notNull(),
  answers: jsonb("answers").notNull(),
  capacityScore: integer("capacity_score").notNull().default(0),
  toleranceScore: integer("tolerance_score").notNull().default(0),
  goalsScore: integer("goals_score").notNull().default(0),
  totalScore: integer("total_score").notNull().default(0),
  profileLabel: text("profile_label").notNull().default(""),
  completedAt: text("completed_at").notNull().default(sql`now()::text`),
});

export const insertRiskQuestionnaireSchema = createInsertSchema(riskQuestionnaires).omit({ id: true, completedAt: true });
export type InsertRiskQuestionnaire = z.infer<typeof insertRiskQuestionnaireSchema>;
export type SelectRiskQuestionnaire = typeof riskQuestionnaires.$inferSelect;

export const publicRiskQuestionnaires = pgTable("public_risk_questionnaires", {
  id: varchar("id", { length: 64 }).primaryKey().default(sql`gen_random_uuid()`),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull().default(""),
  answers: jsonb("answers").notNull(),
  capacityScore: integer("capacity_score").notNull().default(0),
  toleranceScore: integer("tolerance_score").notNull().default(0),
  goalsScore: integer("goals_score").notNull().default(0),
  totalScore: integer("total_score").notNull().default(0),
  profileLabel: text("profile_label").notNull().default(""),
  completedAt: text("completed_at").notNull().default(sql`now()::text`),
});

export const insertPublicRiskQuestionnaireSchema = createInsertSchema(publicRiskQuestionnaires).omit({ id: true, completedAt: true });
export type InsertPublicRiskQuestionnaire = z.infer<typeof insertPublicRiskQuestionnaireSchema>;
export type SelectPublicRiskQuestionnaire = typeof publicRiskQuestionnaires.$inferSelect;
