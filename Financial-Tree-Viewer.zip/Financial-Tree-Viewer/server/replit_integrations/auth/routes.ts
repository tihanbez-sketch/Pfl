import type { Express } from "express";
import { authStorage } from "./storage";
import { isAuthenticated } from "./replitAuth";
import bcrypt from "bcryptjs";

export function registerAuthRoutes(app: Express): void {
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const user = await authStorage.getUser(userId);
      if (!user) return res.status(401).json({ message: "User not found" });
      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.get("/api/admin/users", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const currentUser = await authStorage.getUser(userId);
      if (currentUser?.role !== "advisor") {
        return res.status(403).json({ message: "Forbidden" });
      }
      const allUsers = await authStorage.getAllUsers();
      const safeUsers = allUsers.map(({ password: _, ...u }) => u);
      res.json(safeUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.patch("/api/admin/users/:id/role", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const currentUser = await authStorage.getUser(userId);
      if (currentUser?.role !== "advisor") {
        return res.status(403).json({ message: "Forbidden" });
      }
      const { role, linkedClientId } = req.body;
      if (role && !["advisor", "client"].includes(role)) {
        return res.status(400).json({ message: "Role must be 'advisor' or 'client'" });
      }
      const updated = await authStorage.updateUserRole(
        req.params.id,
        role || null,
        linkedClientId || null
      );
      if (!updated) {
        return res.status(404).json({ message: "User not found" });
      }
      const { password: _, ...safeUser } = updated;
      res.json(safeUser);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  app.post("/api/admin/users", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.session.userId;
      const currentUser = await authStorage.getUser(userId);
      if (currentUser?.role !== "advisor") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { username, password, firstName, lastName, email, role, linkedClientId } = req.body;

      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      if (username.length < 3) {
        return res.status(400).json({ message: "Username must be at least 3 characters" });
      }
      if (password.length < 6) {
        return res.status(400).json({ message: "Password must be at least 6 characters" });
      }

      const existing = await authStorage.getUserByUsername(username);
      if (existing) {
        return res.status(409).json({ message: "Username already exists" });
      }

      const hashed = await bcrypt.hash(password, 10);
      const user = await authStorage.createUser({
        username,
        password: hashed,
        firstName: firstName || null,
        lastName: lastName || null,
        email: email || null,
        role: role || null,
        linkedClientId: linkedClientId || null,
      });

      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });
}
