import { eq } from "drizzle-orm";
import { db } from "./db";
import { desc } from "drizzle-orm";
import {
  clients, dependants, assets, liabilities, meetingRequests, riskQuestionnaires, publicRiskQuestionnaires,
  type InsertClient, type SelectClient,
  type InsertDependant, type SelectDependant,
  type InsertAsset, type SelectAsset,
  type InsertLiability, type SelectLiability,
  type InsertMeetingRequest, type SelectMeetingRequest,
  type InsertRiskQuestionnaire, type SelectRiskQuestionnaire,
  type InsertPublicRiskQuestionnaire, type SelectPublicRiskQuestionnaire,
} from "@shared/schema";

export interface IStorage {
  getAllClients(): Promise<SelectClient[]>;
  getClient(id: string): Promise<SelectClient | undefined>;
  upsertClient(client: InsertClient): Promise<SelectClient>;
  updateClient(id: string, data: Partial<InsertClient>): Promise<SelectClient | undefined>;

  getDependants(clientId: string): Promise<SelectDependant[]>;
  upsertDependant(dep: InsertDependant): Promise<SelectDependant>;
  deleteDependant(id: string): Promise<void>;

  getAssets(clientId: string): Promise<SelectAsset[]>;
  upsertAsset(asset: InsertAsset): Promise<SelectAsset>;
  deleteAsset(id: string): Promise<void>;

  getLiabilities(clientId: string): Promise<SelectLiability[]>;
  upsertLiability(liability: InsertLiability): Promise<SelectLiability>;
  deleteLiability(id: string): Promise<void>;

  getMeetingRequests(clientId: string): Promise<SelectMeetingRequest[]>;
  createMeetingRequest(req: InsertMeetingRequest): Promise<SelectMeetingRequest>;

  getRiskQuestionnaire(clientId: string): Promise<SelectRiskQuestionnaire | undefined>;
  saveRiskQuestionnaire(data: InsertRiskQuestionnaire): Promise<SelectRiskQuestionnaire>;

  savePublicRiskQuestionnaire(data: InsertPublicRiskQuestionnaire): Promise<SelectPublicRiskQuestionnaire>;
}

export class DatabaseStorage implements IStorage {
  async getAllClients(): Promise<SelectClient[]> {
    return db.select().from(clients);
  }

  async getClient(id: string): Promise<SelectClient | undefined> {
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    return client;
  }

  async upsertClient(client: InsertClient): Promise<SelectClient> {
    const [result] = await db.insert(clients).values(client)
      .onConflictDoUpdate({ target: clients.id, set: client })
      .returning();
    return result;
  }

  async updateClient(id: string, data: Partial<InsertClient>): Promise<SelectClient | undefined> {
    const [result] = await db.update(clients).set(data).where(eq(clients.id, id)).returning();
    return result;
  }

  async getDependants(clientId: string): Promise<SelectDependant[]> {
    return db.select().from(dependants).where(eq(dependants.clientId, clientId));
  }

  async upsertDependant(dep: InsertDependant): Promise<SelectDependant> {
    const [result] = await db.insert(dependants).values(dep)
      .onConflictDoUpdate({ target: dependants.id, set: dep })
      .returning();
    return result;
  }

  async deleteDependant(id: string): Promise<void> {
    await db.delete(dependants).where(eq(dependants.id, id));
  }

  async getAssets(clientId: string): Promise<SelectAsset[]> {
    return db.select().from(assets).where(eq(assets.clientId, clientId));
  }

  async upsertAsset(asset: InsertAsset): Promise<SelectAsset> {
    const [result] = await db.insert(assets).values(asset)
      .onConflictDoUpdate({ target: assets.id, set: asset })
      .returning();
    return result;
  }

  async deleteAsset(id: string): Promise<void> {
    await db.delete(assets).where(eq(assets.id, id));
  }

  async getLiabilities(clientId: string): Promise<SelectLiability[]> {
    return db.select().from(liabilities).where(eq(liabilities.clientId, clientId));
  }

  async upsertLiability(liability: InsertLiability): Promise<SelectLiability> {
    const [result] = await db.insert(liabilities).values(liability)
      .onConflictDoUpdate({ target: liabilities.id, set: liability })
      .returning();
    return result;
  }

  async deleteLiability(id: string): Promise<void> {
    await db.delete(liabilities).where(eq(liabilities.id, id));
  }

  async getMeetingRequests(clientId: string): Promise<SelectMeetingRequest[]> {
    return db.select().from(meetingRequests).where(eq(meetingRequests.clientId, clientId));
  }

  async createMeetingRequest(req: InsertMeetingRequest): Promise<SelectMeetingRequest> {
    const [result] = await db.insert(meetingRequests).values(req).returning();
    return result;
  }

  async getRiskQuestionnaire(clientId: string): Promise<SelectRiskQuestionnaire | undefined> {
    const [result] = await db.select().from(riskQuestionnaires)
      .where(eq(riskQuestionnaires.clientId, clientId))
      .orderBy(desc(riskQuestionnaires.completedAt))
      .limit(1);
    return result;
  }

  async saveRiskQuestionnaire(data: InsertRiskQuestionnaire): Promise<SelectRiskQuestionnaire> {
    const [result] = await db.insert(riskQuestionnaires).values(data).returning();
    return result;
  }

  async savePublicRiskQuestionnaire(data: InsertPublicRiskQuestionnaire): Promise<SelectPublicRiskQuestionnaire> {
    const [result] = await db.insert(publicRiskQuestionnaires).values(data).returning();
    return result;
  }
}

export const storage = new DatabaseStorage();
