import type { Express, RequestHandler } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { db } from "./db";
import { clients, dependants as dependantsTable, assets as assetsTable, liabilities as liabilitiesTable, insertClientSchema, insertPublicRiskQuestionnaireSchema } from "@shared/schema";
import { z } from "zod";
import { isAuthenticated } from "./replit_integrations/auth";
import { authStorage } from "./replit_integrations/auth/storage";

async function getUserRole(req: any): Promise<{ role: string | null; linkedClientId: string | null }> {
  const userId = req.session?.userId;
  if (!userId) return { role: null, linkedClientId: null };
  const user = await authStorage.getUser(userId);
  return { role: user?.role ?? null, linkedClientId: user?.linkedClientId ?? null };
}

const isAdvisor: RequestHandler = async (req: any, res, next) => {
  const { role } = await getUserRole(req);
  if (role !== "advisor") return res.status(403).json({ message: "Forbidden" });
  next();
};

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ── Clients ────────────────────────────────────────────────
  app.get("/api/clients", isAuthenticated, async (req: any, res) => {
    try {
      const { role, linkedClientId } = await getUserRole(req);
      const allClients = await storage.getAllClients();

      if (role === "client" && linkedClientId) {
        const own = allClients.filter((c) => c.id === linkedClientId);
        const enriched = await Promise.all(own.map((c) => enrichClient(c)));
        return res.json(enriched);
      }

      const enriched = await Promise.all(
        allClients.map((c) => enrichClient(c))
      );
      res.json(enriched);
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.get("/api/clients/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { role, linkedClientId } = await getUserRole(req);
      if (role === "client" && linkedClientId && req.params.id !== linkedClientId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      const client = await storage.getClient(req.params.id as string);
      if (!client) return res.status(404).json({ message: "Client not found" });
      const enriched = await enrichClient(client);
      res.json(enriched);
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.post("/api/clients", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      const { client: clientData, dependants: deps, assets: assetList, liabilities: liabList } = req.body;
      if (!clientData || !clientData.name || !clientData.age) {
        return res.status(400).json({ message: "Client name and age are required" });
      }

      const uid = () => Math.random().toString(36).slice(2, 10);
      const id = clientData.id || `c-${uid()}`;

      const clientPayload = insertClientSchema.parse({
        ...clientData,
        id,
        lastReviewISO: clientData.lastReviewISO || new Date().toISOString(),
        ficaLastUpdatedISO: clientData.ficaLastUpdatedISO || "",
      });

      const saved = await db.transaction(async (tx) => {
        const [client] = await tx.insert(clients).values(clientPayload)
          .onConflictDoUpdate({ target: clients.id, set: clientPayload })
          .returning();

        if (deps && Array.isArray(deps)) {
          for (const d of deps) {
            await tx.insert(dependantsTable).values({
              id: `dep-${uid()}`,
              clientId: id,
              name: d.name,
              age: Number(d.age) || 0,
            });
          }
        }

        if (assetList && Array.isArray(assetList)) {
          for (const a of assetList) {
            await tx.insert(assetsTable).values({
              id: `ast-${uid()}`,
              clientId: id,
              category: a.category || "Other assets",
              description: a.description,
              currency: a.currency || "ZAR",
              baseCost: Number(a.baseCost) || 0,
              marketValue: Number(a.marketValue) || 0,
              ownerShare: Number(a.ownerShare) || 100,
              included: a.included !== false,
              assetClass: a.assetClass || "Other",
              provider: a.provider || "",
              accountType: a.accountType || "Other",
              accountName: a.accountName || "",
              beneficiary: a.beneficiary || "",
            });
          }
        }

        if (liabList && Array.isArray(liabList)) {
          for (const l of liabList) {
            await tx.insert(liabilitiesTable).values({
              id: `liab-${uid()}`,
              clientId: id,
              category: l.category || "Other",
              description: l.description,
              currency: l.currency || "ZAR",
              amount: Number(l.amount) || 0,
              ownerShare: Number(l.ownerShare) || 100,
              included: l.included !== false,
              interestRate: l.interestRate != null ? Number(l.interestRate) : null,
            });
          }
        }

        return client;
      });

      const enriched = await enrichClient(saved);
      res.status(201).json(enriched);
    } catch (e: any) {
      if (e.name === "ZodError") {
        return res.status(400).json({ message: "Invalid client data", errors: e.errors });
      }
      res.status(500).json({ message: e.message });
    }
  });

  app.patch("/api/clients/:id", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      const updated = await storage.updateClient(req.params.id as string, req.body);
      if (!updated) return res.status(404).json({ message: "Client not found" });
      const enriched = await enrichClient(updated);
      res.json(enriched);
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  // ── Dependants ─────────────────────────────────────────────
  app.get("/api/clients/:clientId/dependants", isAuthenticated, async (req: any, res) => {
    try {
      const { role, linkedClientId } = await getUserRole(req);
      if (role === "client" && linkedClientId && req.params.clientId !== linkedClientId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(await storage.getDependants(req.params.clientId as string));
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.put("/api/dependants/:id", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      const data = { ...req.body, id: req.params.id as string };
      res.json(await storage.upsertDependant(data));
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.delete("/api/dependants/:id", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      await storage.deleteDependant(req.params.id as string);
      res.json({ ok: true });
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  // ── Assets ─────────────────────────────────────────────────
  app.get("/api/clients/:clientId/assets", isAuthenticated, async (req: any, res) => {
    try {
      const { role, linkedClientId } = await getUserRole(req);
      if (role === "client" && linkedClientId && req.params.clientId !== linkedClientId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(await storage.getAssets(req.params.clientId as string));
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.put("/api/assets/:id", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      res.json(await storage.upsertAsset(req.body));
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.delete("/api/assets/:id", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      await storage.deleteAsset(req.params.id as string);
      res.json({ ok: true });
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  // ── Liabilities ────────────────────────────────────────────
  app.get("/api/clients/:clientId/liabilities", isAuthenticated, async (req: any, res) => {
    try {
      const { role, linkedClientId } = await getUserRole(req);
      if (role === "client" && linkedClientId && req.params.clientId !== linkedClientId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(await storage.getLiabilities(req.params.clientId as string));
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.put("/api/liabilities/:id", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      res.json(await storage.upsertLiability(req.body));
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.delete("/api/liabilities/:id", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      await storage.deleteLiability(req.params.id as string);
      res.json({ ok: true });
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  // ── Meeting requests ───────────────────────────────────────
  app.get("/api/clients/:clientId/meetings", isAuthenticated, async (req: any, res) => {
    try {
      const { role, linkedClientId } = await getUserRole(req);
      if (role === "client" && linkedClientId && req.params.clientId !== linkedClientId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.json(await storage.getMeetingRequests(req.params.clientId as string));
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.post("/api/meetings", isAuthenticated, async (req: any, res) => {
    try {
      const { role, linkedClientId } = await getUserRole(req);
      if (role === "client" && linkedClientId && req.body.clientId !== linkedClientId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      res.status(201).json(await storage.createMeetingRequest(req.body));
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  // ── Bulk assets/liabilities save ───────────────────────────
  app.put("/api/clients/:clientId/assets/bulk", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      const { assets: assetList } = req.body;
      const results = [];
      for (const a of assetList) {
        results.push(await storage.upsertAsset(a));
      }
      res.json(results);
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.put("/api/clients/:clientId/liabilities/bulk", isAuthenticated, isAdvisor, async (req, res) => {
    try {
      const { liabilities: liabList } = req.body;
      const results = [];
      for (const l of liabList) {
        results.push(await storage.upsertLiability(l));
      }
      res.json(results);
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.get("/api/clients/:clientId/risk-questionnaire", isAuthenticated, async (req: any, res) => {
    try {
      const { role, linkedClientId } = await getUserRole(req);
      if (role === "client" && linkedClientId !== req.params.clientId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      const result = await storage.getRiskQuestionnaire(req.params.clientId);
      res.json(result || null);
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  app.post("/api/clients/:clientId/risk-questionnaire", isAuthenticated, async (req: any, res) => {
    try {
      const { role, linkedClientId } = await getUserRole(req);
      if (role === "client" && linkedClientId !== req.params.clientId) {
        return res.status(403).json({ message: "Forbidden" });
      }
      const { answers, capacityScore, toleranceScore, goalsScore, totalScore, profileLabel } = req.body;
      const result = await storage.saveRiskQuestionnaire({
        clientId: req.params.clientId,
        answers,
        capacityScore,
        toleranceScore,
        goalsScore,
        totalScore,
        profileLabel,
      });
      res.status(201).json(result);
    } catch (e: any) {
      res.status(500).json({ message: e.message });
    }
  });

  // ── Public Risk Profile (no auth required) ──────────────
  app.post("/api/public/risk-profile", async (req, res) => {
    try {
      const validated = insertPublicRiskQuestionnaireSchema.parse(req.body);
      const result = await storage.savePublicRiskQuestionnaire(validated);
      res.status(201).json(result);
    } catch (e: any) {
      if (e.name === "ZodError") {
        return res.status(400).json({ message: "Invalid data", errors: e.errors });
      }
      res.status(500).json({ message: e.message });
    }
  });

  return httpServer;
}

async function enrichClient(c: any) {
  const [deps, assetList, liabList] = await Promise.all([
    storage.getDependants(c.id),
    storage.getAssets(c.id),
    storage.getLiabilities(c.id),
  ]);

  const investmentMap = new Map<string, any>();
  for (const a of assetList) {
    const key = `${a.provider}|${a.accountType}|${a.accountName}`;
    if (!investmentMap.has(key)) {
      investmentMap.set(key, {
        id: `inv-${a.provider}-${a.accountType}`.toLowerCase().replace(/\s/g, ""),
        name: a.accountName || `${a.provider} ${a.accountType}`,
        provider: a.provider,
        type: a.accountType,
        holdings: [],
      });
    }
    investmentMap.get(key)!.holdings.push({
      id: a.id,
      name: a.description,
      assetClass: a.assetClass,
      value: a.marketValue,
      beneficiary: a.beneficiary || "",
    });
  }

  return {
    id: c.id,
    name: c.name,
    profile: {
      initials: c.initials,
      idNumber: c.idNumber,
      address: { home: c.addressHome, postal: c.addressPostal },
      contact: { cell: c.contactCell, email: c.contactEmail },
      tax: { reference: c.taxReference, office: c.taxOffice },
    },
    age: c.age,
    maritalStatus: c.maritalStatus,
    household: {
      annualSpend: c.annualSpend,
      monthlySpend: c.monthlySpend,
      existingMonthlyIncome: c.existingMonthlyIncome,
      liquidAssets: c.liquidAssets,
    },
    dependants: deps.map((d: any) => ({ id: d.id, name: d.name, age: d.age })),
    investments: Array.from(investmentMap.values()),
    liabilities: liabList.map((l: any) => ({
      id: l.id,
      name: l.description,
      balance: l.amount,
      interestRate: l.interestRate,
    })),
    riskCover: {
      life: c.lifeCover,
      disabilityIncomeMonthly: c.disabilityIncomeMonthly,
      disabilityLumpSum: c.disabilityLumpSum,
      dreadDisease: c.dreadDisease,
    },
    medicalAid: { planName: c.medicalPlanName, gapCover: c.gapCover },
    estate: {
      willStatus: c.willStatus,
      executorNamed: c.executorNamed,
      beneficiaryAlignment: c.beneficiaryAlignment,
      liquidityAdequate: c.liquidityAdequate,
    },
    documents: { ficaStatus: c.ficaStatus, lastUpdatedISO: c.ficaLastUpdatedISO },
    tax: {
      raAnnualContribution: c.raAnnualContribution,
      raAnnualLimit: c.raAnnualLimit,
      tfsaContributionLifetime: c.tfsaContributionLifetime,
      tfsaLifetimeLimit: c.tfsaLifetimeLimit,
    },
    lastReviewISO: c.lastReviewISO,
  };
}
