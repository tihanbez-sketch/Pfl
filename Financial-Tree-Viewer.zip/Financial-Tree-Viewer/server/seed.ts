import { db } from "./db";
import { clients, dependants, assets, liabilities } from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  const existingClients = await db.select().from(clients);
  if (existingClients.length > 0) {
    console.log("Database already seeded, skipping.");
    process.exit(0);
  }

  // ── Tihan Bezuidenhout (FNA data) ──────────────────────────
  await db.insert(clients).values({
    id: "c-004",
    name: "Tihan Benjamin Bezuidenhout",
    age: 37,
    maritalStatus: "Single",
    lastReviewISO: "2026-02-07",
    initials: "TB",
    idNumber: "8902015173080",
    addressHome: "172 Venice Road, Morningside, Durban, 7001, South Africa",
    addressPostal: "172 Venice Road, Morningside, Durban, 7001, South Africa",
    contactCell: "+27 82 857 0776",
    contactEmail: "tihan@pfl.co.za",
    taxReference: "2916132166",
    taxOffice: "Durban",
    annualSpend: 180000,
    monthlySpend: 15000,
    existingMonthlyIncome: 55000,
    liquidAssets: 126000,
    lifeCover: 1810000,
    disabilityIncomeMonthly: 0,
    disabilityLumpSum: 0,
    dreadDisease: 0,
    medicalPlanName: "Discovery Health",
    gapCover: false,
    willStatus: "in_place",
    executorNamed: true,
    beneficiaryAlignment: "aligned",
    liquidityAdequate: true,
    ficaStatus: "complete",
    ficaLastUpdatedISO: "2026-02-07",
    raAnnualContribution: 0,
    raAnnualLimit: 350000,
    tfsaContributionLifetime: 11506,
    tfsaLifetimeLimit: 500000,
  });

  await db.insert(assets).values([
    { id: "a-t01", clientId: "c-004", category: "Retirement funds", description: "Fund 1 (Living Annuity)", currency: "ZAR", baseCost: 0, marketValue: 1050233, ownerShare: 100, included: true, assetClass: "Balanced", provider: "Ninety One", accountType: "RA", accountName: "Ninety One RA" },
    { id: "a-t02", clientId: "c-004", category: "Retirement funds", description: "Fund 2 (Living Annuity)", currency: "ZAR", baseCost: 0, marketValue: 212596, ownerShare: 100, included: true, assetClass: "Balanced", provider: "Ninety One", accountType: "RA", accountName: "Ninety One RA" },
    { id: "a-t03", clientId: "c-004", category: "Investments", description: "TFSA 1", currency: "ZAR", baseCost: 0, marketValue: 134, ownerShare: 100, included: true, assetClass: "Equity", provider: "Ninety One", accountType: "TFSA", accountName: "Ninety One TFSA" },
    { id: "a-t04", clientId: "c-004", category: "Investments", description: "TFSA 2", currency: "ZAR", baseCost: 0, marketValue: 11372, ownerShare: 100, included: true, assetClass: "Equity", provider: "Ninety One", accountType: "TFSA", accountName: "Ninety One TFSA" },
    { id: "a-t05", clientId: "c-004", category: "Business interests", description: "Megafin", currency: "ZAR", baseCost: 0, marketValue: 1000000, ownerShare: 100, included: true, assetClass: "Property", provider: "Private", accountType: "Other", accountName: "Other Assets (PFL/Megafin)" },
    { id: "a-t06", clientId: "c-004", category: "Business interests", description: "PFL", currency: "ZAR", baseCost: 0, marketValue: 1200000, ownerShare: 100, included: true, assetClass: "Equity", provider: "Private", accountType: "Other", accountName: "Other Assets (PFL/Megafin)" },
  ]);

  await db.insert(liabilities).values([
    { id: "l-t01", clientId: "c-004", category: "Vehicle finance", description: "Car Finance", currency: "ZAR", amount: 150000, ownerShare: 100, included: true, interestRate: 0.12 },
    { id: "l-t02", clientId: "c-004", category: "Short-term debt", description: "Credit Cards", currency: "ZAR", amount: 150000, ownerShare: 100, included: true, interestRate: 0.18 },
  ]);

  // ── Thabo Mokoena ──────────────────────────────────────────
  await db.insert(clients).values({
    id: "c-001",
    name: "Thabo Mokoena",
    age: 41,
    maritalStatus: "Married",
    lastReviewISO: "2024-11-02",
    initials: "TM",
    idNumber: "8405235899081",
    addressHome: "42 Sandton Drive, Johannesburg",
    addressPostal: "PO Box 123, Sandton",
    contactCell: "082 555 1234",
    contactEmail: "thabo.m@example.com",
    taxReference: "1234567890",
    taxOffice: "SARS Sandton",
    annualSpend: 540000,
    monthlySpend: 45000,
    existingMonthlyIncome: 18000,
    liquidAssets: 220000,
    lifeCover: 2500000,
    disabilityIncomeMonthly: 20000,
    disabilityLumpSum: 750000,
    dreadDisease: 300000,
    medicalPlanName: "Discovery Classic Comprehensive",
    gapCover: true,
    willStatus: "draft",
    executorNamed: false,
    beneficiaryAlignment: "partial",
    liquidityAdequate: false,
    ficaStatus: "partial",
    ficaLastUpdatedISO: "2025-07-14",
    raAnnualContribution: 96000,
    raAnnualLimit: 350000,
    tfsaContributionLifetime: 240000,
    tfsaLifetimeLimit: 500000,
  });

  await db.insert(dependants).values([
    { id: "d-001", clientId: "c-001", name: "Lerato", age: 12 },
    { id: "d-002", clientId: "c-001", name: "Neo", age: 7 },
  ]);

  await db.insert(assets).values([
    { id: "a-001", clientId: "c-001", category: "Retirement funds", description: "Balanced Fund", currency: "ZAR", baseCost: 0, marketValue: 1250000, ownerShare: 100, included: true, assetClass: "Balanced", provider: "Allan Gray", accountType: "RA", accountName: "Retirement Annuity" },
    { id: "a-002", clientId: "c-001", category: "Retirement funds", description: "Equity Fund", currency: "ZAR", baseCost: 0, marketValue: 640000, ownerShare: 100, included: true, assetClass: "Equity", provider: "Allan Gray", accountType: "RA", accountName: "Retirement Annuity" },
    { id: "a-003", clientId: "c-001", category: "Investments", description: "SA Equity ETF", currency: "ZAR", baseCost: 0, marketValue: 210000, ownerShare: 100, included: true, assetClass: "Equity", provider: "EasyEquities", accountType: "TFSA", accountName: "Tax Free Savings" },
    { id: "a-004", clientId: "c-001", category: "Investments", description: "Cash", currency: "ZAR", baseCost: 0, marketValue: 35000, ownerShare: 100, included: true, assetClass: "Cash", provider: "EasyEquities", accountType: "TFSA", accountName: "Tax Free Savings" },
  ]);

  await db.insert(liabilities).values([
    { id: "l-001", clientId: "c-001", category: "Home loan", description: "Home Loan", currency: "ZAR", amount: 1450000, ownerShare: 100, included: true, interestRate: 0.115 },
    { id: "l-002", clientId: "c-001", category: "Vehicle finance", description: "Vehicle Finance", currency: "ZAR", amount: 210000, ownerShare: 100, included: true, interestRate: 0.135 },
  ]);

  // ── Ayesha Patel ───────────────────────────────────────────
  await db.insert(clients).values({
    id: "c-002",
    name: "Ayesha Patel",
    age: 35,
    maritalStatus: "Single",
    lastReviewISO: "2025-08-21",
    initials: "AP",
    idNumber: "9009120055088",
    addressHome: "15 Marine Parade, Durban",
    addressPostal: "PO Box 44, Durban",
    contactCell: "083 444 9876",
    contactEmail: "ayesha.p@example.com",
    taxReference: "9876543210",
    taxOffice: "SARS Durban",
    annualSpend: 360000,
    monthlySpend: 30000,
    existingMonthlyIncome: 12000,
    liquidAssets: 480000,
    lifeCover: 1800000,
    disabilityIncomeMonthly: 15000,
    disabilityLumpSum: 500000,
    dreadDisease: 500000,
    medicalPlanName: "Bonitas BonComprehensive",
    gapCover: false,
    willStatus: "in_place",
    executorNamed: true,
    beneficiaryAlignment: "aligned",
    liquidityAdequate: true,
    ficaStatus: "complete",
    ficaLastUpdatedISO: "2025-10-01",
    raAnnualContribution: 42000,
    raAnnualLimit: 350000,
    tfsaContributionLifetime: 320000,
    tfsaLifetimeLimit: 500000,
  });

  await db.insert(dependants).values([
    { id: "d-003", clientId: "c-002", name: "Zara", age: 4 },
  ]);

  await db.insert(assets).values([
    { id: "a-005", clientId: "c-002", category: "Investments", description: "Balanced Plus", currency: "ZAR", baseCost: 0, marketValue: 520000, ownerShare: 100, included: true, assetClass: "Balanced", provider: "Coronation", accountType: "Unit Trust", accountName: "Unit Trust" },
    { id: "a-006", clientId: "c-002", category: "Investments", description: "Bond Fund", currency: "ZAR", baseCost: 0, marketValue: 140000, ownerShare: 100, included: true, assetClass: "Bond", provider: "Coronation", accountType: "Unit Trust", accountName: "Unit Trust" },
  ]);

  await db.insert(liabilities).values([
    { id: "l-003", clientId: "c-002", category: "Home loan", description: "Home Loan", currency: "ZAR", amount: 980000, ownerShare: 100, included: true, interestRate: 0.112 },
  ]);

  // ── Johan van der Merwe ────────────────────────────────────
  await db.insert(clients).values({
    id: "c-003",
    name: "Johan van der Merwe",
    age: 58,
    maritalStatus: "Married",
    lastReviewISO: "2024-02-15",
    initials: "JJ",
    idNumber: "6701015099087",
    addressHome: "88 Church Street, Pretoria",
    addressPostal: "PO Box 99, Pretoria",
    contactCell: "082 111 2233",
    contactEmail: "johan.vdm@example.com",
    taxReference: "5555555555",
    taxOffice: "SARS Pretoria",
    annualSpend: 720000,
    monthlySpend: 60000,
    existingMonthlyIncome: 28000,
    liquidAssets: 900000,
    lifeCover: 1200000,
    disabilityIncomeMonthly: 10000,
    disabilityLumpSum: 250000,
    dreadDisease: 200000,
    medicalPlanName: "Momentum Ingwe",
    gapCover: true,
    willStatus: "none",
    executorNamed: false,
    beneficiaryAlignment: "unknown",
    liquidityAdequate: false,
    ficaStatus: "missing",
    ficaLastUpdatedISO: "2024-01-08",
    raAnnualContribution: 0,
    raAnnualLimit: 350000,
    tfsaContributionLifetime: 480000,
    tfsaLifetimeLimit: 500000,
  });

  await db.insert(assets).values([
    { id: "a-007", clientId: "c-003", category: "Retirement funds", description: "Balanced Fund", currency: "ZAR", baseCost: 0, marketValue: 2100000, ownerShare: 100, included: true, assetClass: "Balanced", provider: "Sanlam", accountType: "Retirement Annuity", accountName: "Retirement Annuity" },
    { id: "a-008", clientId: "c-003", category: "Retirement funds", description: "Property Fund", currency: "ZAR", baseCost: 0, marketValue: 410000, ownerShare: 100, included: true, assetClass: "Property", provider: "Sanlam", accountType: "Retirement Annuity", accountName: "Retirement Annuity" },
    { id: "a-009", clientId: "c-003", category: "Investments", description: "Global Equity", currency: "ZAR", baseCost: 0, marketValue: 980000, ownerShare: 100, included: true, assetClass: "Equity", provider: "Ninety One", accountType: "Other", accountName: "Investment Account" },
    { id: "a-010", clientId: "c-003", category: "Investments", description: "Cash", currency: "ZAR", baseCost: 0, marketValue: 120000, ownerShare: 100, included: true, assetClass: "Cash", provider: "Ninety One", accountType: "Other", accountName: "Investment Account" },
  ]);

  await db.insert(liabilities).values([
    { id: "l-004", clientId: "c-003", category: "Vehicle finance", description: "Vehicle Finance", currency: "ZAR", amount: 140000, ownerShare: 100, included: true, interestRate: 0.138 },
  ]);

  console.log("Seeded 4 clients with assets, liabilities, and dependants.");
  process.exit(0);
}

seed().catch((e) => {
  console.error("Seed failed:", e);
  process.exit(1);
});
