# Plan4Life

## Overview
Financial advisory dashboard for Plan4Life Financial Advisors ("Planning Your Path"). Two modes: Advisor (full dashboard) and Client (simplified read-only). Features comprehensive financial planning modules, tree visualization of module health, and South African Rand formatting. Polished for client-facing presentation.

## Recent Changes
- **2026-02-09**: Public risk profile page — Standalone page at /risk-profile (no login required) where prospects enter personal details, complete 12-question questionnaire, and see printable results with indicative asset allocation. Results saved to public_risk_questionnaires table. Link from login page. Print/PDF support via browser print dialog.
- **2026-02-07**: Role-based access control — Users table has role (advisor/client) and linkedClientId columns. Advisors see full dashboard + user management page. Clients see only their linked record (read-only). Users without a role see "Access Pending" page. All API endpoints enforce role scoping. User management at /admin/users for advisors.
- **2026-02-07**: Brand alignment — Updated entire colour palette to match PFL client-facing website. Olive/sage green primary buttons, warm gold accent text, cream backgrounds, dark forest green dark theme. All hardcoded emerald/sky/teal colors replaced with brand CSS variables. Login page restyled with PFL brand. TopNav + meta tags updated to "PFL" branding. Tree visualization colors now use brand palette.
- **2026-02-08**: Risk profile questionnaire — 12 questions across 3 sections (Financial Safety Net, Gut Feeling About Risk, Goals & Life Circumstances). Clients complete from dashboard, results saved to DB with section scores and profile label (Cautious → Adventurous). Advisors see read-only result or "not yet completed" message. Retake supported.
- **2026-02-08**: Authentication switched from Replit Auth to username/password login with bcrypt hashing. Advisors can create user accounts from the User Management page (/admin/users). Default admin account: username "admin", password "admin123". Sessions stored in PostgreSQL.
- **2026-02-07**: Security hardening — All API routes protected with isAuthenticated middleware. Session management via PostgreSQL. Security headers (X-Content-Type-Options, X-Frame-Options, XSS protection, Referrer-Policy, Permissions-Policy). Frontend auth-aware routing with redirect to login for unauthenticated users. User avatar + logout in TopNav.
- **2026-02-07**: Added "Add Client" admin form at /clients/add — comprehensive multi-section data entry for admin staff. POST /api/clients endpoint uses Zod validation + database transaction. "Add Client" button on ClientList page.
- **2026-02-07**: Complete UX polish pass — removed all developer/MVP/demo language from entire application. All components now client-ready. Client mode shows welcome greeting, hides advisor-only features (life stage panel, scenario planner, portfolio upload, documents tab, assumptions controls). Meeting request and onboarding panels show success confirmation states. EstateDetail now calculates values dynamically from client data. Navigation flow improved per mode.
- **2026-02-07**: Backend transition complete. PostgreSQL database with Drizzle ORM. All client data (profiles, assets, liabilities, dependants, meeting requests) persisted. Frontend updated to fetch from API via TanStack Query hooks.

## Architecture

### Stack
- **Frontend**: React + Vite + TailwindCSS + shadcn/ui + wouter routing + TanStack Query
- **Backend**: Express.js + Drizzle ORM + PostgreSQL (Neon-backed)
- **Auth**: Username/password with bcrypt, express-session, PostgreSQL session store
- **Fonts**: Fraunces (serif display) + Inter (UI)

### Database Tables
- `clients` - Main client record with flattened profile/financial fields
- `dependants` - Client dependants (name, age)
- `assets` - Investment holdings with category, provider, account grouping
- `liabilities` - Debts with category, interest rate
- `meeting_requests` - Client meeting requests
- `risk_questionnaires` - Risk profile questionnaire responses with section scores and profile label
- `users` - Auth users with role (advisor/client) and linkedClientId
- `public_risk_questionnaires` - Public (no-auth) risk profile submissions with personal details and scores

### API Endpoints
- `GET /api/clients` - List all clients (enriched with nested relations)
- `GET /api/clients/:id` - Single client (enriched)
- `POST /api/clients` - Create new client with dependants/assets/liabilities (transactional, Zod-validated)
- `PATCH /api/clients/:id` - Update client fields
- `PUT /api/clients/:clientId/assets/bulk` - Bulk save assets
- `PUT /api/clients/:clientId/liabilities/bulk` - Bulk save liabilities
- `POST /api/meetings` - Create meeting request
- `POST /api/public/risk-profile` - Public (no auth) save risk profile questionnaire result
- CRUD for individual assets, liabilities, dependants

### Key Files
- `shared/schema.ts` - Drizzle schema + Zod types
- `server/db.ts` - Database connection
- `server/storage.ts` - Storage interface (DatabaseStorage)
- `server/routes.ts` - API routes with `enrichClient()` for nested response shape
- `server/seed.ts` - Demo data seeder (4 SA clients)
- `client/src/lib/plan4life/api.ts` - TanStack Query hooks
- `client/src/lib/plan4life/types.ts` - Frontend Client type (nested shape)
- `client/src/lib/plan4life/demoData.ts` - Default assumptions config
- `client/src/lib/plan4life/compute.ts` - Heuristic calculations

### Data Flow
API returns enriched Client objects (nested profile/investments/liabilities) matching the frontend `Client` type. The `enrichClient()` function in routes.ts transforms flat DB rows + related records into this nested shape.

## User Preferences
- SA Rand formatting throughout
- Organic tree visualization with canopy glow and roots
- Fraunces + Inter font combination
- CRM integration placeholders for Elite Wealth
- Heuristic calculations (not actuarial)

## Demo Data
4 seeded clients: Tihan Bezuidenhout (FNA data), Thabo Mokoena, Ayesha Patel, Johan van der Merwe. Run `npx tsx server/seed.ts` to re-seed (skips if data exists).
