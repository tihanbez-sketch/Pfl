import type { EstateReadiness } from "@/lib/plan4life/types";

function colorFor(status: EstateReadiness) {
  if (status === "green") return "hsl(var(--chart-1))";
  if (status === "amber") return "hsl(var(--chart-2))";
  return "hsl(var(--chart-3))";
}

function bgFor(status: EstateReadiness) {
  if (status === "green") return "hsl(var(--chart-1) / 0.15)";
  if (status === "amber") return "hsl(var(--chart-2) / 0.15)";
  return "hsl(var(--chart-3) / 0.15)";
}

function leafCluster(
  cx: number,
  cy: number,
  color: string,
  id: string,
  scale = 1,
) {
  const r1 = 18 * scale;
  const r2 = 14 * scale;
  const r3 = 12 * scale;
  return (
    <g key={id}>
      <circle cx={cx} cy={cy} r={r1 + 8} fill={color} opacity="0.08" filter="url(#leafGlow)" />
      <circle cx={cx - r2 * 0.6} cy={cy - r2 * 0.3} r={r1} fill={color} opacity="0.55">
        <animate attributeName="r" values={`${r1};${r1 + 1.5};${r1}`} dur="4s" repeatCount="indefinite" begin={`${Math.random() * 2}s`} />
      </circle>
      <circle cx={cx + r2 * 0.5} cy={cy - r2 * 0.5} r={r2} fill={color} opacity="0.5">
        <animate attributeName="r" values={`${r2};${r2 + 1};${r2}`} dur="5s" repeatCount="indefinite" begin={`${Math.random() * 3}s`} />
      </circle>
      <circle cx={cx} cy={cy + r3 * 0.3} r={r3} fill={color} opacity="0.45">
        <animate attributeName="r" values={`${r3};${r3 + 1};${r3}`} dur="3.5s" repeatCount="indefinite" begin={`${Math.random() * 2}s`} />
      </circle>
      <circle cx={cx - r3 * 0.2} cy={cy - r3 * 0.1} r={r3 * 0.5} fill={color} opacity="0.7" />
    </g>
  );
}

export function TreeViz({
  branches,
}: {
  branches: {
    investments: EstateReadiness;
    risk: EstateReadiness;
    estate: EstateReadiness;
    tax: EstateReadiness;
    budgeting: EstateReadiness;
  };
}) {
  const branchData = [
    { key: "investments", label: "Investments", status: branches.investments },
    { key: "risk", label: "Risk", status: branches.risk },
    { key: "estate", label: "Estate", status: branches.estate },
    { key: "tax", label: "Tax", status: branches.tax },
    { key: "budgeting", label: "Budgeting", status: branches.budgeting },
  ] as const;

  return (
    <div
      className="relative overflow-hidden rounded-2xl border bg-card shadow-lg p4l-noise"
      data-testid="card-tree"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-sky-50/30 via-transparent to-amber-50/20 dark:from-primary/5 dark:to-transparent" />
      <div className="relative p-5">
        <div className="mb-2 flex items-center justify-between">
          <div>
            <div className="font-display text-base font-semibold tracking-tight" data-testid="text-tree-title">
              Financial Health Tree
            </div>
            <div className="text-xs text-muted-foreground" data-testid="text-tree-subtitle">
              Your planning overview at a glance
            </div>
          </div>
          <div className="flex items-center gap-3 text-[11px]" data-testid="text-tree-legend">
            <span className="flex items-center gap-1">
              <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: "hsl(var(--chart-1))" }} />
              Healthy
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: "hsl(var(--chart-2))" }} />
              Attention
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: "hsl(var(--chart-3))" }} />
              Action needed
            </span>
          </div>
        </div>

        <svg
          viewBox="0 0 900 420"
          className="h-[340px] w-full"
          role="img"
          aria-label="Plan tree visualization"
          data-testid="svg-tree"
        >
          <defs>
            <linearGradient id="trunkGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="hsl(28 35% 48%)" />
              <stop offset="0.5" stopColor="hsl(25 32% 36%)" />
              <stop offset="1" stopColor="hsl(22 30% 24%)" />
            </linearGradient>
            <linearGradient id="rootGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor="hsl(22 30% 24% / 0.6)" />
              <stop offset="1" stopColor="hsl(22 30% 24% / 0.15)" />
            </linearGradient>
            <filter id="soft" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" />
            </filter>
            <filter id="leafGlow" x="-40%" y="-40%" width="180%" height="180%">
              <feGaussianBlur stdDeviation="12" />
            </filter>
            <filter id="trunkTexture" x="0" y="0" width="100%" height="100%">
              <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="3" seed="2" />
              <feDisplacementMap in="SourceGraphic" scale="3" />
            </filter>
            <radialGradient id="groundGlow" cx="50%" cy="0%" r="60%">
              <stop offset="0" stopColor="hsl(var(--primary) / 0.06)" />
              <stop offset="1" stopColor="transparent" />
            </radialGradient>
          </defs>

          <ellipse cx="450" cy="390" rx="320" ry="20" fill="url(#groundGlow)" />

          <g opacity="0.85">
            <circle cx="360" cy="130" r="90" fill="hsl(var(--primary) / 0.06)" filter="url(#leafGlow)" />
            <circle cx="450" cy="100" r="110" fill="hsl(var(--primary) / 0.08)" filter="url(#leafGlow)" />
            <circle cx="540" cy="130" r="85" fill="hsl(var(--chart-4) / 0.06)" filter="url(#leafGlow)" />
            <circle cx="450" cy="160" r="75" fill="hsl(var(--primary) / 0.05)" filter="url(#leafGlow)" />
          </g>

          <g opacity="0.5">
            <path
              d="M450 380 C 425 385 390 390 360 398"
              stroke="url(#rootGrad)"
              strokeWidth="7"
              strokeLinecap="round"
              fill="none"
            />
            <path
              d="M450 380 C 430 388 410 396 385 408"
              stroke="url(#rootGrad)"
              strokeWidth="5"
              strokeLinecap="round"
              fill="none"
            />
            <path
              d="M450 380 C 475 385 510 390 540 398"
              stroke="url(#rootGrad)"
              strokeWidth="7"
              strokeLinecap="round"
              fill="none"
            />
            <path
              d="M450 380 C 470 388 490 396 515 408"
              stroke="url(#rootGrad)"
              strokeWidth="5"
              strokeLinecap="round"
              fill="none"
            />
            <path
              d="M450 382 C 448 392 446 402 445 415"
              stroke="url(#rootGrad)"
              strokeWidth="4"
              strokeLinecap="round"
              fill="none"
            />
          </g>

          <g>
            <path
              d="M450 378 C 446 340 454 310 448 278 C 443 248 425 228 412 208"
              stroke="url(#trunkGrad)"
              strokeWidth="22"
              strokeLinecap="round"
              fill="none"
            />
            <path
              d="M450 378 C 454 340 448 310 452 278 C 457 248 475 228 488 208"
              stroke="url(#trunkGrad)"
              strokeWidth="20"
              strokeLinecap="round"
              fill="none"
              opacity="0.9"
            />
            <path
              d="M449 320 C 442 315 438 308 433 302"
              stroke="hsl(25 32% 36% / 0.3)"
              strokeWidth="4"
              strokeLinecap="round"
              fill="none"
            />
            <path
              d="M451 295 C 458 290 462 283 467 276"
              stroke="hsl(25 32% 36% / 0.25)"
              strokeWidth="3"
              strokeLinecap="round"
              fill="none"
            />
          </g>

          <g>
            <path
              d="M430 230 C 370 198 310 168 235 142"
              stroke={colorFor(branches.investments)}
              strokeWidth="11"
              strokeLinecap="round"
              fill="none"
              opacity="0.9"
            />
            {leafCluster(220, 130, colorFor(branches.investments), "inv", 1.3)}
            <g transform="translate(172,105)">
              <rect x="0" y="0" width="88" height="26" rx="13" fill="hsl(var(--background) / 0.85)" stroke={colorFor(branches.investments)} strokeWidth="1.5" />
              <text x="44" y="17" fontSize="12" fontWeight="600" fill={colorFor(branches.investments)} textAnchor="middle">
                Investments
              </text>
            </g>
          </g>

          <g>
            <path
              d="M425 228 C 360 228 300 228 240 228"
              stroke={colorFor(branches.estate)}
              strokeWidth="9"
              strokeLinecap="round"
              fill="none"
              opacity="0.85"
            />
            {leafCluster(228, 228, colorFor(branches.estate), "estate", 1.1)}
            <g transform="translate(186,243)">
              <rect x="0" y="0" width="62" height="26" rx="13" fill="hsl(var(--background) / 0.85)" stroke={colorFor(branches.estate)} strokeWidth="1.5" />
              <text x="31" y="17" fontSize="12" fontWeight="600" fill={colorFor(branches.estate)} textAnchor="middle">
                Estate
              </text>
            </g>
          </g>

          <g>
            <path
              d="M470 230 C 530 198 590 168 665 142"
              stroke={colorFor(branches.risk)}
              strokeWidth="11"
              strokeLinecap="round"
              fill="none"
              opacity="0.9"
            />
            {leafCluster(680, 130, colorFor(branches.risk), "risk", 1.3)}
            <g transform="translate(650,105)">
              <rect x="0" y="0" width="52" height="26" rx="13" fill="hsl(var(--background) / 0.85)" stroke={colorFor(branches.risk)} strokeWidth="1.5" />
              <text x="26" y="17" fontSize="12" fontWeight="600" fill={colorFor(branches.risk)} textAnchor="middle">
                Risk
              </text>
            </g>
          </g>

          <g>
            <path
              d="M475 228 C 540 228 600 228 660 228"
              stroke={colorFor(branches.tax)}
              strokeWidth="9"
              strokeLinecap="round"
              fill="none"
              opacity="0.85"
            />
            {leafCluster(672, 228, colorFor(branches.tax), "tax", 1.1)}
            <g transform="translate(650,243)">
              <rect x="0" y="0" width="46" height="26" rx="13" fill="hsl(var(--background) / 0.85)" stroke={colorFor(branches.tax)} strokeWidth="1.5" />
              <text x="23" y="17" fontSize="12" fontWeight="600" fill={colorFor(branches.tax)} textAnchor="middle">
                Tax
              </text>
            </g>
          </g>

          <g>
            <path
              d="M450 260 C 450 232 451 210 450 185"
              stroke={colorFor(branches.budgeting)}
              strokeWidth="10"
              strokeLinecap="round"
              fill="none"
              opacity="0.9"
            />
            {leafCluster(450, 168, colorFor(branches.budgeting), "budget", 1.2)}
            <g transform="translate(414,132)">
              <rect x="0" y="0" width="74" height="26" rx="13" fill="hsl(var(--background) / 0.85)" stroke={colorFor(branches.budgeting)} strokeWidth="1.5" />
              <text x="37" y="17" fontSize="12" fontWeight="600" fill={colorFor(branches.budgeting)} textAnchor="middle">
                Budgeting
              </text>
            </g>
          </g>
        </svg>

        <div className="mt-1 grid grid-cols-2 gap-2 text-xs md:grid-cols-5">
          {branchData.map(({ key, label, status }) => (
            <div
              key={key}
              className="flex items-center justify-between rounded-xl border px-3 py-2.5 transition-colors"
              style={{ background: bgFor(status) }}
              data-testid={`row-tree-${key}`}
            >
              <span className="font-medium text-foreground/80" data-testid={`text-tree-label-${key}`}>{label}</span>
              <span
                className="inline-flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold text-white"
                style={{ background: colorFor(status) }}
                data-testid={`status-tree-${key}`}
              >
                {status === "green" ? "✓" : status === "amber" ? "!" : "✕"}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
