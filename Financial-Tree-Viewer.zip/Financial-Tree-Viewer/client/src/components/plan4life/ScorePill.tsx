import type { EstateReadiness } from "@/lib/plan4life/types";

export function ScorePill({
  label,
  value,
  tone,
  testId,
}: {
  label: string;
  value: string;
  tone: EstateReadiness;
  testId: string;
}) {
  const fg =
    tone === "green"
      ? "hsl(var(--chart-1))"
      : tone === "amber"
        ? "hsl(var(--chart-2))"
        : "hsl(var(--chart-3))";
  const bg =
    tone === "green"
      ? "hsl(var(--chart-1) / 0.10)"
      : tone === "amber"
        ? "hsl(var(--chart-2) / 0.12)"
        : "hsl(var(--chart-3) / 0.12)";

  return (
    <div className="rounded-2xl border bg-card p-4 shadow-sm p4l-noise" data-testid={testId}>
      <div className="text-xs text-muted-foreground" data-testid={`${testId}-label`}>{label}</div>
      <div className="mt-2 flex items-end justify-between">
        <div className="font-serif text-2xl font-semibold tracking-tight" data-testid={`${testId}-value`}>
          {value}
        </div>
        <div
          className="rounded-full px-2 py-1 text-[11px] font-medium"
          style={{ background: bg, color: fg }}
          data-testid={`${testId}-tone`}
        >
          {tone.toUpperCase()}
        </div>
      </div>
    </div>
  );
}
