import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Save } from "lucide-react";
import type { Client } from "@/lib/plan4life/types";
import { useUpdateClient } from "@/lib/plan4life/api";
import { estateReadinessScore } from "@/lib/plan4life/compute";

export function EstateEditor({ client }: { client: Client }) {
  const [willStatus, setWillStatus] = React.useState(client.estate.willStatus);
  const [executorNamed, setExecutorNamed] = React.useState(client.estate.executorNamed);
  const [beneficiaryAlignment, setBeneficiaryAlignment] = React.useState(client.estate.beneficiaryAlignment);
  const [liquidityAdequate, setLiquidityAdequate] = React.useState(client.estate.liquidityAdequate);
  const [dirty, setDirty] = React.useState(false);

  const updateClient = useUpdateClient();

  React.useEffect(() => {
    setWillStatus(client.estate.willStatus);
    setExecutorNamed(client.estate.executorNamed);
    setBeneficiaryAlignment(client.estate.beneficiaryAlignment);
    setLiquidityAdequate(client.estate.liquidityAdequate);
    setDirty(false);
  }, [client.estate]);

  const handleSave = () => {
    updateClient.mutate({
      id: client.id,
      data: {
        willStatus,
        executorNamed,
        beneficiaryAlignment,
        liquidityAdequate,
      },
    });
    setDirty(false);
  };

  const score = estateReadinessScore({
    ...client,
    estate: { willStatus, executorNamed, beneficiaryAlignment, liquidityAdequate },
  });

  const scoreTone =
    score >= 75 ? "text-primary bg-primary/10" :
    score >= 45 ? "text-amber-700 bg-amber-500/10" :
    "text-red-700 bg-red-500/10";

  return (
    <Card className="rounded-2xl p-4 shadow-sm" data-testid="card-estate-editor">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm font-medium" data-testid="text-estate-editor-title">Estate Planning</div>
          <div className="mt-1 text-xs text-muted-foreground" data-testid="text-estate-editor-subtitle">
            Update client estate readiness flags
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className={`rounded-full px-3 py-1 text-xs font-semibold ${scoreTone}`} data-testid="badge-estate-score">
            {score}/100
          </div>
          {dirty && (
            <Button size="sm" onClick={handleSave} disabled={updateClient.isPending} data-testid="button-estate-save">
              <Save className="mr-1 h-3.5 w-3.5" />
              Save
            </Button>
          )}
        </div>
      </div>

      <div className="mt-4 grid gap-3" data-testid="form-estate-editor">
        <div className="rounded-xl border bg-background/60 p-3" data-testid="field-will-status">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Will status</div>
              <div className="text-xs text-muted-foreground">Is the client's will signed and current?</div>
            </div>
            <Select
              value={willStatus}
              onValueChange={(v: any) => { setWillStatus(v); setDirty(true); }}
            >
              <SelectTrigger className="w-[140px] h-8" data-testid="select-will-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="in_place">In place</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="none">None</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="rounded-xl border bg-background/60 p-3" data-testid="field-executor">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Executor named</div>
              <div className="text-xs text-muted-foreground">Has an executor been appointed?</div>
            </div>
            <Switch
              checked={executorNamed}
              onCheckedChange={(v) => { setExecutorNamed(v); setDirty(true); }}
              data-testid="switch-executor"
            />
          </div>
        </div>

        <div className="rounded-xl border bg-background/60 p-3" data-testid="field-beneficiary-alignment">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Beneficiary alignment</div>
              <div className="text-xs text-muted-foreground">Are beneficiaries consistent across policies?</div>
            </div>
            <Select
              value={beneficiaryAlignment}
              onValueChange={(v: any) => { setBeneficiaryAlignment(v); setDirty(true); }}
            >
              <SelectTrigger className="w-[140px] h-8" data-testid="select-beneficiary-alignment">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="aligned">Aligned</SelectItem>
                <SelectItem value="partial">Partial</SelectItem>
                <SelectItem value="unknown">Unknown</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="rounded-xl border bg-background/60 p-3" data-testid="field-liquidity">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Estate liquidity adequate</div>
              <div className="text-xs text-muted-foreground">Are there enough liquid assets for estate costs?</div>
            </div>
            <Switch
              checked={liquidityAdequate}
              onCheckedChange={(v) => { setLiquidityAdequate(v); setDirty(true); }}
              data-testid="switch-liquidity"
            />
          </div>
        </div>
      </div>
    </Card>
  );
}
