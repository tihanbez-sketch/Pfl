import React from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Save } from "lucide-react";
import type { Client } from "@/lib/plan4life/types";
import { useUpsertDependant, useDeleteDependant } from "@/lib/plan4life/api";

type DependantRow = {
  id: string;
  name: string;
  age: number;
  isNew?: boolean;
};

export function DependantsPanel({ client }: { client: Client }) {
  const [rows, setRows] = React.useState<DependantRow[]>(
    client.dependants.map((d) => ({ ...d }))
  );
  const [dirty, setDirty] = React.useState(false);

  const upsertDep = useUpsertDependant();
  const deleteDep = useDeleteDependant();

  React.useEffect(() => {
    setRows(client.dependants.map((d) => ({ ...d })));
    setDirty(false);
  }, [client.dependants]);

  const addRow = () => {
    const id = `dep-${Date.now()}`;
    setRows((prev) => [...prev, { id, name: "", age: 0, isNew: true }]);
    setDirty(true);
  };

  const updateRow = (id: string, field: keyof DependantRow, value: any) => {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, [field]: value } : r)));
    setDirty(true);
  };

  const removeRow = (id: string) => {
    const row = rows.find((r) => r.id === id);
    if (row && !row.isNew) {
      deleteDep.mutate({ id, clientId: client.id });
    }
    setRows((prev) => prev.filter((r) => r.id !== id));
    setDirty(true);
  };

  const handleSave = () => {
    const valid = rows.filter((r) => r.name.trim());
    valid.forEach((r) => {
      upsertDep.mutate({
        id: r.id,
        clientId: client.id,
        name: r.name.trim(),
        age: r.age,
      });
    });
    setDirty(false);
  };

  return (
    <Card className="rounded-2xl p-4 shadow-sm p4l-noise" data-testid="card-dependants">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm font-medium" data-testid="text-dependants-title">Dependants</div>
          <div className="mt-1 text-xs text-muted-foreground" data-testid="text-dependants-subtitle">
            Manage your dependants for education and estate planning
          </div>
        </div>
        <div className="flex items-center gap-2">
          {dirty && (
            <Button size="sm" onClick={handleSave} data-testid="button-dependants-save">
              <Save className="mr-1 h-3.5 w-3.5" />
              Save
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={addRow} data-testid="button-dependants-add">
            <Plus className="mr-1 h-3.5 w-3.5" />
            Add
          </Button>
        </div>
      </div>

      {rows.length === 0 && (
        <div className="mt-4 rounded-xl border bg-background/60 p-4 text-center text-sm text-muted-foreground" data-testid="text-no-dependants">
          No dependants added yet. Click "Add" to add a dependant.
        </div>
      )}

      {rows.length > 0 && (
        <div className="mt-4 space-y-2" data-testid="list-dependants">
          {rows.map((row) => (
            <div
              key={row.id}
              className="flex items-center gap-2 rounded-xl border bg-background/60 p-2"
              data-testid={`row-dependant-${row.id}`}
            >
              <div className="flex-1">
                <Input
                  placeholder="Name"
                  value={row.name}
                  onChange={(e) => updateRow(row.id, "name", e.target.value)}
                  className="h-8 text-sm"
                  data-testid={`input-dependant-name-${row.id}`}
                />
              </div>
              <div className="w-20">
                <Input
                  type="number"
                  placeholder="Age"
                  value={row.age || ""}
                  onChange={(e) => updateRow(row.id, "age", Number(e.target.value) || 0)}
                  className="h-8 text-sm text-center"
                  data-testid={`input-dependant-age-${row.id}`}
                />
              </div>
              <Button
                size="icon"
                variant="ghost"
                className="h-7 w-7 text-muted-foreground hover:text-destructive"
                onClick={() => removeRow(row.id)}
                data-testid={`button-dependant-delete-${row.id}`}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
