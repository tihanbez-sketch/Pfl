import { Link, useLocation } from "wouter";
import { ModeToggle } from "./ModeToggle";
import { useMode } from "@/lib/plan4life/mode";
import { TreePine, LogOut, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { User } from "@shared/models/auth";

interface TopNavProps {
  user?: User | null;
}

export function TopNav({ user }: TopNavProps) {
  const [location] = useLocation();
  const { mode } = useMode();

  const isActive = (href: string) =>
    location === href ? "text-foreground" : "text-muted-foreground";

  return (
    <header className="sticky top-0 z-40 border-b bg-background/75 backdrop-blur supports-[backdrop-filter]:bg-background/60 no-print">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-4 py-3">
        <Link href={mode === "client" ? location : "/clients"} className="flex items-center gap-3">
          <div
            className="grid h-9 w-9 place-items-center rounded-xl border bg-card shadow-sm"
            aria-hidden
          >
            <TreePine className="h-4.5 w-4.5 text-primary" />
          </div>
          <div className="leading-tight">
            <div className="font-serif text-lg font-semibold" data-testid="text-app-title">
              PFL
            </div>
            <div className="text-[10px] font-medium uppercase tracking-widest text-primary/60" data-testid="text-app-slogan">
              Planning Your Path
            </div>
          </div>
        </Link>

        {mode === "advisor" && user?.role === "advisor" && (
          <nav className="flex items-center gap-4 text-sm md:gap-6">
            <Link
              href="/clients"
              data-testid="link-nav-clients"
              className={
                "hover:text-foreground transition-colors " + isActive("/clients")
              }
            >
              Clients
            </Link>
            <Link
              href="/admin/users"
              data-testid="link-nav-users"
              className={
                "hover:text-foreground transition-colors flex items-center gap-1.5 " + isActive("/admin/users")
              }
            >
              <Users className="h-3.5 w-3.5" />
              Users
            </Link>
          </nav>
        )}

        <div className="flex items-center gap-3">
          <ModeToggle />
          {user && (
            <div className="flex items-center gap-2">
              {user.profileImageUrl && (
                <img
                  src={user.profileImageUrl}
                  alt=""
                  className="h-7 w-7 rounded-full border"
                  data-testid="img-user-avatar"
                />
              )}
              <span className="hidden text-sm text-muted-foreground md:inline" data-testid="text-user-name">
                {user.firstName || user.email || "User"}
              </span>
              <a href="/api/logout" data-testid="button-logout">
                <Button variant="ghost" size="icon" className="h-8 w-8" title="Sign out">
                  <LogOut className="h-4 w-4" />
                </Button>
              </a>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
