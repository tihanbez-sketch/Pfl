import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import type { Client } from "@/lib/plan4life/types";
import { formatZar } from "@/lib/plan4life/format";

export function ClientToolsPanel({ client }: { client: Client }) {
  const [lumpSum, setLumpSum] = React.useState(200000);
  const [years, setYears] = React.useState(10);

  const monthlyRate = 0.08 / 12;
  const months = years * 12;
  const futureValue = Math.round(lumpSum * Math.pow(1 + monthlyRate, months));

  return (
    <Card className="rounded-2xl p-4 shadow-sm p4l-noise" data-testid="card-client-tools">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm font-medium" data-testid="text-tools-title">Investment calculator</div>
          <div className="mt-1 text-xs text-muted-foreground" data-testid="text-tools-subtitle">
            Estimate how your money could grow over time
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-xl border bg-background/60 p-3" data-testid="panel-tools-growth">
        <div className="text-sm font-medium" data-testid="text-tools-growth-title">Growth projection</div>
        <div className="mt-1 text-xs text-muted-foreground" data-testid="text-tools-growth-hint">
          Projected at 8% p.a. compounded monthly
        </div>

        <div className="mt-3 grid gap-3">
          <label className="grid gap-1" data-testid="field-tools-lumpsum">
            <span className="text-xs text-muted-foreground" data-testid="label-tools-lumpsum">Lump sum (R)</span>
            <Input
              value={String(lumpSum)}
              onChange={(e) => setLumpSum(Number(e.target.value || 0))}
              data-testid="input-tools-lumpsum"
            />
          </label>

          <div className="rounded-xl border bg-card p-3" data-testid="field-tools-years">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground" data-testid="label-tools-years">Investment period</span>
              <span className="text-xs font-medium" data-testid="value-tools-years">{years} years</span>
            </div>
            <div className="mt-3" data-testid="slider-tools-years">
              <Slider
                value={[years]}
                min={1}
                max={30}
                step={1}
                onValueChange={(v) => setYears(v[0] ?? 10)}
                data-testid="input-tools-years"
              />
            </div>
          </div>

          <div className="flex items-center justify-between rounded-xl border bg-card px-3 py-2" data-testid="row-tools-future">
            <span className="text-xs text-muted-foreground" data-testid="label-tools-future">Estimated value</span>
            <span className="text-sm font-semibold" data-testid="value-tools-future">{formatZar(futureValue)}</span>
          </div>
        </div>
      </div>

      <div className="mt-3 rounded-xl border bg-background/60 p-3" data-testid="panel-tools-cta">
        <div className="text-sm font-medium" data-testid="text-tools-cta-title">Need guidance?</div>
        <div className="mt-1 text-xs text-muted-foreground" data-testid="text-tools-cta-note">
          Use the meeting request panel above to schedule a session with your advisor.
        </div>
      </div>
    </Card>
  );
}
