import React from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import type { Client } from "@/lib/plan4life/types";
import { useUpdateClient } from "@/lib/plan4life/api";

export function ClientProfilePanel({ client, locked }: { client: Client; locked: boolean }) {
  const [isEditing, setIsEditing] = React.useState(false);
  const [profile, setProfile] = React.useState(client.profile);
  const updateClient = useUpdateClient();

  const handleSave = () => {
    updateClient.mutate({
      id: client.id,
      data: {
        contactCell: profile.contact.cell,
        contactEmail: profile.contact.email,
        addressHome: profile.address.home,
        addressPostal: profile.address.postal,
      },
    });
    setIsEditing(false);
  };

  const showEdit = !locked && !isEditing;
  const showSave = !locked && isEditing;

  return (
    <Card className="rounded-2xl p-4 shadow-sm p4l-noise" data-testid="card-profile">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-sm font-medium" data-testid="text-profile-title">Personal Details</div>
          <div className="mt-1 text-xs text-muted-foreground" data-testid="text-profile-subtitle">
            {locked ? "Contact information on file" : "Manage your contact information"}
          </div>
        </div>
        {showEdit && (
          <Button variant="outline" size="sm" onClick={() => setIsEditing(true)} data-testid="button-profile-edit">
            Update Details
          </Button>
        )}
        {showSave && (
          <Button size="sm" onClick={handleSave} data-testid="button-profile-save">
            Save Changes
          </Button>
        )}
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <div className="space-y-3">
          <div className="grid gap-1">
            <label className="text-xs text-muted-foreground">Full Name</label>
            <Input value={client.name} disabled className="bg-muted/50" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="grid gap-1">
              <label className="text-xs text-muted-foreground">ID Number</label>
              <Input value={profile.idNumber} disabled className="bg-muted/50" />
            </div>
            <div className="grid gap-1">
              <label className="text-xs text-muted-foreground">Tax Reference</label>
              <Input value={profile.tax.reference} disabled className="bg-muted/50" />
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div className="grid gap-1">
              <label className="text-xs text-muted-foreground">Cellphone</label>
              <Input
                value={profile.contact.cell}
                disabled={!isEditing}
                onChange={(e) => setProfile(p => ({ ...p, contact: { ...p.contact, cell: e.target.value } }))}
                className={!isEditing ? "bg-transparent border-transparent px-0 h-auto font-medium" : ""}
              />
            </div>
            <div className="grid gap-1">
              <label className="text-xs text-muted-foreground">Email</label>
              <Input
                value={profile.contact.email}
                disabled={!isEditing}
                onChange={(e) => setProfile(p => ({ ...p, contact: { ...p.contact, email: e.target.value } }))}
                className={!isEditing ? "bg-transparent border-transparent px-0 h-auto font-medium" : ""}
              />
            </div>
          </div>
          <div className="grid gap-1">
            <label className="text-xs text-muted-foreground">Physical Address</label>
            <Textarea
              value={profile.address.home}
              disabled={!isEditing}
              onChange={(e) => setProfile(p => ({ ...p, address: { ...p.address, home: e.target.value } }))}
              className={!isEditing ? "bg-transparent border-transparent px-0 h-auto font-medium min-h-[60px] resize-none" : "min-h-[60px]"}
            />
          </div>
        </div>
      </div>
    </Card>
  );
}
