import React from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Trash2, MoreHorizontal, Plus, Save } from "lucide-react";
import type { Client } from "@/lib/plan4life/types";
import { formatZar } from "@/lib/plan4life/format";
import { useSaveBulkAssets, useSaveBulkLiabilities } from "@/lib/plan4life/api";

type AssetRow = {
  id: string;
  category: string;
  description: string;
  currency: string;
  baseCost: number;
  marketValue: number;
  ownerShare: number;
  included: boolean;
  beneficiary: string;
};

type LiabilityRow = {
  id: string;
  category: string; // "Hire purchases", "Credit cards", etc.
  description: string;
  currency: string;
  amount: number;
  ownerShare: number;
  included: boolean;
};

function mapClientToRows(client: Client) {
  const assets: AssetRow[] = [];
  const liabilities: LiabilityRow[] = [];

  // Map Investments -> Assets
  client.investments.forEach((inv) => {
    inv.holdings.forEach((h) => {
      let category = "Other assets";
      if (inv.type === "RA" || inv.type === "Retirement Annuity") category = "Retirement funds";
      if (inv.type === "TFSA") category = "Voluntary investments";
      if (h.assetClass === "Property" && h.name.includes("Megafin")) category = "Business interests";
      if (h.assetClass === "Equity" && h.name.includes("PFL")) category = "Business interests";

      assets.push({
        id: h.id,
        category,
        description: h.name,
        currency: "ZAR",
        baseCost: 0,
        marketValue: h.value,
        ownerShare: 100,
        included: true,
        beneficiary: h.beneficiary || "",
      });
    });
  });

  // Add personal assets for known client profiles
  if (client.id === "c-004") {
    const personal = ["FKS", "Art", "Jewellery", "Personal stuff", "Car"];
    const exists = assets.some((a) => personal.includes(a.description));
    if (!exists) {
      assets.push(
        { id: "pa-1", category: "Business interests", description: "FKS", currency: "ZAR", baseCost: 0, marketValue: 15000, ownerShare: 100, included: true, beneficiary: "" },
        { id: "pa-2", category: "Personal effects", description: "Art", currency: "ZAR", baseCost: 0, marketValue: 10000, ownerShare: 100, included: true, beneficiary: "" },
        { id: "pa-3", category: "Personal effects", description: "Jewellery", currency: "ZAR", baseCost: 0, marketValue: 30000, ownerShare: 100, included: true, beneficiary: "" },
        { id: "pa-4", category: "Personal effects", description: "Personal stuff", currency: "ZAR", baseCost: 0, marketValue: 50000, ownerShare: 100, included: true, beneficiary: "" },
        { id: "pa-5", category: "Other assets", description: "Car", currency: "ZAR", baseCost: 0, marketValue: 260000, ownerShare: 100, included: true, beneficiary: "" }
      );
    }
    assets.push(
      { id: "as-1", category: "Assurance", description: "Alexander Forbes Group Life Cover", currency: "ZAR", baseCost: 0, marketValue: 0, ownerShare: 100, included: true, beneficiary: "" },
      { id: "as-2", category: "Assurance", description: "Hollard portfolio (7006367)", currency: "ZAR", baseCost: 0, marketValue: 0, ownerShare: 100, included: true, beneficiary: "" }
    );
  }

  // Map Liabilities
  client.liabilities.forEach((l) => {
    let category = "Other debt";
    if (l.name.toLowerCase().includes("car") || l.name.toLowerCase().includes("vehicle")) category = "Hire purchases and leases";
    if (l.name.toLowerCase().includes("card") || l.name.toLowerCase().includes("overdraft")) category = "Overdrafts and credit cards";
    if (l.name.toLowerCase().includes("home") || l.name.toLowerCase().includes("bond")) category = "Bonds";

    liabilities.push({
      id: l.id,
      category,
      description: l.name,
      currency: "ZAR",
      amount: l.balance,
      ownerShare: 100,
      included: true,
    });
  });

  return { assets, liabilities };
}

export function ClientAssetsLiabilitiesPanel({ client, locked }: { client: Client; locked: boolean }) {
  const initial = React.useMemo(() => mapClientToRows(client), [client]);
  const [assets, setAssets] = React.useState<AssetRow[]>(initial.assets);
  const [liabilities, setLiabilities] = React.useState<LiabilityRow[]>(initial.liabilities);
  const [dirty, setDirty] = React.useState(false);
  const saveBulkAssets = useSaveBulkAssets();
  const saveBulkLiabilities = useSaveBulkLiabilities();
  const saving = saveBulkAssets.isPending || saveBulkLiabilities.isPending;

  const totalAssets = assets.filter(a => a.included).reduce((sum, a) => sum + a.marketValue, 0);
  const totalLiabilities = liabilities.filter(l => l.included).reduce((sum, l) => sum + l.amount, 0);
  const netAssets = totalAssets - totalLiabilities;

  const handleSave = () => {
    const assetPayload = assets.map(a => ({
      id: a.id,
      clientId: client.id,
      category: a.category,
      description: a.description,
      provider: "",
      accountNumber: "",
      accountGroup: a.category,
      marketValue: a.marketValue,
      beneficiary: a.beneficiary || null,
    }));
    const liabilityPayload = liabilities.map(l => ({
      id: l.id,
      clientId: client.id,
      category: l.category,
      name: l.description,
      balance: l.amount,
      interestRate: 0,
    }));
    saveBulkAssets.mutate({ clientId: client.id, assets: assetPayload });
    saveBulkLiabilities.mutate({ clientId: client.id, liabilities: liabilityPayload });
    setDirty(false);
  };

  const updateAsset = (id: string, field: keyof AssetRow, value: any) => {
    setAssets(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
    setDirty(true);
  };

  const updateLiability = (id: string, field: keyof LiabilityRow, value: any) => {
    setLiabilities(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
    setDirty(true);
  };

  const deleteAsset = (id: string) => { setAssets(prev => prev.filter(i => i.id !== id)); setDirty(true); };
  const deleteLiability = (id: string) => { setLiabilities(prev => prev.filter(i => i.id !== id)); setDirty(true); };

  const AssetGroup = ({ title, items }: { title: string; items: AssetRow[] }) => {
    if (items.length === 0) return null; // Or show placeholder
    const groupTotal = items.reduce((sum, i) => sum + (i.included ? i.marketValue : 0), 0);
    
    return (
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-2 bg-slate-50 dark:bg-slate-900/50 p-2 rounded-lg">
          <Button size="icon" variant="ghost" className="h-5 w-5 bg-primary text-primary-foreground rounded-sm">
            <Plus className="h-3 w-3" />
          </Button>
          <span className="font-medium text-sm text-slate-700 dark:text-slate-300">{title}</span>
          <div className="ml-auto text-sm font-semibold">{formatZar(groupTotal)}</div>
        </div>
        <div className="space-y-2 pl-2">
          {items.map(item => (
            <div key={item.id} className="flex items-center gap-2 group">
              <Button 
                size="icon" 
                variant="ghost" 
                className="h-6 w-6 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => deleteAsset(item.id)}
                disabled={locked}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
              <Checkbox 
                checked={item.included} 
                onCheckedChange={(c) => !locked && updateAsset(item.id, "included", !!c)}
                disabled={locked}
              />
              <div className="flex-1 min-w-[200px]">
                <Input 
                  value={item.description}
                  onChange={(e) => updateAsset(item.id, "description", e.target.value)}
                  className="h-8 text-sm"
                  disabled={locked}
                />
              </div>
              <div className="w-[80px]">
                <Select disabled={locked} value={item.currency} onValueChange={(v) => updateAsset(item.id, "currency", v)}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ZAR">ZAR</SelectItem>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="GBP">GBP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-[100px]">
                <Input 
                  type="number"
                  placeholder="Base cost"
                  value={item.baseCost || ""}
                  onChange={(e) => updateAsset(item.id, "baseCost", Number(e.target.value))}
                  className="h-8 text-sm text-right"
                  disabled={locked}
                />
              </div>
              <div className="w-[120px]">
                <Input 
                  type="number"
                  value={item.marketValue}
                  onChange={(e) => updateAsset(item.id, "marketValue", Number(e.target.value))}
                  className="h-8 text-sm text-right font-medium"
                  disabled={locked}
                />
              </div>
              <div className="w-[60px]">
                <Input 
                  value={item.ownerShare}
                  onChange={(e) => updateAsset(item.id, "ownerShare", Number(e.target.value))}
                  className="h-8 text-sm text-center"
                  disabled={locked}
                />
              </div>
              <div className="w-[120px]">
                <Select
                  disabled={locked}
                  value={item.beneficiary || "__none__"}
                  onValueChange={(v) => updateAsset(item.id, "beneficiary", v === "__none__" ? "" : v)}
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="Beneficiary" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">None</SelectItem>
                    <SelectItem value="Estate">Estate</SelectItem>
                    <SelectItem value="Spouse">Spouse</SelectItem>
                    {client.dependants.map((d) => (
                      <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button size="icon" variant="ghost" className="h-6 w-6" disabled={locked}>
                <MoreHorizontal className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const LiabilityGroup = ({ title, items }: { title: string; items: LiabilityRow[] }) => {
    if (items.length === 0) return null;
    const groupTotal = items.reduce((sum, i) => sum + (i.included ? i.amount : 0), 0);

    return (
      <div className="mb-4">
        <div className="flex items-center gap-2 mb-2 bg-slate-50 dark:bg-slate-900/50 p-2 rounded-lg">
          <Button size="icon" variant="ghost" className="h-5 w-5 bg-primary text-primary-foreground rounded-sm">
            <Plus className="h-3 w-3" />
          </Button>
          <span className="font-medium text-sm text-slate-700 dark:text-slate-300">{title}</span>
          <div className="ml-auto text-sm font-semibold">{formatZar(groupTotal)}</div>
        </div>
        <div className="space-y-2 pl-2">
          {items.map(item => (
            <div key={item.id} className="flex items-center gap-2 group">
              <Button 
                size="icon" 
                variant="ghost" 
                className="h-6 w-6 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => deleteLiability(item.id)}
                disabled={locked}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
              <Checkbox 
                checked={item.included} 
                onCheckedChange={(c) => !locked && updateLiability(item.id, "included", !!c)}
                disabled={locked}
              />
              <div className="flex-1 min-w-[200px]">
                <Input 
                  value={item.description}
                  onChange={(e) => updateLiability(item.id, "description", e.target.value)}
                  className="h-8 text-sm"
                  disabled={locked}
                />
              </div>
              <div className="w-[80px]">
                <Select disabled={locked} value={item.currency} onValueChange={(v) => updateLiability(item.id, "currency", v)}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ZAR">ZAR</SelectItem>
                    <SelectItem value="USD">USD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {/* Spacer for alignment with Assets table base cost column */}
              <div className="w-[100px]" />
              <div className="w-[120px]">
                <Input 
                  type="number"
                  value={item.amount}
                  onChange={(e) => updateLiability(item.id, "amount", Number(e.target.value))}
                  className="h-8 text-sm text-right font-medium"
                  disabled={locked}
                />
              </div>
              <div className="w-[60px]">
                <Input 
                  value={item.ownerShare}
                  onChange={(e) => updateLiability(item.id, "ownerShare", Number(e.target.value))}
                  className="h-8 text-sm text-center"
                  disabled={locked}
                />
              </div>
               <Button size="icon" variant="ghost" className="h-6 w-6" disabled={locked}>
                <MoreHorizontal className="h-3 w-3" />
              </Button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const assetCategories = [
    "Immovable assets (primary residence)",
    "Immovable assets (other)",
    "Business interests",
    "Movable property",
    "Personal effects",
    "Voluntary investments",
    "Retirement funds",
    "Assurance",
    "Other assets"
  ];

  const liabilityCategories = [
    "Bonds",
    "Hire purchases and leases",
    "Overdrafts and credit cards",
    "Other debt"
  ];

  return (
    <Card className="rounded-2xl p-0 overflow-hidden shadow-sm border" data-testid="card-assets-liabilities">
      {/* Header */}
      <div className="bg-slate-100/50 dark:bg-slate-800/50 p-4 border-b flex justify-between items-center">
        <div>
           <div className="text-sm font-medium" data-testid="text-al-title">Assets & Liabilities</div>
           <div className="text-xs text-muted-foreground">Update your balance sheet</div>
        </div>
        {!locked && (
          <div className="flex gap-2">
           {dirty && (
             <Button variant="default" size="sm" className="h-7 text-xs gap-1" onClick={handleSave} disabled={saving} data-testid="button-save-assets">
               <Save className="h-3 w-3" />
               {saving ? "Saving..." : "Save changes"}
             </Button>
           )}
           <Button variant="outline" size="sm" className="h-7 text-xs">
              Add item
           </Button>
          </div>
        )}
      </div>

      {/* Table Header Row */}
      <div className="flex items-center gap-2 p-2 border-b bg-slate-50/50 dark:bg-slate-900/20 text-xs text-muted-foreground font-medium">
        <div className="w-6 text-center">Del</div>
        <div className="w-4 text-center">Incl?</div>
        <div className="flex-1 pl-1">Category and description</div>
        <div className="w-[80px]">Currency</div>
        <div className="w-[100px] text-right pr-2">Base cost</div>
        <div className="w-[120px] text-right pr-2">Market value</div>
        <div className="w-[60px] text-center">{client.name.split(" ")[0]} %</div>
        <div className="w-[120px]">Beneficiary</div>
        <div className="w-6"></div>
      </div>

      <div className="p-4 space-y-6">
        {/* ASSETS */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold tracking-tight">ASSETS</h3>
            <div className="text-sm font-bold bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-md">{formatZar(totalAssets)}</div>
          </div>
          <div className="pl-1">
             {assetCategories.map(cat => (
                <AssetGroup 
                  key={cat} 
                  title={cat} 
                  items={assets.filter(a => a.category === cat || (cat === "Other assets" && !assetCategories.includes(a.category)))} 
                />
             ))}
          </div>
        </div>

        {/* LIABILITIES */}
        <div className="pt-4 border-t">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold tracking-tight">LIABILITIES</h3>
            <div className="text-sm font-bold bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-md">{formatZar(totalLiabilities)}</div>
          </div>
          <div className="pl-1">
             {liabilityCategories.map(cat => (
                <LiabilityGroup 
                  key={cat} 
                  title={cat} 
                  items={liabilities.filter(l => l.category === cat || (cat === "Other debt" && !liabilityCategories.includes(l.category)))} 
                />
             ))}
          </div>
        </div>

        {/* NET */}
        <div className="pt-4 border-t flex items-center justify-between bg-slate-50 dark:bg-slate-900/30 -mx-4 -mb-4 p-4">
           <h3 className="text-sm font-bold">NET ASSETS</h3>
           <div className="text-lg font-bold">{formatZar(netAssets)}</div>
        </div>
      </div>
    </Card>
  );
}
