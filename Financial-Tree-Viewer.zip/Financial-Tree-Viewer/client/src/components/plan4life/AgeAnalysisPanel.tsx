import React from "react";
import { Card } from "@/components/ui/card";
import type { Client } from "@/lib/plan4life/types";

type Bucket = {
  id: string;
  label: string;
  min: number;
  max: number;
};

const buckets: Bucket[] = [
  { id: "u30", label: "Under 30", min: 0, max: 29 },
  { id: "30s", label: "30–39", min: 30, max: 39 },
  { id: "40s", label: "40–49", min: 40, max: 49 },
  { id: "50s", label: "50–59", min: 50, max: 59 },
  { id: "60p", label: "60+", min: 60, max: 200 },
];

function pct(n: number, total: number) {
  if (!total) return 0;
  return Math.round((n / total) * 100);
}

export function AgeAnalysisPanel({ clients }: { clients: Client[] }) {
  const total = clients.length;

  const ages = clients.map((c) => c.age).filter((a) => Number.isFinite(a));
  const avg = ages.length ? Math.round(ages.reduce((a, b) => a + b, 0) / ages.length) : 0;
  const minAge = ages.length ? Math.min(...ages) : 0;
  const maxAge = ages.length ? Math.max(...ages) : 0;

  const counts = buckets.map((b) => ({
    ...b,
    count: clients.filter((c) => c.age >= b.min && c.age <= b.max).length,
  }));

  return (
    <Card className="rounded-2xl border bg-card p-4 shadow-sm p4l-noise" data-testid="panel-age-analysis">
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-sm font-medium" data-testid="text-age-title">Age analysis</div>
          <div className="mt-1 text-xs text-muted-foreground" data-testid="text-age-subtitle">
            Quick view of your book’s age distribution.
          </div>
        </div>
        <div className="text-xs text-muted-foreground" data-testid="text-age-total">
          {total} clients
        </div>
      </div>

      <div className="mt-4 grid gap-2" data-testid="grid-age-stats">
        <div className="grid grid-cols-3 gap-2">
          <div className="rounded-xl border bg-background/60 px-3 py-2" data-testid="stat-age-avg">
            <div className="text-[11px] text-muted-foreground" data-testid="label-age-avg">Average</div>
            <div className="text-sm font-semibold" data-testid="value-age-avg">{avg}</div>
          </div>
          <div className="rounded-xl border bg-background/60 px-3 py-2" data-testid="stat-age-min">
            <div className="text-[11px] text-muted-foreground" data-testid="label-age-min">Youngest</div>
            <div className="text-sm font-semibold" data-testid="value-age-min">{minAge}</div>
          </div>
          <div className="rounded-xl border bg-background/60 px-3 py-2" data-testid="stat-age-max">
            <div className="text-[11px] text-muted-foreground" data-testid="label-age-max">Oldest</div>
            <div className="text-sm font-semibold" data-testid="value-age-max">{maxAge}</div>
          </div>
        </div>

        <div className="mt-2 grid gap-2" data-testid="list-age-buckets">
          {counts.map((b) => (
            <div
              key={b.id}
              className="rounded-xl border bg-background/60 px-3 py-2"
              data-testid={`row-age-bucket-${b.id}`}
            >
              <div className="flex items-center justify-between">
                <div className="text-sm" data-testid={`text-age-bucket-${b.id}`}>{b.label}</div>
                <div className="text-xs text-muted-foreground" data-testid={`value-age-bucket-${b.id}`}
                >
                  {b.count} · {pct(b.count, total)}%
                </div>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-foreground/10" data-testid={`bar-age-${b.id}`}>
                <div
                  className="h-full rounded-full bg-[linear-gradient(90deg,hsl(var(--primary)/0.9),hsl(var(--chart-4)/0.85))]"
                  style={{ width: `${pct(b.count, total)}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-2 rounded-xl border bg-background/60 p-3 text-xs text-muted-foreground" data-testid="text-age-note">
          Use the filters above to see distribution for a specific segment.
        </div>
      </div>
    </Card>
  );
}
