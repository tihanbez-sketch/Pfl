import React from "react";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { lifeStages, defaultLifeStageForAge, type LifeStageId } from "@/lib/plan4life/lifestages";
import type { Client } from "@/lib/plan4life/types";

export function LifeStagePanel({
  client,
  locked,
}: {
  client: Client;
  locked: boolean;
}) {
  const [stage, setStage] = React.useState<LifeStageId>(() => defaultLifeStageForAge(client.age));

  const def = lifeStages.find((s) => s.id === stage) ?? lifeStages[0];

  const stageProgress = (() => {
    const idx = lifeStages.findIndex((s) => s.id === stage);
    return Math.round(((idx + 1) / lifeStages.length) * 100);
  })();

  return (
    <Card className="rounded-2xl p-4 shadow-sm p4l-noise" data-testid="card-life-stage">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm font-medium" data-testid="text-life-stage-title">Life stage planning</div>
          <div className="mt-1 text-xs text-muted-foreground" data-testid="text-life-stage-subtitle">
            Priorities and focus areas based on life stage
          </div>
        </div>
        <div className="min-w-[180px]">
          <Select value={stage} onValueChange={(v) => setStage(v as LifeStageId)}>
            <SelectTrigger className="h-9" disabled={locked} data-testid="select-life-stage">
              <SelectValue placeholder="Select stage" />
            </SelectTrigger>
            <SelectContent>
              {lifeStages.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="mt-4 rounded-xl border bg-background/60 p-3" data-testid="panel-life-stage-summary">
        <div className="text-xs text-muted-foreground" data-testid="text-life-stage-name">{def.name}</div>
        <div className="mt-1 text-sm" data-testid="text-life-stage-summary">
          {def.summary}
        </div>
        <div className="mt-3" data-testid="progress-life-stage">
          <Progress value={stageProgress} />
        </div>
      </div>

      <div className="mt-4 grid gap-2" data-testid="list-life-stage-focus">
        {def.focusAreas.map((f) => (
          <div
            key={f.id}
            className="flex items-start justify-between gap-3 rounded-xl border bg-card px-3 py-2"
            data-testid={`row-life-focus-${f.id}`}
          >
            <div>
              <div className="text-sm font-medium" data-testid={`text-life-focus-label-${f.id}`}>{f.label}</div>
              <div className="mt-0.5 text-xs text-muted-foreground" data-testid={`text-life-focus-hint-${f.id}`}>{f.hint}</div>
            </div>
            <div
              className="rounded-full border bg-background px-2 py-0.5 text-[11px] text-muted-foreground"
              data-testid={`badge-life-focus-${f.id}`}
            >
              Focus
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
