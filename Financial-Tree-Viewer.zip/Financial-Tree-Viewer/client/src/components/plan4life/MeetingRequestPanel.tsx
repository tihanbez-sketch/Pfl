import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useCreateMeetingRequest } from "@/lib/plan4life/api";
import { CalendarDays, CheckCircle2 } from "lucide-react";

export type MeetingRequest = {
  preferredDate: string;
  preferredTime: string;
  reason: string;
};

export function MeetingRequestPanel({
  clientId,
  locked,
  onSubmit,
}: {
  clientId: string;
  locked: boolean;
  onSubmit: (r: MeetingRequest) => void;
}) {
  const createMeeting = useCreateMeetingRequest();
  const [req, setReq] = React.useState<MeetingRequest>({
    preferredDate: "",
    preferredTime: "",
    reason: "",
  });
  const [submitted, setSubmitted] = React.useState(false);

  const handleSubmit = () => {
    createMeeting.mutate({ clientId, ...req });
    onSubmit(req);
    setSubmitted(true);
  };

  return (
    <Card className="rounded-2xl p-4 shadow-sm p4l-noise" data-testid="card-meeting-request">
      <div className="flex items-start gap-3">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
          <CalendarDays className="h-4.5 w-4.5" />
        </div>
        <div>
          <div className="text-sm font-medium" data-testid="text-meeting-title">Request a meeting</div>
          <div className="mt-1 text-xs text-muted-foreground" data-testid="text-meeting-subtitle">
            Your advisor will be notified and will contact you to confirm.
          </div>
        </div>
      </div>

      {submitted ? (
        <div className="mt-4 rounded-xl border bg-primary/5 p-4 flex items-center gap-3" data-testid="text-meeting-success">
          <CheckCircle2 className="h-5 w-5 text-primary shrink-0" />
          <div>
            <div className="text-sm font-medium text-primary">Meeting request sent</div>
            <div className="text-xs text-muted-foreground">Your advisor will reach out to confirm the details.</div>
          </div>
        </div>
      ) : (
        <div className="mt-4 grid gap-3" data-testid="form-meeting">
          <label className="grid gap-1" data-testid="field-meeting-date">
            <span className="text-xs text-muted-foreground" data-testid="label-meeting-date">Preferred date</span>
            <Input
              type="date"
              value={req.preferredDate}
              onChange={(e) => setReq((s) => ({ ...s, preferredDate: e.target.value }))}
              disabled={locked}
              data-testid="input-meeting-date"
            />
          </label>

          <label className="grid gap-1" data-testid="field-meeting-time">
            <span className="text-xs text-muted-foreground" data-testid="label-meeting-time">Preferred time</span>
            <Input
              placeholder="e.g. 10:30"
              value={req.preferredTime}
              onChange={(e) => setReq((s) => ({ ...s, preferredTime: e.target.value }))}
              disabled={locked}
              data-testid="input-meeting-time"
            />
          </label>

          <label className="grid gap-1" data-testid="field-meeting-reason">
            <span className="text-xs text-muted-foreground" data-testid="label-meeting-reason">What would you like to discuss?</span>
            <Textarea
              value={req.reason}
              onChange={(e) => setReq((s) => ({ ...s, reason: e.target.value }))}
              disabled={locked}
              placeholder="e.g. Review my investment portfolio, update beneficiaries..."
              data-testid="input-meeting-reason"
            />
          </label>

          <Button
            onClick={handleSubmit}
            disabled={locked || !req.preferredDate}
            data-testid="button-meeting-submit"
          >
            Send request
          </Button>
        </div>
      )}
    </Card>
  );
}
