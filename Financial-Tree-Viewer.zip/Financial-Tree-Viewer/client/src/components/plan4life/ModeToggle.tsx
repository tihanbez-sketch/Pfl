import { Switch } from "@/components/ui/switch";
import { useMode } from "@/lib/plan4life/mode";

export function ModeToggle() {
  const { mode, setMode } = useMode();
  const isAdvisor = mode === "advisor";

  return (
    <div
      className="flex items-center gap-3 rounded-full border bg-card/70 px-3 py-1.5 shadow-sm backdrop-blur p4l-noise"
      data-testid="mode-toggle"
    >
      <div className="text-xs font-medium text-muted-foreground" data-testid="text-mode-label">
        Mode
      </div>
      <div className="flex items-center gap-2">
        <span
          className={
            "text-xs font-medium " +
            (isAdvisor ? "text-foreground" : "text-muted-foreground")
          }
          data-testid="text-mode-advisor"
        >
          Advisor
        </span>
        <Switch
          checked={!isAdvisor}
          onCheckedChange={(v) => setMode(v ? "client" : "advisor")}
          data-testid="switch-mode"
        />
        <span
          className={
            "text-xs font-medium " +
            (!isAdvisor ? "text-foreground" : "text-muted-foreground")
          }
          data-testid="text-mode-client"
        >
          Client
        </span>
      </div>
    </div>
  );
}
