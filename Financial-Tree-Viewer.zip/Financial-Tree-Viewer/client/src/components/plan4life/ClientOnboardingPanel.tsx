import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export type OnboardingDraft = {
  preferredName: string;
  employmentStatus: "employed" | "self_employed" | "retired" | "student" | "unemployed";
  riskProfile: "conservative" | "balanced" | "growth";
  monthlySavings: number;
};

export function ClientOnboardingPanel({
  locked,
  onSubmit,
}: {
  locked: boolean;
  onSubmit: (draft: OnboardingDraft) => void;
}) {
  const [draft, setDraft] = React.useState<OnboardingDraft>({
    preferredName: "",
    employmentStatus: "employed",
    riskProfile: "balanced",
    monthlySavings: 0,
  });
  const [submitted, setSubmitted] = React.useState(false);

  const handleSubmit = () => {
    onSubmit(draft);
    setSubmitted(true);
  };

  return (
    <Card className="rounded-2xl p-4 shadow-sm p4l-noise" data-testid="card-client-onboarding">
      <div>
        <div className="text-sm font-medium" data-testid="text-onboarding-title">Update your details</div>
        <div className="mt-1 text-xs text-muted-foreground" data-testid="text-onboarding-subtitle">
          Help your advisor keep your records up to date
        </div>
      </div>

      {submitted ? (
        <div className="mt-4 rounded-xl border bg-primary/5 p-4 text-center" data-testid="text-onboarding-success">
          <div className="text-sm font-medium text-primary">Details submitted successfully</div>
          <div className="mt-1 text-xs text-muted-foreground">Your advisor will review your updated information.</div>
        </div>
      ) : (
        <div className="mt-4 grid gap-3" data-testid="form-onboarding">
          <label className="grid gap-1" data-testid="field-onboarding-preferred">
            <span className="text-xs text-muted-foreground" data-testid="label-onboarding-preferred">Preferred name</span>
            <Input
              value={draft.preferredName}
              onChange={(e) => setDraft((s) => ({ ...s, preferredName: e.target.value }))}
              disabled={locked}
              placeholder="What should we call you?"
              data-testid="input-onboarding-preferred"
            />
          </label>

          <div className="grid gap-1" data-testid="field-onboarding-employment">
            <span className="text-xs text-muted-foreground" data-testid="label-onboarding-employment">Employment status</span>
            <Select
              value={draft.employmentStatus}
              onValueChange={(v) => setDraft((s) => ({ ...s, employmentStatus: v as OnboardingDraft["employmentStatus"] }))}
            >
              <SelectTrigger disabled={locked} data-testid="select-onboarding-employment">
                <SelectValue placeholder="Select" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="employed">Employed</SelectItem>
                <SelectItem value="self_employed">Self-employed</SelectItem>
                <SelectItem value="retired">Retired</SelectItem>
                <SelectItem value="student">Student</SelectItem>
                <SelectItem value="unemployed">Unemployed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-1" data-testid="field-onboarding-risk">
            <span className="text-xs text-muted-foreground" data-testid="label-onboarding-risk">Risk profile</span>
            <Select
              value={draft.riskProfile}
              onValueChange={(v) => setDraft((s) => ({ ...s, riskProfile: v as OnboardingDraft["riskProfile"] }))}
            >
              <SelectTrigger disabled={locked} data-testid="select-onboarding-risk">
                <SelectValue placeholder="Select" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="conservative">Conservative</SelectItem>
                <SelectItem value="balanced">Balanced</SelectItem>
                <SelectItem value="growth">Growth</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <label className="grid gap-1" data-testid="field-onboarding-savings">
            <span className="text-xs text-muted-foreground" data-testid="label-onboarding-savings">Monthly savings target (R)</span>
            <Input
              value={String(draft.monthlySavings)}
              onChange={(e) => setDraft((s) => ({ ...s, monthlySavings: Number(e.target.value || 0) }))}
              disabled={locked}
              data-testid="input-onboarding-savings"
            />
          </label>

          <Button
            onClick={handleSubmit}
            disabled={locked}
            className="mt-1"
            data-testid="button-onboarding-submit"
          >
            Submit details
          </Button>
        </div>
      )}
    </Card>
  );
}
