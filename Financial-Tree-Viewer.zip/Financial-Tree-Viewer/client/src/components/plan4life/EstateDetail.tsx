import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import type { Client } from "@/lib/plan4life/types";
import { estateReadinessScore, sumInvestments, sumLiabilities } from "@/lib/plan4life/compute";
import { formatZar } from "@/lib/plan4life/format";

function checkRow(label: string, ok: boolean, hint: string, testId: string) {
  return (
    <div className="flex items-start justify-between gap-3 rounded-xl border bg-background/60 px-3 py-2" data-testid={testId}>
      <div>
        <div className="text-sm font-medium" data-testid={`${testId}-label`}>{label}</div>
        <div className="mt-0.5 text-xs text-muted-foreground" data-testid={`${testId}-hint`}>{hint}</div>
      </div>
      <div
        className={
          "rounded-full px-2 py-0.5 text-[11px] font-medium " +
          (ok
            ? "bg-primary/10 text-primary border border-primary/15"
            : "bg-amber-500/10 text-amber-800 border border-amber-500/15")
        }
        data-testid={`${testId}-status`}
      >
        {ok ? "OK" : "Action"}
      </div>
    </div>
  );
}

export function EstateDetail({ client }: { client: Client }) {
  const score = estateReadinessScore(client);

  const willOk = client.estate.willStatus === "in_place";
  const executorOk = client.estate.executorNamed;
  const benOk = client.estate.beneficiaryAlignment === "aligned";
  const liquidityOk = client.estate.liquidityAdequate;

  const guardianshipOk = client.dependants.length === 0 ? true : willOk;

  const docsAccessOk = client.documents.ficaStatus === "complete";

  const estatePackOk = willOk && executorOk && benOk;

  const totalAssets = sumInvestments(client) + client.household.liquidAssets;
  const totalLiabilities = sumLiabilities(client);

  const executorFees = Math.round(totalAssets * 0.04025);
  const cgtEstimate = Math.round(totalAssets * 0.079);
  const masterFees = 7000;
  const funeralCosts = 60000;
  const lifeCoverPayout = client.riskCover.life;
  const totalDeductions = totalLiabilities + executorFees + cgtEstimate + masterFees + funeralCosts;
  const netEstateSurplus = totalAssets + lifeCoverPayout - totalDeductions;

  return (
    <div className="grid gap-4 md:grid-cols-2" data-testid="panel-estate-detailed">
      <Card className="rounded-2xl p-4" data-testid="card-estate-readiness">
        <div className="text-sm font-medium" data-testid="text-estate-detailed-title">Estate readiness</div>
        <div className="mt-3 rounded-xl border bg-background/60 px-3 py-3" data-testid="row-estate-score">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground" data-testid="label-estate-score">Score</span>
            <span className="text-lg font-semibold" data-testid="value-estate-score">{score}/100</span>
          </div>
          <div className="mt-3">
            <Progress value={score} data-testid="progress-estate" />
          </div>
          <div className="mt-2 text-xs text-muted-foreground" data-testid="text-estate-score-hint">
            Based on will status, executor, beneficiary alignment, and liquidity.
          </div>
        </div>

        <div className="mt-4 grid gap-2" data-testid="list-estate-checks">
          {checkRow(
            "Will signed and current",
            willOk,
            "Confirm latest will is signed and reflects current family situation.",
            "check-estate-will",
          )}
          {checkRow(
            "Executor nominated",
            executorOk,
            "Ensure executor details are correct and consent is in place.",
            "check-estate-executor",
          )}
          {checkRow(
            "Beneficiaries aligned",
            benOk,
            "Review beneficiaries across policies and investments for consistency.",
            "check-estate-beneficiaries",
          )}
          {checkRow(
            "Estate liquidity",
            liquidityOk,
            "Check liquidity for taxes, executor fees, and immediate expenses.",
            "check-estate-liquidity",
          )}
        </div>
      </Card>

      <Card className="rounded-2xl p-4" data-testid="card-estate-flags-detailed">
        <div className="text-sm font-medium" data-testid="text-estate-flags-title">Key flags & next steps</div>
        <div className="mt-3 grid gap-2" data-testid="list-estate-flags">
          {checkRow(
            "Minor dependants guardianship",
            guardianshipOk,
            client.dependants.length
              ? "If there are minor children, confirm guardianship instructions in the will."
              : "No dependants recorded.",
            "flag-estate-guardianship",
          )}
          {checkRow(
            "Estate pack accessible",
            estatePackOk,
            "Store will, policy schedules, and contact list in an accessible place.",
            "flag-estate-pack",
          )}
          {checkRow(
            "Document readiness",
            docsAccessOk,
            "Keep IDs, proof of address, and key documents updated.",
            "flag-estate-docs",
          )}
        </div>
      </Card>

      <div className="md:col-span-2">
        <Card className="rounded-2xl p-4" data-testid="card-estate-liquidity">
          <div className="text-sm font-medium" data-testid="text-estate-liquidity-title">Liquidity & costs analysis (estimated)</div>
          <div className="mt-3 grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <div className="flex justify-between text-sm border-b pb-1">
                <span className="text-muted-foreground">Total assets</span>
                <span className="font-medium">{formatZar(totalAssets)}</span>
              </div>
              <div className="flex justify-between text-sm border-b pb-1">
                <span className="text-muted-foreground">Liabilities</span>
                <span className="font-medium text-red-600">({formatZar(totalLiabilities)})</span>
              </div>
              <div className="flex justify-between text-sm border-b pb-1">
                <span className="text-muted-foreground">Executor's fees (est. 4.025%)</span>
                <span className="font-medium text-red-600">({formatZar(executorFees)})</span>
              </div>
              <div className="flex justify-between text-sm border-b pb-1">
                <span className="text-muted-foreground">Capital gains tax (est.)</span>
                <span className="font-medium text-red-600">({formatZar(cgtEstimate)})</span>
              </div>
              <div className="flex justify-between text-sm border-b pb-1">
                <span className="text-muted-foreground">Master's fees</span>
                <span className="font-medium text-red-600">({formatZar(masterFees)})</span>
              </div>
              <div className="flex justify-between text-sm border-b pb-1">
                <span className="text-muted-foreground">Funeral / deathbed</span>
                <span className="font-medium text-red-600">({formatZar(funeralCosts)})</span>
              </div>
            </div>
            <div className={`rounded-xl border p-4 flex flex-col justify-center ${netEstateSurplus >= 0 ? "bg-primary/5" : "bg-red-500/5"}`}>
              <div className="text-sm text-muted-foreground">Net estate surplus / (shortfall)</div>
              <div className={`text-3xl font-serif font-semibold mt-1 ${netEstateSurplus >= 0 ? "text-primary" : "text-red-700"}`}>
                {netEstateSurplus >= 0 ? formatZar(netEstateSurplus) : `(${formatZar(Math.abs(netEstateSurplus))})`}
              </div>
              <div className="text-xs text-muted-foreground mt-2">
                Includes {formatZar(lifeCoverPayout)} life cover payout to estate.
                <br />
                Without life cover: <span className={`font-medium ${totalAssets - totalDeductions >= 0 ? "text-primary" : "text-red-600"}`}>
                  {totalAssets - totalDeductions >= 0
                    ? formatZar(totalAssets - totalDeductions)
                    : `(${formatZar(Math.abs(totalAssets - totalDeductions))}) shortfall`}
                </span>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
