import React from "react";
import { Card } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import type { Client } from "@/lib/plan4life/types";
import { formatZar } from "@/lib/plan4life/format";
import { requiredLifeCover, riskAdequacyScore } from "@/lib/plan4life/compute";
import { defaultAssumptions } from "@/lib/plan4life/demoData";

export function ScenarioPlanner({ client }: { client: Client }) {
  const [shockPct, setShockPct] = React.useState(15);
  const [lifeEvent, setLifeEvent] = React.useState<"market_drop" | "death">("market_drop");

  const baseInvestments = client.investments.reduce((acc, a) => acc + a.holdings.reduce((h, v) => h + v.value, 0), 0);
  const shockedInvestments =
    lifeEvent === "market_drop" ? Math.round(baseInvestments * (1 - shockPct / 100)) : baseInvestments;

  const lifeRequired = requiredLifeCover(client, defaultAssumptions, { annualSpend: client.household.annualSpend });
  const lifeGap = Math.max(0, lifeRequired - client.riskCover.life);

  const score = riskAdequacyScore(client, defaultAssumptions);

  return (
    <Card className="rounded-2xl p-4 shadow-sm p4l-noise" data-testid="card-scenario-planner">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm font-medium" data-testid="text-scenario-title">Scenario planning</div>
          <div className="mt-1 text-xs text-muted-foreground" data-testid="text-scenario-subtitle">
            Explore what-if scenarios for key life events
          </div>
        </div>
      </div>

      <div className="mt-4 grid gap-3">
        <div className="grid grid-cols-2 gap-2" data-testid="row-scenario-type">
          <button
            className={
              "rounded-xl border px-3 py-2 text-sm transition hover-elevate " +
              (lifeEvent === "market_drop" ? "bg-background" : "bg-background/60 text-muted-foreground")
            }
            onClick={() => setLifeEvent("market_drop")}
            data-testid="button-scenario-market"
          >
            Market drop
          </button>
          <button
            className={
              "rounded-xl border px-3 py-2 text-sm transition hover-elevate " +
              (lifeEvent === "death" ? "bg-background" : "bg-background/60 text-muted-foreground")
            }
            onClick={() => setLifeEvent("death")}
            data-testid="button-scenario-death"
          >
            Death event
          </button>
        </div>

        {lifeEvent === "market_drop" && (
          <div className="rounded-xl border bg-background/60 p-3" data-testid="panel-scenario-market">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground" data-testid="label-scenario-shock">Shock</span>
              <span className="text-xs font-medium" data-testid="value-scenario-shock">{shockPct}%</span>
            </div>
            <div className="mt-3" data-testid="slider-scenario-shock">
              <Slider
                value={[shockPct]}
                min={5}
                max={40}
                step={1}
                onValueChange={(v) => setShockPct(v[0] ?? 15)}
                data-testid="input-scenario-shock"
              />
            </div>
            <div className="mt-3 flex items-center justify-between text-sm" data-testid="row-scenario-investments">
              <span className="text-muted-foreground" data-testid="label-scenario-investments">Investments after shock</span>
              <span className="font-semibold" data-testid="value-scenario-investments">{formatZar(shockedInvestments)}</span>
            </div>
          </div>
        )}

        {lifeEvent === "death" && (
          <div className="rounded-xl border bg-background/60 p-3" data-testid="panel-scenario-death">
            <div className="text-sm font-medium" data-testid="text-scenario-death-title">Life cover adequacy</div>
            <div className="mt-2 grid gap-2 text-sm" data-testid="list-scenario-death">
              <div className="flex items-center justify-between" data-testid="row-scenario-life-required">
                <span className="text-muted-foreground" data-testid="label-scenario-life-required">Required</span>
                <span className="font-medium" data-testid="value-scenario-life-required">{formatZar(lifeRequired)}</span>
              </div>
              <div className="flex items-center justify-between" data-testid="row-scenario-life-current">
                <span className="text-muted-foreground" data-testid="label-scenario-life-current">Current cover</span>
                <span className="font-medium" data-testid="value-scenario-life-current">{formatZar(client.riskCover.life)}</span>
              </div>
              <div className="flex items-center justify-between" data-testid="row-scenario-life-gap">
                <span className="text-muted-foreground" data-testid="label-scenario-life-gap">Shortfall</span>
                <span className="font-semibold" data-testid="value-scenario-life-gap">{formatZar(lifeGap)}</span>
              </div>
            </div>
          </div>
        )}

        <div className="rounded-xl border bg-card p-3" data-testid="panel-scenario-score">
          <div className="flex items-center justify-between" data-testid="row-scenario-score">
            <span className="text-xs text-muted-foreground" data-testid="label-scenario-score">Risk adequacy (baseline)</span>
            <span className="text-xs font-medium" data-testid="value-scenario-score">{score}/100</span>
          </div>
          <div className="mt-3" data-testid="progress-scenario-score">
            <Progress value={score} />
          </div>
        </div>
      </div>

      <div className="mt-3 text-xs text-muted-foreground" data-testid="text-scenario-note">
        Illustrative projections. Speak with your advisor for detailed cashflow and estate modelling.
      </div>
    </Card>
  );
}
