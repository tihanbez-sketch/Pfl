import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useRiskQuestionnaire, useSaveRiskQuestionnaire } from "@/lib/plan4life/api";
import { useMode } from "@/lib/plan4life/mode";
import { Shield, ChevronRight, ChevronLeft, CheckCircle, AlertTriangle, RotateCcw } from "lucide-react";

interface Question {
  id: string;
  section: "capacity" | "tolerance" | "goals";
  text: string;
  options: { label: string; value: number }[];
}

const QUESTIONS: Question[] = [
  {
    id: "q1",
    section: "capacity",
    text: "How many months of living expenses do you have in an easily accessible emergency fund (savings account, money market)?",
    options: [
      { label: "Less than 1 month", value: 2 },
      { label: "1 – 3 months", value: 4 },
      { label: "3 – 6 months", value: 6 },
      { label: "More than 6 months", value: 8 },
    ],
  },
  {
    id: "q2",
    section: "capacity",
    text: "What percentage of your monthly income are you able to save or invest after all expenses?",
    options: [
      { label: "Less than 5%", value: 2 },
      { label: "5 – 10%", value: 4 },
      { label: "10 – 20%", value: 6 },
      { label: "More than 20%", value: 8 },
    ],
  },
  {
    id: "q3",
    section: "capacity",
    text: "How stable is your primary source of income?",
    options: [
      { label: "Very unstable — irregular or contract-based", value: 2 },
      { label: "Somewhat stable — employed but uncertain industry", value: 4 },
      { label: "Stable — permanent position or established business", value: 6 },
      { label: "Very stable — multiple income streams or guaranteed pension", value: 8 },
    ],
  },
  {
    id: "q4",
    section: "capacity",
    text: "How much total debt (excluding home loan) do you carry relative to your annual income?",
    options: [
      { label: "More than 50% of annual income", value: 2 },
      { label: "25 – 50% of annual income", value: 4 },
      { label: "Less than 25% of annual income", value: 6 },
      { label: "No non-mortgage debt", value: 8 },
    ],
  },
  {
    id: "q5",
    section: "capacity",
    text: "Do you have adequate life, disability, and dread disease cover in place?",
    options: [
      { label: "No cover at all", value: 2 },
      { label: "Some cover but not enough", value: 4 },
      { label: "Adequate cover in most areas", value: 6 },
      { label: "Fully covered across all categories", value: 8 },
    ],
  },
  {
    id: "q6",
    section: "tolerance",
    text: "If your investment portfolio dropped 20% in a single month, what would you most likely do?",
    options: [
      { label: "Sell everything immediately to stop further losses", value: 2 },
      { label: "Sell some holdings to reduce exposure", value: 5 },
      { label: "Do nothing and wait for recovery", value: 8 },
      { label: "Invest more to take advantage of lower prices", value: 12 },
    ],
  },
  {
    id: "q7",
    section: "tolerance",
    text: "When you think about investing, which statement best describes your feelings?",
    options: [
      { label: "I lose sleep over any potential loss — safety is everything", value: 2 },
      { label: "I prefer stability but accept small ups and downs", value: 5 },
      { label: "I'm comfortable with moderate volatility for better returns", value: 8 },
      { label: "I thrive on volatility — big risks mean big rewards", value: 12 },
    ],
  },
  {
    id: "q8",
    section: "tolerance",
    text: "Which of these investment outcomes would you be most comfortable with over a 12-month period?",
    options: [
      { label: "Guaranteed return of 6% (no chance of loss)", value: 2 },
      { label: "Expected return of 10%, but could range from -5% to +25%", value: 5 },
      { label: "Expected return of 15%, but could range from -15% to +40%", value: 8 },
      { label: "Expected return of 25%, but could range from -30% to +60%", value: 12 },
    ],
  },
  {
    id: "q9",
    section: "tolerance",
    text: "How experienced are you with investment products (unit trusts, shares, ETFs, retirement annuities)?",
    options: [
      { label: "No experience — I've only used savings accounts", value: 2 },
      { label: "Some experience — I have a retirement fund through my employer", value: 5 },
      { label: "Moderate experience — I actively invest in unit trusts or ETFs", value: 8 },
      { label: "Very experienced — I invest directly in shares and understand market cycles", value: 14 },
    ],
  },
  {
    id: "q10",
    section: "goals",
    text: "When do you plan to start drawing on the majority of your investments?",
    options: [
      { label: "Within the next 3 years", value: 2 },
      { label: "In 3 – 7 years", value: 5 },
      { label: "In 7 – 15 years", value: 8 },
      { label: "More than 15 years from now", value: 10 },
    ],
  },
  {
    id: "q11",
    section: "goals",
    text: "What is the primary purpose of your investments?",
    options: [
      { label: "Preserve my capital — I cannot afford to lose money", value: 2 },
      { label: "Generate a steady income with minimal risk", value: 5 },
      { label: "Grow my wealth over time, accepting some ups and downs", value: 8 },
      { label: "Maximise long-term growth — I can handle significant volatility", value: 10 },
    ],
  },
  {
    id: "q12",
    section: "goals",
    text: "Which South African scenario concerns you most about your financial future?",
    options: [
      { label: "Load shedding and rising costs eroding my savings", value: 2 },
      { label: "Rand weakness reducing my purchasing power", value: 5 },
      { label: "Not having enough for retirement given SA inflation", value: 8 },
      { label: "Missing out on growth opportunities while being too conservative", value: 10 },
    ],
  },
];

const SECTION_LABELS = {
  capacity: "Financial Safety Net",
  tolerance: "Gut Feeling About Risk",
  goals: "Goals & Life Circumstances",
};

const SECTION_MAX = {
  capacity: 40,
  tolerance: 50,
  goals: 30,
};

function getProfileLabel(total: number): string {
  if (total <= 40) return "Cautious";
  if (total <= 65) return "Moderately Cautious";
  if (total <= 85) return "Balanced";
  if (total <= 105) return "Moderately Adventurous";
  return "Adventurous";
}

function getProfileColor(label: string): string {
  switch (label) {
    case "Cautious": return "hsl(200, 60%, 50%)";
    case "Moderately Cautious": return "hsl(180, 50%, 45%)";
    case "Balanced": return "hsl(82, 40%, 45%)";
    case "Moderately Adventurous": return "hsl(40, 70%, 50%)";
    case "Adventurous": return "hsl(15, 70%, 55%)";
    default: return "hsl(82, 22%, 42%)";
  }
}

function getProfileDescription(label: string): string {
  switch (label) {
    case "Cautious":
      return "You prefer stability and capital preservation. A portfolio weighted towards income funds, money market, and bonds with minimal equity exposure is recommended.";
    case "Moderately Cautious":
      return "You lean towards safety but can tolerate some market movement. A blend of income-focused and balanced funds with limited equity exposure suits your profile.";
    case "Balanced":
      return "You are comfortable with moderate risk for reasonable growth. A diversified portfolio across equities, bonds, and property with a medium-term horizon is appropriate.";
    case "Moderately Adventurous":
      return "You accept above-average risk for higher potential returns. A portfolio with significant equity exposure, including some offshore allocation, matches your appetite.";
    case "Adventurous":
      return "You embrace volatility and seek maximum long-term growth. A high-equity portfolio with substantial offshore and alternative asset exposure is recommended.";
    default:
      return "";
  }
}

export function RiskQuestionnaire({ clientId }: { clientId: string }) {
  const { mode } = useMode();
  const isAdvisor = mode === "advisor";
  const { data: existingResult, isLoading, isError } = useRiskQuestionnaire(clientId);
  const saveQuestionnaire = useSaveRiskQuestionnaire();

  const [started, setStarted] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [showResult, setShowResult] = useState(false);

  if (isLoading) {
    return (
      <Card data-testid="card-risk-questionnaire">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="h-4 w-4" />
            Risk Profile Questionnaire
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">Loading...</div>
        </CardContent>
      </Card>
    );
  }

  if (existingResult && existingResult.id && !started) {
    const profileColor = getProfileColor(existingResult.profileLabel);
    return (
      <Card data-testid="card-risk-questionnaire">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="h-4 w-4" />
            Risk Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center py-2">
            <div
              className="inline-block rounded-full px-5 py-2 text-white font-semibold text-lg"
              style={{ backgroundColor: profileColor }}
              data-testid="text-risk-profile-label"
            >
              {existingResult.profileLabel}
            </div>
            <div className="mt-3 text-sm text-muted-foreground max-w-md mx-auto" data-testid="text-risk-profile-desc">
              {getProfileDescription(existingResult.profileLabel)}
            </div>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Financial Safety Net</span>
              <span className="font-medium">{existingResult.capacityScore} / {SECTION_MAX.capacity}</span>
            </div>
            <Progress value={(existingResult.capacityScore / SECTION_MAX.capacity) * 100} className="h-2" />

            <div className="flex items-center justify-between mt-3">
              <span className="text-muted-foreground">Gut Feeling About Risk</span>
              <span className="font-medium">{existingResult.toleranceScore} / {SECTION_MAX.tolerance}</span>
            </div>
            <Progress value={(existingResult.toleranceScore / SECTION_MAX.tolerance) * 100} className="h-2" />

            <div className="flex items-center justify-between mt-3">
              <span className="text-muted-foreground">Goals & Life Circumstances</span>
              <span className="font-medium">{existingResult.goalsScore} / {SECTION_MAX.goals}</span>
            </div>
            <Progress value={(existingResult.goalsScore / SECTION_MAX.goals) * 100} className="h-2" />
          </div>

          <div className="pt-2 flex items-center justify-between border-t">
            <span className="text-sm font-medium">Total Score</span>
            <span className="text-lg font-semibold font-serif">{existingResult.totalScore} / 120</span>
          </div>

          <div className="text-xs text-muted-foreground text-center">
            Completed {existingResult.completedAt ? new Date(existingResult.completedAt).toLocaleDateString("en-ZA") : ""}
          </div>

          {!isAdvisor && (
            <Button
              variant="outline"
              size="sm"
              className="w-full mt-2"
              onClick={() => {
                setAnswers({});
                setCurrentStep(0);
                setShowResult(false);
                setStarted(true);
              }}
              data-testid="button-retake-questionnaire"
            >
              <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
              Retake Questionnaire
            </Button>
          )}
        </CardContent>
      </Card>
    );
  }

  if (!started) {
    return (
      <Card data-testid="card-risk-questionnaire">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="h-4 w-4" />
            Risk Profile Questionnaire
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-sm text-muted-foreground">
            This questionnaire helps determine your investment risk profile. It covers three areas: your financial safety net, how you feel about risk, and your goals. It takes about 5 minutes to complete.
          </div>
          <div className="flex gap-2 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-primary/60" />
              12 questions
            </div>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-primary/60" />
              3 sections
            </div>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-primary/60" />
              ~5 minutes
            </div>
          </div>
          {!isAdvisor && (
            <Button
              className="w-full"
              onClick={() => setStarted(true)}
              data-testid="button-start-questionnaire"
            >
              Start Questionnaire
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          )}
          {isAdvisor && (
            <div className="rounded-lg border border-dashed p-3 text-center text-sm text-muted-foreground">
              <AlertTriangle className="h-4 w-4 inline mr-1.5 -mt-0.5" />
              No questionnaire completed yet. The client can complete this from their dashboard.
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  if (showResult) {
    const capacityScore = QUESTIONS.filter(q => q.section === "capacity").reduce((sum, q) => sum + (answers[q.id] || 0), 0);
    const toleranceScore = QUESTIONS.filter(q => q.section === "tolerance").reduce((sum, q) => sum + (answers[q.id] || 0), 0);
    const goalsScore = QUESTIONS.filter(q => q.section === "goals").reduce((sum, q) => sum + (answers[q.id] || 0), 0);
    const totalScore = capacityScore + toleranceScore + goalsScore;
    const profileLabel = getProfileLabel(totalScore);
    const profileColor = getProfileColor(profileLabel);

    const handleSave = () => {
      saveQuestionnaire.mutate({
        clientId,
        data: {
          answers,
          capacityScore,
          toleranceScore,
          goalsScore,
          totalScore,
          profileLabel,
        },
      }, {
        onSuccess: () => {
          setStarted(false);
          setShowResult(false);
        },
      });
    };

    return (
      <Card data-testid="card-risk-questionnaire-result">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <CheckCircle className="h-4 w-4 text-primary" />
            Your Risk Profile Result
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center py-3">
            <div
              className="inline-block rounded-full px-6 py-2.5 text-white font-semibold text-xl"
              style={{ backgroundColor: profileColor }}
              data-testid="text-risk-result-label"
            >
              {profileLabel}
            </div>
            <div className="mt-3 text-sm text-muted-foreground max-w-md mx-auto">
              {getProfileDescription(profileLabel)}
            </div>
          </div>

          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Financial Safety Net</span>
              <span className="font-medium">{capacityScore} / {SECTION_MAX.capacity}</span>
            </div>
            <Progress value={(capacityScore / SECTION_MAX.capacity) * 100} className="h-2" />

            <div className="flex items-center justify-between mt-3">
              <span className="text-muted-foreground">Gut Feeling About Risk</span>
              <span className="font-medium">{toleranceScore} / {SECTION_MAX.tolerance}</span>
            </div>
            <Progress value={(toleranceScore / SECTION_MAX.tolerance) * 100} className="h-2" />

            <div className="flex items-center justify-between mt-3">
              <span className="text-muted-foreground">Goals & Life Circumstances</span>
              <span className="font-medium">{goalsScore} / {SECTION_MAX.goals}</span>
            </div>
            <Progress value={(goalsScore / SECTION_MAX.goals) * 100} className="h-2" />
          </div>

          <div className="pt-2 flex items-center justify-between border-t">
            <span className="text-sm font-medium">Total Score</span>
            <span className="text-lg font-semibold font-serif">{totalScore} / 120</span>
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => {
                setAnswers({});
                setCurrentStep(0);
                setShowResult(false);
              }}
              data-testid="button-retake"
            >
              <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
              Retake
            </Button>
            <Button
              className="flex-1"
              onClick={handleSave}
              disabled={saveQuestionnaire.isPending}
              data-testid="button-save-result"
            >
              {saveQuestionnaire.isPending ? "Saving..." : "Save My Profile"}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  const question = QUESTIONS[currentStep];
  const currentSection = question.section;
  const sectionQuestions = QUESTIONS.filter(q => q.section === currentSection);
  const sectionIndex = sectionQuestions.indexOf(question);
  const progress = ((currentStep + 1) / QUESTIONS.length) * 100;

  return (
    <Card data-testid="card-risk-questionnaire-active">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Shield className="h-3.5 w-3.5" />
            {SECTION_LABELS[currentSection]}
          </CardTitle>
          <span className="text-xs text-muted-foreground">
            {currentStep + 1} of {QUESTIONS.length}
          </span>
        </div>
        <Progress value={progress} className="h-1.5 mt-2" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm font-medium leading-relaxed" data-testid="text-question">
          {question.text}
        </div>

        <div className="space-y-2">
          {question.options.map((opt, idx) => {
            const isSelected = answers[question.id] === opt.value;
            return (
              <button
                key={idx}
                className={`w-full text-left rounded-lg border p-3 text-sm transition-all ${
                  isSelected
                    ? "border-primary bg-primary/10 ring-1 ring-primary/30"
                    : "border-border hover:border-primary/40 hover:bg-muted/50"
                }`}
                onClick={() => setAnswers(prev => ({ ...prev, [question.id]: opt.value }))}
                data-testid={`option-${question.id}-${idx}`}
              >
                {opt.label}
              </button>
            );
          })}
        </div>

        <div className="flex gap-2 pt-2">
          {currentStep > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentStep(s => s - 1)}
              data-testid="button-prev"
            >
              <ChevronLeft className="h-3.5 w-3.5 mr-1" />
              Back
            </Button>
          )}
          <Button
            size="sm"
            className="ml-auto"
            disabled={!answers[question.id]}
            onClick={() => {
              if (currentStep < QUESTIONS.length - 1) {
                setCurrentStep(s => s + 1);
              } else {
                setShowResult(true);
              }
            }}
            data-testid="button-next"
          >
            {currentStep < QUESTIONS.length - 1 ? (
              <>
                Next
                <ChevronRight className="h-3.5 w-3.5 ml-1" />
              </>
            ) : (
              "See My Result"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
