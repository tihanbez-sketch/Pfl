import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatZar } from "@/lib/plan4life/format";

type ParsedPortfolio = {
  reportTitle?: string;
  asOf?: string;
  totals?: {
    totalInvestments?: number;
    retirementFunds?: number;
    retirementAnnuities?: number;
    deathCover?: number;
  };
  holdings?: { name: string; value: number }[];
};

function parseElitePdfText(text: string): ParsedPortfolio {
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.replace(/\s+/g, " ").trim())
    .filter(Boolean);

  const joined = lines.join("\n");

  const reportTitle = lines.find((l) => /Portfolio Analysis/i.test(l)) ?? undefined;

  const asOfMatch = joined.match(/\b(\d{1,2}\s+[A-Za-z]+\s+\d{4})\b/);
  const asOf = asOfMatch?.[1];

  const grabNumber = (label: RegExp) => {
    const line = lines.find((l) => label.test(l));
    if (!line) return undefined;
    const m = line.match(/([0-9]{1,3}(?:\s[0-9]{3})+)/);
    if (!m) return undefined;
    return Number(m[1].replace(/\s/g, ""));
  };

  const totalInvestments = grabNumber(/^Total investments/i);
  const retirementFunds = grabNumber(/^Retirement funds/i);
  const retirementAnnuities = grabNumber(/^Retirement annuities/i);
  const deathCover = grabNumber(/^Death Cover/i);

  const holdings: { name: string; value: number }[] = [];
  const startIdx = lines.findIndex((l) => /Underlying values/i.test(l));
  if (startIdx >= 0) {
    for (let i = startIdx + 1; i < Math.min(lines.length, startIdx + 80); i++) {
      const l = lines[i];
      if (/Retirement Annuities/i.test(l) || /Risk Product/i.test(l)) break;
      const num = l.match(/([0-9]{1,3}(?:\s[0-9]{3})+)/g);
      if (!num || num.length < 1) continue;
      const amount = Number(num[num.length - 1].replace(/\s/g, ""));
      if (!Number.isFinite(amount) || amount <= 0) continue;
      const name = l.replace(/([0-9]{1,3}(?:\s[0-9]{3})+).*/, "").trim();
      if (name.length < 3) continue;
      holdings.push({ name, value: amount });
    }
  }

  return {
    reportTitle,
    asOf,
    totals: {
      totalInvestments,
      retirementFunds,
      retirementAnnuities,
      deathCover,
    },
    holdings: holdings.length ? holdings.slice(0, 12) : undefined,
  };
}

export function PortfolioUpload({
  onParsed,
}: {
  onParsed: (parsed: ParsedPortfolio) => void;
}) {
  const [fileName, setFileName] = React.useState<string | null>(null);
  const [status, setStatus] = React.useState<"idle" | "reading" | "parsed" | "error">("idle");
  const [parsed, setParsed] = React.useState<ParsedPortfolio | null>(null);

  const handleFile = async (file: File | null) => {
    if (!file) return;
    setFileName(file.name);
    setStatus("reading");

    try {
      const txt = await file.text();
      const p = parseElitePdfText(txt);
      setParsed(p);
      onParsed(p);
      setStatus("parsed");
    } catch {
      setStatus("error");
    }
  };

  return (
    <Card className="rounded-2xl p-4 shadow-sm p4l-noise" data-testid="card-portfolio-upload">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-sm font-medium" data-testid="text-upload-title">Portfolio report upload</div>
          <div className="mt-1 text-xs text-muted-foreground" data-testid="text-upload-subtitle">
            Upload a portfolio report to extract investment totals and holdings.
          </div>
        </div>
        <div className="text-xs text-muted-foreground" data-testid="text-upload-filename">
          {fileName ?? "No file"}
        </div>
      </div>

      <div className="mt-4 grid gap-3">
        <Input
          type="file"
          accept=".pdf,.txt"
          onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
          data-testid="input-portfolio-file"
        />

        <div className="rounded-xl border bg-background/60 p-3 text-xs text-muted-foreground" data-testid="text-upload-status">
          {status === "idle" && "Upload a PDF or exported text. For best results, export the PDF to text first."}
          {status === "reading" && "Reading file…"}
          {status === "parsed" && "Parsed key values (best-effort)."}
          {status === "error" && "Could not read this file in the browser. Try exporting to text."}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="outline"
            onClick={() => {
              const sampleText = `Portfolio Analysis\n\nMr WJ Rheeder\n\n22 March 2016\n\nSummary of Assurance and Investments\nRetirement funds 520 781\nRetirement annuities 319 407\nTOTAL: 840 188\nTotal investments: 840 188\nDeath Cover (Standard) 528 735\n\nUnderlying values\nCoronation Equity Fund R 148 396\nMomentum Top 25 Fund R 117 017\nOld Mutual Global Equity Fund R 74 706`;
              const p = parseElitePdfText(sampleText);
              setParsed(p);
              onParsed(p);
              setStatus("parsed");
              setFileName("sample-elite-report.txt");
            }}
            data-testid="button-use-sample-report"
          >
            Use sample report
          </Button>

          <div className="text-xs text-muted-foreground" data-testid="text-upload-note">
            Best results with text-exported PDF reports from Elite Wealth.
          </div>
        </div>

        {parsed?.totals && (
          <div className="mt-2 grid gap-2 rounded-2xl border bg-card p-3" data-testid="panel-parsed-totals">
            <div className="flex items-center justify-between">
              <div className="text-xs text-muted-foreground" data-testid="text-parsed-title">Parsed totals</div>
              <div className="text-xs text-muted-foreground" data-testid="text-parsed-asof">
                {parsed.asOf ? `As of ${parsed.asOf}` : ""}
              </div>
            </div>
            <div className="grid gap-1 text-sm">
              <div className="flex items-center justify-between" data-testid="row-parsed-total">
                <span className="text-muted-foreground" data-testid="label-parsed-total">Total investments</span>
                <span className="font-medium" data-testid="value-parsed-total">
                  {parsed.totals.totalInvestments != null ? formatZar(parsed.totals.totalInvestments) : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between" data-testid="row-parsed-ra">
                <span className="text-muted-foreground" data-testid="label-parsed-ra">Retirement annuities</span>
                <span className="font-medium" data-testid="value-parsed-ra">
                  {parsed.totals.retirementAnnuities != null ? formatZar(parsed.totals.retirementAnnuities) : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between" data-testid="row-parsed-rf">
                <span className="text-muted-foreground" data-testid="label-parsed-rf">Retirement funds</span>
                <span className="font-medium" data-testid="value-parsed-rf">
                  {parsed.totals.retirementFunds != null ? formatZar(parsed.totals.retirementFunds) : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between" data-testid="row-parsed-death">
                <span className="text-muted-foreground" data-testid="label-parsed-death">Death cover</span>
                <span className="font-medium" data-testid="value-parsed-death">
                  {parsed.totals.deathCover != null ? formatZar(parsed.totals.deathCover) : "—"}
                </span>
              </div>
            </div>

            {parsed.holdings?.length ? (
              <div className="mt-3 overflow-hidden rounded-xl border bg-background/60" data-testid="table-parsed-holdings">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Holding</TableHead>
                      <TableHead className="text-right">Value</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {parsed.holdings.map((h, idx) => (
                      <TableRow key={idx} data-testid={`row-parsed-holding-${idx}`}>
                        <TableCell data-testid={`text-parsed-holding-name-${idx}`}>{h.name}</TableCell>
                        <TableCell className="text-right" data-testid={`text-parsed-holding-value-${idx}`}>{formatZar(h.value)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : null}
          </div>
        )}
      </div>
    </Card>
  );
}
