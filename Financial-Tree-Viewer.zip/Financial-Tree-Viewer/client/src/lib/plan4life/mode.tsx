import React from "react";

export type AppMode = "advisor" | "client";

const ModeContext = React.createContext<{
  mode: AppMode;
  setMode: (m: AppMode) => void;
} | null>(null);

export function ModeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = React.useState<AppMode>("advisor");
  return (
    <ModeContext.Provider value={{ mode, setMode }}>
      {children}
    </ModeContext.Provider>
  );
}

export function useMode() {
  const ctx = React.useContext(ModeContext);
  if (!ctx) throw new Error("useMode must be used within ModeProvider");
  return ctx;
}
