export type EstateReadiness = "green" | "amber" | "red";

export type Holding = {
  id: string;
  name: string;
  ticker?: string;
  assetClass: "Equity" | "Balanced" | "Bond" | "Cash" | "Property";
  value: number;
  beneficiary?: string;
};

export type InvestmentAccount = {
  id: string;
  name: string;
  provider: string;
  type: "RA" | "TFSA" | "Unit Trust" | "Retirement Annuity" | "Other";
  holdings: Holding[];
};

export type Liability = {
  id: string;
  name: string;
  balance: number;
  interestRate?: number;
};

export type RiskCover = {
  life: number;
  disabilityIncomeMonthly: number;
  disabilityLumpSum: number;
  dreadDisease: number;
};

export type MedicalAid = {
  planName: string;
  gapCover: boolean;
};

export type EstatePlanning = {
  willStatus: "in_place" | "draft" | "none";
  executorNamed: boolean;
  beneficiaryAlignment: "aligned" | "partial" | "unknown";
  liquidityAdequate: boolean;
};

export type Documents = {
  ficaStatus: "complete" | "partial" | "missing";
  lastUpdatedISO: string;
};

export type Household = {
  annualSpend: number;
  monthlySpend: number;
  existingMonthlyIncome: number;
  liquidAssets: number;
};

export type TaxProgress = {
  raAnnualContribution: number;
  raAnnualLimit: number;
  tfsaContributionLifetime: number;
  tfsaLifetimeLimit: number;
};

export type Profile = {
  initials: string;
  idNumber: string;
  address: {
    home: string;
    postal: string;
  };
  contact: {
    cell: string;
    email: string;
  };
  tax: {
    reference: string;
    office: string;
  };
};

export type Client = {
  id: string;
  name: string;
  profile: Profile;
  age: number;
  maritalStatus: "Single" | "Married" | "Divorced" | "Widowed";
  household: Household;
  dependants: { id: string; name: string; age: number }[];
  investments: InvestmentAccount[];
  liabilities: Liability[];
  riskCover: RiskCover;
  medicalAid: MedicalAid;
  estate: EstatePlanning;
  documents: Documents;
  tax: TaxProgress;
  lastReviewISO: string;
};

export type Assumptions = {
  lifeCoverYearsToYoungest21: boolean;
  educationInflation: number;
  educationCostPrimary: number;
  educationCostHigh: number;
  educationCostTertiary: number;
  investmentReturnRate: number;
};
