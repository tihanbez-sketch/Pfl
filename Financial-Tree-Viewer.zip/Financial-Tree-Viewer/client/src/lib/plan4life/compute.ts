import type { Assumptions, Client, EstateReadiness } from "./types";
import { clamp } from "./format";

export function sumInvestments(client: Client) {
  return client.investments.reduce((acc, a) => {
    return acc + a.holdings.reduce((h, v) => h + v.value, 0);
  }, 0);
}

export function sumLiquidInvestments(client: Client) {
  const liquidTypes = new Set(["TFSA", "Unit Trust", "Other"]);
  return client.investments.reduce((acc, a) => {
    if (!liquidTypes.has(a.type)) return acc;
    return acc + a.holdings.reduce((h, v) => h + v.value, 0);
  }, 0);
}

export function sumLiabilities(client: Client) {
  return client.liabilities.reduce((acc, l) => acc + l.balance, 0);
}

export function netWorth(client: Client) {
  return sumInvestments(client) + client.household.liquidAssets - sumLiabilities(client);
}

export function youngestDependantAge(client: Client) {
  if (!client.dependants.length) return null;
  return Math.min(...client.dependants.map((d) => d.age));
}

export function yearsToYoungest21(client: Client) {
  const y = youngestDependantAge(client);
  if (y === null) return 0;
  return Math.max(0, 21 - y);
}

export function requiredLifeCover(client: Client, assumptions: Assumptions, overrides?: { annualSpend?: number }) {
  const annualSpend = overrides?.annualSpend ?? client.household.annualSpend;
  const years = assumptions.lifeCoverYearsToYoungest21 ? yearsToYoungest21(client) : 10;
  const liab = sumLiabilities(client);
  const liquid = sumLiquidInvestments(client) + client.household.liquidAssets;
  return Math.max(0, annualSpend * years + liab - liquid);
}

export function disabilityIncomeRequiredMonthly(client: Client, overrides?: { monthlySpend?: number; existingMonthlyIncome?: number }) {
  const monthlySpend = overrides?.monthlySpend ?? client.household.monthlySpend;
  const existingIncome = overrides?.existingMonthlyIncome ?? client.household.existingMonthlyIncome;
  return Math.max(0, monthlySpend - existingIncome);
}

export function educationStage(age: number) {
  if (age <= 6) return "primary";
  if (age <= 13) return "high";
  return "tertiary";
}

export function educationCostPerChildAnnual(
  childAge: number,
  assumptions: Assumptions,
  overrides?: { inflation?: number; primary?: number; high?: number; tertiary?: number },
) {
  const inflation = overrides?.inflation ?? assumptions.educationInflation;
  const primary = overrides?.primary ?? assumptions.educationCostPrimary;
  const high = overrides?.high ?? assumptions.educationCostHigh;
  const tertiary = overrides?.tertiary ?? assumptions.educationCostTertiary;

  const stage = educationStage(childAge);
  const base = stage === "primary" ? primary : stage === "high" ? high : tertiary;
  return { stage, annual: Math.round(base * (1 + inflation)) };
}

export type EducationFundingResult = {
  childName: string;
  childAge: number;
  yearsRemaining: number;
  breakdown: { year: number; age: number; stage: string; cost: number }[];
  totalFutureCost: number;
  presentValue: number;
  monthlySavingsNeeded: number;
};

export function educationFundingPlan(
  child: { name: string; age: number },
  costs: { primary: number; high: number; tertiary: number },
  eduInflation: number,
  investReturnRate: number,
): EducationFundingResult {
  const endAge = 22;
  const yearsRemaining = Math.max(0, endAge - child.age);

  const breakdown: { year: number; age: number; stage: string; cost: number }[] = [];
  let totalFutureCost = 0;
  let presentValue = 0;

  for (let y = 0; y < yearsRemaining; y++) {
    const futureAge = child.age + y + 1;
    let stage: string;
    let baseCost: number;

    if (futureAge <= 7) {
      stage = "Primary";
      baseCost = costs.primary;
    } else if (futureAge <= 13) {
      stage = "High School";
      baseCost = costs.high;
    } else if (futureAge <= 22) {
      stage = "Tertiary";
      baseCost = costs.tertiary;
    } else {
      continue;
    }

    const futureCost = Math.round(baseCost * Math.pow(1 + eduInflation, y + 1));
    const pv = futureCost / Math.pow(1 + investReturnRate, y + 1);

    breakdown.push({ year: y + 1, age: futureAge, stage, cost: futureCost });
    totalFutureCost += futureCost;
    presentValue += pv;
  }

  presentValue = Math.round(presentValue);

  let monthlySavingsNeeded = 0;
  if (yearsRemaining > 0 && investReturnRate > 0) {
    const monthlyRate = investReturnRate / 12;
    const months = yearsRemaining * 12;
    const fvAnnuity = (Math.pow(1 + monthlyRate, months) - 1) / monthlyRate;
    const fvTarget = totalFutureCost;
    monthlySavingsNeeded = Math.round(fvTarget / fvAnnuity);
  } else if (yearsRemaining > 0) {
    monthlySavingsNeeded = Math.round(totalFutureCost / (yearsRemaining * 12));
  }

  return {
    childName: child.name,
    childAge: child.age,
    yearsRemaining,
    breakdown,
    totalFutureCost,
    presentValue,
    monthlySavingsNeeded,
  };
}

export function estateReadinessScore(client: Client) {
  let score = 0;
  if (client.estate.willStatus === "in_place") score += 40;
  if (client.estate.executorNamed) score += 20;
  if (client.estate.beneficiaryAlignment === "aligned") score += 25;
  if (client.estate.liquidityAdequate) score += 15;
  return clamp(score, 0, 100);
}

export function estateReadinessBadge(client: Client): EstateReadiness {
  const score = estateReadinessScore(client);
  if (score >= 75) return "green";
  if (score >= 45) return "amber";
  return "red";
}

export function riskAdequacyScore(
  client: Client,
  assumptions: Assumptions,
  overrides?: {
    annualSpend?: number;
    monthlySpend?: number;
    existingMonthlyIncome?: number;
  },
) {
  const reqLife = requiredLifeCover(client, assumptions, { annualSpend: overrides?.annualSpend });
  const reqDisIncome = disabilityIncomeRequiredMonthly(client, {
    monthlySpend: overrides?.monthlySpend,
    existingMonthlyIncome: overrides?.existingMonthlyIncome,
  });

  const lifeShortfall = Math.max(0, reqLife - client.riskCover.life);
  const disIncShortfall = Math.max(0, reqDisIncome - client.riskCover.disabilityIncomeMonthly);

  const dreadTarget = (overrides?.annualSpend ?? client.household.annualSpend) * 2;
  const dreadShortfall = Math.max(0, dreadTarget - client.riskCover.dreadDisease);

  const penalty =
    (lifeShortfall > 0 ? 45 : 0) +
    (disIncShortfall > 0 ? 35 : 0) +
    (dreadShortfall > 0 ? 20 : 0);

  return clamp(100 - penalty, 0, 100);
}

export function riskHasShortfall(client: Client, assumptions: Assumptions) {
  const score = riskAdequacyScore(client, assumptions);
  return score < 80;
}

export function reviewDue(client: Client, nowISO = new Date().toISOString()) {
  const now = new Date(nowISO);
  const last = new Date(client.lastReviewISO);
  if (Number.isNaN(now.getTime()) || Number.isNaN(last.getTime())) return false;
  const months = (now.getFullYear() * 12 + now.getMonth()) - (last.getFullYear() * 12 + last.getMonth());
  return months >= 12;
}

export function ficaDue(client: Client, nowISO = new Date().toISOString()) {
  if (client.documents.ficaStatus !== "complete") return true;
  const now = new Date(nowISO);
  const last = new Date(client.documents.lastUpdatedISO);
  if (Number.isNaN(now.getTime()) || Number.isNaN(last.getTime())) return true;
  const months = (now.getFullYear() * 12 + now.getMonth()) - (last.getFullYear() * 12 + last.getMonth());
  return months >= 24;
}

export function aum(client: Client) {
  return sumInvestments(client);
}

export function treeBranchStatuses(client: Client, assumptions: Assumptions) {
  const invest = sumInvestments(client);
  const investStatus: EstateReadiness = invest >= 1500000 ? "green" : invest >= 600000 ? "amber" : "red";

  const riskScore = riskAdequacyScore(client, assumptions);
  const riskStatus: EstateReadiness = riskScore >= 80 ? "green" : riskScore >= 55 ? "amber" : "red";

  const estateStatus = estateReadinessBadge(client);

  const raPct = client.tax.raAnnualLimit > 0 ? client.tax.raAnnualContribution / client.tax.raAnnualLimit : 0;
  const tfsaPct = client.tax.tfsaLifetimeLimit > 0 ? client.tax.tfsaContributionLifetime / client.tax.tfsaLifetimeLimit : 0;
  const taxAvg = (raPct + tfsaPct) / 2;
  const taxStatus: EstateReadiness = taxAvg >= 0.7 ? "green" : taxAvg >= 0.35 ? "amber" : "red";

  const budgetStatus: EstateReadiness = client.household.monthlySpend <= 0 ? "red" : "amber";

  return {
    investments: investStatus,
    risk: riskStatus,
    estate: estateStatus,
    tax: taxStatus,
    budgeting: budgetStatus,
  };
}
