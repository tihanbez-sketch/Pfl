export type LifeStageId =
  | "starting_out"
  | "family_building"
  | "wealth_accumulation"
  | "pre_retirement"
  | "retirement";

export type LifeStageDefinition = {
  id: LifeStageId;
  name: string;
  summary: string;
  focusAreas: { id: string; label: string; hint: string }[];
};

export const lifeStages: LifeStageDefinition[] = [
  {
    id: "starting_out",
    name: "Starting Out",
    summary: "Build foundations: protection, emergency fund, and clean cashflow.",
    focusAreas: [
      {
        id: "budget",
        label: "Budget & Cashflow",
        hint: "Know your monthly burn, start an emergency fund.",
      },
      {
        id: "risk",
        label: "Core Risk Cover",
        hint: "Protect income and liabilities early.",
      },
      {
        id: "tax",
        label: "Start TFSA",
        hint: "Build tax-free compounding habit.",
      },
    ],
  },
  {
    id: "family_building",
    name: "Family Building",
    summary: "Protect dependants and fund education while investing consistently.",
    focusAreas: [
      {
        id: "life",
        label: "Life Cover Adequacy",
        hint: "Cover years to youngest 21 and liabilities.",
      },
      {
        id: "education",
        label: "Education Funding",
        hint: "Estimate costs per child and plan funding gap.",
      },
      {
        id: "estate",
        label: "Estate Basics",
        hint: "Will, executor, beneficiary alignment.",
      },
    ],
  },
  {
    id: "wealth_accumulation",
    name: "Wealth Accumulation",
    summary: "Optimise investments, tax efficiency, and longer-term goals.",
    focusAreas: [
      {
        id: "invest",
        label: "Portfolio Strategy",
        hint: "Review allocation and contribution discipline.",
      },
      {
        id: "tax",
        label: "RA / TFSA Optimisation",
        hint: "Track progress to limits and efficiency.",
      },
      {
        id: "estate",
        label: "Estate Planning Depth",
        hint: "Liquidity, guardianship, trust considerations.",
      },
    ],
  },
  {
    id: "pre_retirement",
    name: "Pre‑Retirement",
    summary: "Shift to outcomes: retirement income plan, de-risking, estate readiness.",
    focusAreas: [
      {
        id: "retirement",
        label: "Retirement Income Plan",
        hint: "Project drawdown and sustainability.",
      },
      {
        id: "risk",
        label: "Protection Review",
        hint: "Reduce overlaps and keep catastrophic risks covered.",
      },
      {
        id: "estate",
        label: "Estate Liquidity",
        hint: "Ensure cash to pay fees and taxes.",
      },
    ],
  },
  {
    id: "retirement",
    name: "Retirement",
    summary: "Maintain income, manage healthcare, and simplify estate execution.",
    focusAreas: [
      {
        id: "income",
        label: "Income & Budgeting",
        hint: "Align spend to reliable income streams.",
      },
      {
        id: "medical",
        label: "Medical & Gap Cover",
        hint: "Reassess plan and gap cover suitability.",
      },
      {
        id: "estate",
        label: "Executor & Beneficiaries",
        hint: "Keep documents up to date and accessible.",
      },
    ],
  },
];

export function defaultLifeStageForAge(age: number): LifeStageId {
  if (age <= 28) return "starting_out";
  if (age <= 40) return "family_building";
  if (age <= 52) return "wealth_accumulation";
  if (age <= 62) return "pre_retirement";
  return "retirement";
}
