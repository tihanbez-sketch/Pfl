import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type { Client } from "./types";

async function apiFetch<T>(url: string, opts?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.message || `API error ${res.status}`);
  }
  return res.json();
}

export function useClients() {
  return useQuery<Client[]>({
    queryKey: ["/api/clients"],
    queryFn: () => apiFetch<Client[]>("/api/clients"),
  });
}

export function useClient(id: string) {
  return useQuery<Client>({
    queryKey: ["/api/clients", id],
    queryFn: () => apiFetch<Client>(`/api/clients/${id}`),
  });
}

export function useUpdateClient() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: Record<string, any> }) =>
      apiFetch(`/api/clients/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["/api/clients", vars.id] });
      qc.invalidateQueries({ queryKey: ["/api/clients"] });
    },
  });
}

export function useSaveBulkAssets() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ clientId, assets }: { clientId: string; assets: any[] }) =>
      apiFetch(`/api/clients/${clientId}/assets/bulk`, {
        method: "PUT",
        body: JSON.stringify({ assets }),
      }),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["/api/clients", vars.clientId] });
      qc.invalidateQueries({ queryKey: ["/api/clients"] });
    },
  });
}

export function useSaveBulkLiabilities() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ clientId, liabilities }: { clientId: string; liabilities: any[] }) =>
      apiFetch(`/api/clients/${clientId}/liabilities/bulk`, {
        method: "PUT",
        body: JSON.stringify({ liabilities }),
      }),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["/api/clients", vars.clientId] });
      qc.invalidateQueries({ queryKey: ["/api/clients"] });
    },
  });
}

export function useCreateMeetingRequest() {
  return useMutation({
    mutationFn: (data: { clientId: string; preferredDate: string; preferredTime: string; reason: string }) =>
      apiFetch("/api/meetings", { method: "POST", body: JSON.stringify(data) }),
  });
}

export function useUpsertDependant() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { id: string; clientId: string; name: string; age: number }) =>
      apiFetch(`/api/dependants/${data.id}`, { method: "PUT", body: JSON.stringify(data) }),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["/api/clients", vars.clientId] });
      qc.invalidateQueries({ queryKey: ["/api/clients"] });
    },
  });
}

export function useDeleteDependant() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, clientId }: { id: string; clientId: string }) =>
      apiFetch(`/api/dependants/${id}`, { method: "DELETE" }),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["/api/clients", vars.clientId] });
      qc.invalidateQueries({ queryKey: ["/api/clients"] });
    },
  });
}

export function useRiskQuestionnaire(clientId: string) {
  return useQuery<any>({
    queryKey: ["/api/clients", clientId, "risk-questionnaire"],
    queryFn: () => apiFetch(`/api/clients/${clientId}/risk-questionnaire`),
    enabled: !!clientId,
  });
}

export function useSaveRiskQuestionnaire() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ clientId, data }: { clientId: string; data: any }) =>
      apiFetch(`/api/clients/${clientId}/risk-questionnaire`, {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["/api/clients", vars.clientId, "risk-questionnaire"] });
    },
  });
}
