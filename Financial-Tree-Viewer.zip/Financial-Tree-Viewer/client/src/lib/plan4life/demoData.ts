import type { Assumptions, Client } from "./types";

export const defaultAssumptions: Assumptions = {
  lifeCoverYearsToYoungest21: true,
  educationInflation: 0.06,
  educationCostPrimary: 65000,
  educationCostHigh: 110000,
  educationCostTertiary: 165000,
  investmentReturnRate: 0.08,
};

export const demoClients: Client[] = [
  {
    id: "c-004",
    name: "Tihan Benjamin Bezuidenhout",
    profile: {
      initials: "TB",
      idNumber: "8902015173080",
      address: {
        home: "172 Venice Road, Morningside, Durban, 7001, South Africa",
        postal: "172 Venice Road, Morningside, Durban, 7001, South Africa",
      },
      contact: {
        cell: "+27 82 857 0776",
        email: "tihan@pfl.co.za",
      },
      tax: {
        reference: "2916132166",
        office: "Durban",
      },
    },
    age: 37,
    maritalStatus: "Single",
    household: {
      annualSpend: 180000, // Derived from 15k monthly
      monthlySpend: 15000,
      existingMonthlyIncome: 55000, // Estimated from assets/lifestyle
      liquidAssets: 126000, // Cash holdings roughly
    },
    dependants: [], // None listed in FNA clearly
    investments: [
      {
        id: "inv-t01",
        name: "Ninety One RA",
        provider: "Ninety One",
        type: "RA",
        holdings: [
          { id: "h-t01", name: "Fund 1 (Living Annuity)", assetClass: "Balanced", value: 1050233 },
          { id: "h-t02", name: "Fund 2 (Living Annuity)", assetClass: "Balanced", value: 212596 },
        ],
      },
      {
        id: "inv-t02",
        name: "Ninety One TFSA",
        provider: "Ninety One",
        type: "TFSA",
        holdings: [
          { id: "h-t03", name: "TFSA 1", assetClass: "Equity", value: 134 },
          { id: "h-t04", name: "TFSA 2", assetClass: "Equity", value: 11372 },
        ],
      },
      {
        id: "inv-t03",
        name: "Other Assets (PFL/Megafin)",
        provider: "Private",
        type: "Other",
        holdings: [
          { id: "h-t05", name: "Megafin", assetClass: "Property", value: 1000000 },
          { id: "h-t06", name: "PFL", assetClass: "Equity", value: 1200000 },
        ],
      },
    ],
    liabilities: [
      { id: "l-t01", name: "Car Finance", balance: 150000, interestRate: 0.12 },
      { id: "l-t02", name: "Credit Cards", balance: 150000, interestRate: 0.18 },
    ],
    riskCover: {
      life: 1810000, // Alexander Forbes
      disabilityIncomeMonthly: 0,
      disabilityLumpSum: 0,
      dreadDisease: 0,
    },
    medicalAid: { planName: "Discovery Health", gapCover: false },
    estate: {
      willStatus: "in_place", // Implied by detailed calc
      executorNamed: true,
      beneficiaryAlignment: "aligned",
      liquidityAdequate: true, // Surplus 931k
    },
    documents: { ficaStatus: "complete", lastUpdatedISO: "2026-02-07" },
    tax: {
      raAnnualContribution: 0,
      raAnnualLimit: 350000,
      tfsaContributionLifetime: 11506,
      tfsaLifetimeLimit: 500000,
    },
    lastReviewISO: "2026-02-07",
  },
  {
    id: "c-001",
    name: "Thabo Mokoena",
    profile: {
      initials: "TM",
      idNumber: "8405235899081",
      address: {
        home: "42 Sandton Drive, Johannesburg",
        postal: "PO Box 123, Sandton",
      },
      contact: {
        cell: "082 555 1234",
        email: "thabo.m@example.com",
      },
      tax: {
        reference: "1234567890",
        office: "SARS Sandton",
      },
    },
    age: 41,
    maritalStatus: "Married",
    household: {
      annualSpend: 540000,
      monthlySpend: 45000,
      existingMonthlyIncome: 18000,
      liquidAssets: 220000,
    },
    dependants: [
      { id: "d-001", name: "Lerato", age: 12 },
      { id: "d-002", name: "Neo", age: 7 },
    ],
    investments: [
      {
        id: "inv-001",
        name: "Retirement Annuity",
        provider: "Allan Gray",
        type: "RA",
        holdings: [
          {
            id: "h-001",
            name: "Balanced Fund",
            assetClass: "Balanced",
            value: 1250000,
          },
          {
            id: "h-002",
            name: "Equity Fund",
            assetClass: "Equity",
            value: 640000,
          },
        ],
      },
      {
        id: "inv-002",
        name: "Tax Free Savings",
        provider: "EasyEquities",
        type: "TFSA",
        holdings: [
          {
            id: "h-003",
            name: "SA Equity ETF",
            ticker: "STX40",
            assetClass: "Equity",
            value: 210000,
          },
          {
            id: "h-004",
            name: "Cash",
            assetClass: "Cash",
            value: 35000,
          },
        ],
      },
    ],
    liabilities: [
      { id: "l-001", name: "Home Loan", balance: 1450000, interestRate: 0.115 },
      { id: "l-002", name: "Vehicle Finance", balance: 210000, interestRate: 0.135 },
    ],
    riskCover: {
      life: 2500000,
      disabilityIncomeMonthly: 20000,
      disabilityLumpSum: 750000,
      dreadDisease: 300000,
    },
    medicalAid: { planName: "Discovery Classic Comprehensive", gapCover: true },
    estate: {
      willStatus: "draft",
      executorNamed: false,
      beneficiaryAlignment: "partial",
      liquidityAdequate: false,
    },
    documents: { ficaStatus: "partial", lastUpdatedISO: "2025-07-14" },
    tax: {
      raAnnualContribution: 96000,
      raAnnualLimit: 350000,
      tfsaContributionLifetime: 240000,
      tfsaLifetimeLimit: 500000,
    },
    lastReviewISO: "2024-11-02",
  },
  {
    id: "c-002",
    name: "Ayesha Patel",
    profile: {
      initials: "AP",
      idNumber: "9009120055088",
      address: {
        home: "15 Marine Parade, Durban",
        postal: "PO Box 44, Durban",
      },
      contact: {
        cell: "083 444 9876",
        email: "ayesha.p@example.com",
      },
      tax: {
        reference: "9876543210",
        office: "SARS Durban",
      },
    },
    age: 35,
    maritalStatus: "Single",
    household: {
      annualSpend: 360000,
      monthlySpend: 30000,
      existingMonthlyIncome: 12000,
      liquidAssets: 480000,
    },
    dependants: [{ id: "d-003", name: "Zara", age: 4 }],
    investments: [
      {
        id: "inv-003",
        name: "Unit Trust",
        provider: "Coronation",
        type: "Unit Trust",
        holdings: [
          { id: "h-005", name: "Balanced Plus", assetClass: "Balanced", value: 520000 },
          { id: "h-006", name: "Bond Fund", assetClass: "Bond", value: 140000 },
        ],
      },
    ],
    liabilities: [{ id: "l-003", name: "Home Loan", balance: 980000, interestRate: 0.112 }],
    riskCover: {
      life: 1800000,
      disabilityIncomeMonthly: 15000,
      disabilityLumpSum: 500000,
      dreadDisease: 500000,
    },
    medicalAid: { planName: "Bonitas BonComprehensive", gapCover: false },
    estate: {
      willStatus: "in_place",
      executorNamed: true,
      beneficiaryAlignment: "aligned",
      liquidityAdequate: true,
    },
    documents: { ficaStatus: "complete", lastUpdatedISO: "2025-10-01" },
    tax: {
      raAnnualContribution: 42000,
      raAnnualLimit: 350000,
      tfsaContributionLifetime: 320000,
      tfsaLifetimeLimit: 500000,
    },
    lastReviewISO: "2025-08-21",
  },
  {
    id: "c-003",
    name: "Johan van der Merwe",
    profile: {
      initials: "JJ",
      idNumber: "6701015099087",
      address: {
        home: "88 Church Street, Pretoria",
        postal: "PO Box 99, Pretoria",
      },
      contact: {
        cell: "082 111 2233",
        email: "johan.vdm@example.com",
      },
      tax: {
        reference: "5555555555",
        office: "SARS Pretoria",
      },
    },
    age: 58,
    maritalStatus: "Married",
    household: {
      annualSpend: 720000,
      monthlySpend: 60000,
      existingMonthlyIncome: 28000,
      liquidAssets: 900000,
    },
    dependants: [],
    investments: [
      {
        id: "inv-004",
        name: "Retirement Annuity",
        provider: "Sanlam",
        type: "Retirement Annuity",
        holdings: [
          { id: "h-007", name: "Balanced Fund", assetClass: "Balanced", value: 2100000 },
          { id: "h-008", name: "Property Fund", assetClass: "Property", value: 410000 },
        ],
      },
      {
        id: "inv-005",
        name: "Investment Account",
        provider: "Ninety One",
        type: "Other",
        holdings: [
          { id: "h-009", name: "Global Equity", assetClass: "Equity", value: 980000 },
          { id: "h-010", name: "Cash", assetClass: "Cash", value: 120000 },
        ],
      },
    ],
    liabilities: [{ id: "l-004", name: "Vehicle Finance", balance: 140000, interestRate: 0.138 }],
    riskCover: {
      life: 1200000,
      disabilityIncomeMonthly: 10000,
      disabilityLumpSum: 250000,
      dreadDisease: 200000,
    },
    medicalAid: { planName: "Momentum Ingwe", gapCover: true },
    estate: {
      willStatus: "none",
      executorNamed: false,
      beneficiaryAlignment: "unknown",
      liquidityAdequate: false,
    },
    documents: { ficaStatus: "missing", lastUpdatedISO: "2024-01-08" },
    tax: {
      raAnnualContribution: 0,
      raAnnualLimit: 350000,
      tfsaContributionLifetime: 480000,
      tfsaLifetimeLimit: 500000,
    },
    lastReviewISO: "2024-02-15",
  },
];
