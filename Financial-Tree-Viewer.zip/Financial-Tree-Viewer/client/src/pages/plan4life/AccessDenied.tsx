import { Shield, LogOut, TreePine } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function AccessDenied({ email }: { email?: string | null }) {
  return (
    <div
      className="min-h-dvh bg-gradient-to-br from-[hsl(40_30%_95%)] via-background to-[hsl(82_15%_95%)] dark:from-[hsl(158_18%_8%)] dark:via-background dark:to-[hsl(82_12%_10%)] flex items-center justify-center px-4"
      data-testid="page-access-denied"
    >
      <Card className="max-w-md w-full rounded-2xl border bg-card/90 p-8 shadow-xl backdrop-blur-sm text-center" data-testid="card-access-denied">
        <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl border bg-card shadow-sm">
          <TreePine className="h-7 w-7 text-primary" />
        </div>

        <h1 className="font-serif text-2xl font-semibold tracking-tight" data-testid="text-access-denied-title">
          Access Pending
        </h1>

        <div className="mt-3 flex items-center justify-center gap-2">
          <Shield className="h-4 w-4 text-muted-foreground" />
          <p className="text-sm text-muted-foreground" data-testid="text-access-denied-email">
            {email || "Your account"}
          </p>
        </div>

        <p className="mt-4 text-sm leading-relaxed text-muted-foreground" data-testid="text-access-denied-message">
          Your account has been created, but an advisor needs to grant you access before you can use the portal. Please contact your financial advisor to activate your account.
        </p>

        <div className="mt-6">
          <a href="/api/logout" data-testid="button-access-denied-logout">
            <Button variant="outline" className="gap-2">
              <LogOut className="h-4 w-4" />
              Sign out
            </Button>
          </a>
        </div>

        <p className="mt-6 text-[11px] text-muted-foreground/60">
          Secured portal for PFL Financial Advisors
        </p>
      </Card>
    </div>
  );
}
