import React from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { defaultAssumptions } from "@/lib/plan4life/demoData";
import { useClient } from "@/lib/plan4life/api";
import type { Assumptions, Client } from "@/lib/plan4life/types";
import {
  disabilityIncomeRequiredMonthly,
  educationCostPerChildAnnual,
  educationFundingPlan,
  estateReadinessBadge,
  estateReadinessScore,
  netWorth,
  requiredLifeCover,
  riskAdequacyScore,
  sumInvestments,
  sumLiabilities,
  treeBranchStatuses,
} from "@/lib/plan4life/compute";
import { formatDate, formatZar } from "@/lib/plan4life/format";
import { useMode } from "@/lib/plan4life/mode";
import { ScorePill } from "@/components/plan4life/ScorePill";
import { TreeViz } from "@/components/plan4life/TreeViz";
import { PortfolioUpload } from "@/components/plan4life/PortfolioUpload";
import { LifeStagePanel } from "@/components/plan4life/LifeStagePanel";
import { EstateDetail } from "@/components/plan4life/EstateDetail";
import { ScenarioPlanner } from "@/components/plan4life/ScenarioPlanner";
import { ClientOnboardingPanel } from "@/components/plan4life/ClientOnboardingPanel";
import { MeetingRequestPanel } from "@/components/plan4life/MeetingRequestPanel";
import { ClientToolsPanel } from "@/components/plan4life/ClientToolsPanel";
import { ClientProfilePanel } from "@/components/plan4life/ClientProfilePanel";
import { ClientAssetsLiabilitiesPanel } from "@/components/plan4life/ClientAssetsLiabilitiesPanel";
import { DependantsPanel } from "@/components/plan4life/DependantsPanel";
import { EstateEditor } from "@/components/plan4life/EstateEditor";
import { RiskQuestionnaire } from "@/components/plan4life/RiskQuestionnaire";
import { ArrowLeft, Printer } from "lucide-react";

function toneFromScore(score: number) {
  if (score >= 75) return "green" as const;
  if (score >= 45) return "amber" as const;
  return "red" as const;
}

function actionItems(client: Client, assumptions: Assumptions, overrides: Overrides) {
  const items: string[] = [];
  const estate = estateReadinessBadge(client);
  if (client.estate.willStatus === "none") items.push("Draft and sign a will");
  if (!client.estate.executorNamed) items.push("Confirm executor appointment");
  if (!client.estate.liquidityAdequate) items.push("Review estate liquidity and funding");
  if (client.documents.ficaStatus !== "complete") items.push("Complete FICA documentation");

  const reqLife = requiredLifeCover(client, assumptions, { annualSpend: overrides.annualSpend });
  if (reqLife > client.riskCover.life) items.push("Address life cover shortfall");

  const reqDi = disabilityIncomeRequiredMonthly(client, {
    monthlySpend: overrides.monthlySpend,
    existingMonthlyIncome: overrides.existingMonthlyIncome,
  });
  if (reqDi > client.riskCover.disabilityIncomeMonthly) items.push("Address disability income shortfall");

  const dreadTarget = (overrides.annualSpend ?? client.household.annualSpend) * 2;
  if (dreadTarget > client.riskCover.dreadDisease) items.push("Consider increasing dread disease cover");

  if (estate === "red") items.push("Prioritise estate readiness actions");

  return items.length ? items : ["No critical action items at this time"];
}

type Overrides = {
  annualSpend?: number;
  monthlySpend?: number;
  existingMonthlyIncome?: number;
  educationInflation?: number;
  educationCostPrimary?: number;
  educationCostHigh?: number;
  educationCostTertiary?: number;
  investmentReturnRate?: number;
};

function PrintSummary({
  client,
  assumptions,
  overrides,
  onClose,
}: {
  client: Client;
  assumptions: Assumptions;
  overrides: Overrides;
  onClose: () => void;
}) {
  const inv = sumInvestments(client);
  const nw = netWorth(client);
  const risk = riskAdequacyScore(client, assumptions, overrides);
  const estateScore = estateReadinessScore(client);
  const branches = treeBranchStatuses(client, assumptions);
  const items = actionItems(client, assumptions, overrides).slice(0, 5);

  return (
    <div className="fixed inset-0 z-50 bg-black/40 p-4 backdrop-blur-sm print-area" data-testid="modal-print">
      <div className="mx-auto w-full max-w-3xl overflow-hidden rounded-2xl border bg-card shadow-xl">
        <div className="flex items-center justify-between border-b px-5 py-3 no-print">
          <div>
            <div className="font-medium" data-testid="text-print-title">Review Summary</div>
            <div className="text-xs text-muted-foreground" data-testid="text-print-subtitle">
              One-page financial overview
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={() => window.print()} data-testid="button-print">
              Print
            </Button>
            <Button variant="outline" onClick={onClose} data-testid="button-close-print">
              Close
            </Button>
          </div>
        </div>

        <div className="p-6">
          <div className="flex items-start justify-between gap-6">
            <div>
              <div className="font-serif text-2xl font-semibold" data-testid="text-print-client">
                {client.name}
              </div>
              <div className="mt-1 text-sm text-muted-foreground" data-testid="text-print-meta">
                {client.age} · {client.maritalStatus} · Last review: {formatDate(client.lastReviewISO)}
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted-foreground" data-testid="text-print-brand">
                Plan4Life Financial Advisors
              </div>
              <div className="text-xs text-muted-foreground" data-testid="text-print-slogan">
                Planning Your Path
              </div>
            </div>
          </div>

          <div className="mt-5 grid gap-3 md:grid-cols-4">
            <div className="rounded-xl border bg-background/60 p-3" data-testid="print-stat-networth">
              <div className="text-[11px] text-muted-foreground" data-testid="print-label-networth">Net worth</div>
              <div className="mt-1 font-semibold" data-testid="print-value-networth">{formatZar(nw)}</div>
            </div>
            <div className="rounded-xl border bg-background/60 p-3" data-testid="print-stat-investments">
              <div className="text-[11px] text-muted-foreground" data-testid="print-label-investments">Investments</div>
              <div className="mt-1 font-semibold" data-testid="print-value-investments">{formatZar(inv)}</div>
            </div>
            <div className="rounded-xl border bg-background/60 p-3" data-testid="print-stat-risk">
              <div className="text-[11px] text-muted-foreground" data-testid="print-label-risk">Risk adequacy</div>
              <div className="mt-1 font-semibold" data-testid="print-value-risk">{risk}/100</div>
            </div>
            <div className="rounded-xl border bg-background/60 p-3" data-testid="print-stat-estate">
              <div className="text-[11px] text-muted-foreground" data-testid="print-label-estate">Estate readiness</div>
              <div className="mt-1 font-semibold" data-testid="print-value-estate">{estateScore}/100</div>
            </div>
          </div>

          <div className="mt-5 rounded-2xl border bg-background/60 p-4" data-testid="print-tree-status">
            <div className="text-sm font-medium" data-testid="text-print-tree">Module status</div>
            <div className="mt-2 grid gap-2 md:grid-cols-5 text-xs">
              {(
                [
                  ["Investments", branches.investments],
                  ["Risk", branches.risk],
                  ["Estate", branches.estate],
                  ["Tax", branches.tax],
                  ["Budget", branches.budgeting],
                ] as const
              ).map(([k, v]) => (
                <div key={k} className="flex items-center justify-between rounded-xl border bg-card px-3 py-2" data-testid={`print-row-${k.toLowerCase()}`}>
                  <span className="text-muted-foreground" data-testid={`print-label-${k.toLowerCase()}`}>{k}</span>
                  <span className="font-medium" data-testid={`print-value-${k.toLowerCase()}`}>{v}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-5 grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl border bg-card p-4" data-testid="print-actions">
              <div className="text-sm font-medium" data-testid="text-print-actions">Action items</div>
              <ul className="mt-3 list-disc space-y-1 pl-5 text-sm" data-testid="list-action-items">
                {items.map((it, idx) => (
                  <li key={idx} data-testid={`item-action-${idx}`}>{it}</li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border bg-card p-4" data-testid="print-assumptions">
              <div className="text-sm font-medium" data-testid="text-print-assumptions">Assumptions</div>
              <div className="mt-3 space-y-2 text-sm text-muted-foreground">
                <div data-testid="text-assumption-annual">Annual spend: {formatZar(overrides.annualSpend ?? client.household.annualSpend)}</div>
                <div data-testid="text-assumption-monthly">Monthly spend: {formatZar(overrides.monthlySpend ?? client.household.monthlySpend)}</div>
                <div data-testid="text-assumption-inflation">Education inflation: {Math.round((overrides.educationInflation ?? assumptions.educationInflation) * 100)}%</div>
              </div>
            </div>
          </div>

          <div className="mt-6 text-xs text-muted-foreground" data-testid="text-print-footer">
            Prepared by Plan4Life Financial Advisors · {new Date().toLocaleDateString("en-ZA")}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ClientOverview({ params }: { params: { id: string } }) {
  const { data: client, isLoading } = useClient(params.id);
  const { mode } = useMode();
  const [, setLocation] = useLocation();

  const [overrides, setOverrides] = React.useState<Overrides>({});
  const [showPrint, setShowPrint] = React.useState(false);

  const assumptions = defaultAssumptions;

  if (isLoading || !client) {
    return (
      <div className="mx-auto w-full max-w-6xl px-4 py-8">
        <div className="text-sm text-muted-foreground">{isLoading ? "Loading..." : "Client not found"}</div>
      </div>
    );
  }

  const annualSpend = overrides.annualSpend ?? client.household.annualSpend;
  const monthlySpend = overrides.monthlySpend ?? client.household.monthlySpend;
  const existingMonthlyIncome = overrides.existingMonthlyIncome ?? client.household.existingMonthlyIncome;
  const inflation = overrides.educationInflation ?? assumptions.educationInflation;
  const eduPrimary = overrides.educationCostPrimary ?? assumptions.educationCostPrimary;
  const eduHigh = overrides.educationCostHigh ?? assumptions.educationCostHigh;
  const eduTertiary = overrides.educationCostTertiary ?? assumptions.educationCostTertiary;
  const returnRate = overrides.investmentReturnRate ?? assumptions.investmentReturnRate;

  const eduFundingPlans = client.dependants.map((d) =>
    educationFundingPlan(d, { primary: eduPrimary, high: eduHigh, tertiary: eduTertiary }, inflation, returnRate),
  );

  const invTotal = sumInvestments(client);
  const liabilities = sumLiabilities(client);
  const nw = netWorth(client);
  const riskScore = riskAdequacyScore(client, assumptions, { annualSpend, monthlySpend, existingMonthlyIncome });
  const estateScore = estateReadinessScore(client);

  const branches = treeBranchStatuses(client, assumptions);

  const lifeReq = requiredLifeCover(client, assumptions, { annualSpend });
  const disIncomeReq = disabilityIncomeRequiredMonthly(client, { monthlySpend, existingMonthlyIncome });

  const educationRows = client.dependants.map((d) => {
    const { stage, annual } = educationCostPerChildAnnual(d.age, assumptions, {
      inflation,
      primary: eduPrimary,
      high: eduHigh,
      tertiary: eduTertiary,
    });
    const currentProvisionAnnual = 0;
    const gap = Math.max(0, annual - currentProvisionAnnual);
    return { ...d, stage, annual, gap };
  });

  const locked = mode === "client";
  const isClient = mode === "client";
  const isAdvisor = mode === "advisor";

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-8">
      <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          {isAdvisor && (
            <button
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition mb-2"
              onClick={() => setLocation("/clients")}
              data-testid="button-back"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to clients
            </button>
          )}

          {isClient && (
            <div className="mb-2 text-sm text-muted-foreground" data-testid="text-welcome">
              Welcome back
            </div>
          )}

          <div className="font-serif text-3xl font-semibold tracking-tight" data-testid="text-client-title">
            {client.name}
          </div>
          <div className="mt-1 text-sm text-muted-foreground" data-testid="text-client-subtitle">
            {client.age} · {client.maritalStatus} · {client.dependants.length} dependant{client.dependants.length !== 1 ? "s" : ""}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isAdvisor && (
            <Button onClick={() => setShowPrint(true)} className="gap-2" data-testid="button-generate-review">
              <Printer className="h-4 w-4" />
              Review Summary
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_420px]">
        <div className="grid gap-4 md:grid-cols-2">
          <ScorePill
            label="Net worth"
            value={formatZar(nw)}
            tone={toneFromScore(nw > 0 ? 80 : 30)}
            testId="card-networth"
          />
          <ScorePill
            label="Total investments"
            value={formatZar(invTotal)}
            tone={toneFromScore(invTotal >= 1500000 ? 85 : invTotal >= 600000 ? 60 : 35)}
            testId="card-investments"
          />
          <ScorePill
            label="Risk adequacy"
            value={`${riskScore}/100`}
            tone={toneFromScore(riskScore)}
            testId="card-risk"
          />
          <ScorePill
            label="Estate readiness"
            value={`${estateScore}/100`}
            tone={toneFromScore(estateScore)}
            testId="card-estate"
          />

          <div className="md:col-span-2">
            <TreeViz branches={branches} />
          </div>
        </div>

        <div className="space-y-4">
          {isAdvisor && (
            <LifeStagePanel client={client} locked={locked} />
          )}

          {isAdvisor && <ScenarioPlanner client={client} />}

          <ClientProfilePanel client={client} locked={isClient} />

          {isClient && <DependantsPanel client={client} />}

          <RiskQuestionnaire clientId={client.id} />

          <ClientAssetsLiabilitiesPanel client={client} locked={isClient} />

          {isAdvisor && <EstateEditor client={client} />}

          {isAdvisor && (
            <PortfolioUpload
              onParsed={() => {}}
            />
          )}

          {isClient && (
            <MeetingRequestPanel
              clientId={client.id}
              locked={false}
              onSubmit={() => {}}
            />
          )}

          {isClient && (
            <ClientOnboardingPanel
              locked={false}
              onSubmit={() => {}}
            />
          )}

          {isClient && <ClientToolsPanel client={client} />}

          <Card className="rounded-2xl p-4 shadow-sm" data-testid="card-details">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium" data-testid="text-details-title">Key details</div>
                <div className="text-xs text-muted-foreground" data-testid="text-details-subtitle">
                  {isAdvisor ? "Adjust assumptions to update calculations" : "Your financial overview"}
                </div>
              </div>
              <div className="rounded-full border bg-background px-3 py-1 text-xs text-muted-foreground" data-testid="status-readonly">
                {isClient ? "Client view" : "Advisor view"}
              </div>
            </div>

            <div className="mt-4 grid gap-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl border bg-background/60 p-3" data-testid="stat-lastreview">
                  <div className="text-[11px] text-muted-foreground" data-testid="label-lastreview">Last review</div>
                  <div className="mt-1 font-medium" data-testid="value-lastreview">{formatDate(client.lastReviewISO)}</div>
                </div>
                <div className="rounded-xl border bg-background/60 p-3" data-testid="stat-liabilities">
                  <div className="text-[11px] text-muted-foreground" data-testid="label-liabilities">Liabilities</div>
                  <div className="mt-1 font-medium" data-testid="value-liabilities">{formatZar(liabilities)}</div>
                </div>
              </div>

              {isAdvisor && (
                <div className="grid gap-2">
                  <div className="text-xs text-muted-foreground" data-testid="text-assumptions">Assumptions</div>
                  <div className="grid gap-2 rounded-xl border bg-background/60 p-3">
                    <label className="grid gap-1" data-testid="field-annual">
                      <span className="text-xs text-muted-foreground" data-testid="label-annual">Annual household spend</span>
                      <Input
                        value={String(annualSpend)}
                        onChange={(e) => setOverrides((s) => ({ ...s, annualSpend: Number(e.target.value || 0) }))}
                        disabled={locked}
                        data-testid="input-annual-spend"
                      />
                    </label>
                    <label className="grid gap-1" data-testid="field-monthly">
                      <span className="text-xs text-muted-foreground" data-testid="label-monthly">Monthly household spend</span>
                      <Input
                        value={String(monthlySpend)}
                        onChange={(e) => setOverrides((s) => ({ ...s, monthlySpend: Number(e.target.value || 0) }))}
                        disabled={locked}
                        data-testid="input-monthly-spend"
                      />
                    </label>
                    <label className="grid gap-1" data-testid="field-income">
                      <span className="text-xs text-muted-foreground" data-testid="label-income">Existing monthly income</span>
                      <Input
                        value={String(existingMonthlyIncome)}
                        onChange={(e) => setOverrides((s) => ({ ...s, existingMonthlyIncome: Number(e.target.value || 0) }))}
                        disabled={locked}
                        data-testid="input-existing-income"
                      />
                    </label>
                  </div>
                </div>
              )}

              <div className="rounded-xl border bg-background/60 p-3" data-testid="stat-networth-detail">
                <div className="text-xs text-muted-foreground" data-testid="label-networth-detail">Net worth</div>
                <div className="mt-1 text-sm font-medium" data-testid="value-networth-detail">{formatZar(nw)}</div>
              </div>
            </div>
          </Card>

          <Card className="rounded-2xl p-4 text-sm text-muted-foreground" data-testid="card-medical-estate">
            <div className="font-medium text-foreground" data-testid="text-medical-title">Medical & estate</div>
            <div className="mt-3 grid gap-3">
              <div className="rounded-xl border bg-background/60 p-3" data-testid="stat-medical">
                <div className="text-[11px] text-muted-foreground" data-testid="label-medical">Medical aid</div>
                <div className="mt-1 font-medium text-foreground" data-testid="value-medical">
                  {client.medicalAid.planName}
                </div>
                <div className="mt-1 text-xs" data-testid="value-gap">Gap cover: {client.medicalAid.gapCover ? "Yes" : "No"}</div>
              </div>
              <div className="rounded-xl border bg-background/60 p-3" data-testid="stat-estate-flags">
                <div className="text-[11px] text-muted-foreground" data-testid="label-estate-flags">Estate status</div>
                <div className="mt-1 grid gap-1 text-xs" data-testid="list-estate-flags">
                  <div data-testid="flag-will">Will: {client.estate.willStatus.replace("_", " ")}</div>
                  <div data-testid="flag-executor">Executor named: {client.estate.executorNamed ? "Yes" : "No"}</div>
                  <div data-testid="flag-beneficiary">Beneficiary alignment: {client.estate.beneficiaryAlignment}</div>
                  <div data-testid="flag-liquidity">Estate liquidity: {client.estate.liquidityAdequate ? "Adequate" : "At risk"}</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <div className="mt-6 rounded-2xl border bg-card p-4 shadow-sm p4l-noise" data-testid="card-modules">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-medium" data-testid="text-modules-title">Financial modules</div>
            <div className="text-xs text-muted-foreground" data-testid="text-modules-subtitle">
              {isAdvisor ? "Review and adjust each area of your client's financial plan" : "Explore each area of your financial plan"}
            </div>
          </div>
        </div>

        <Tabs defaultValue="investments" className="mt-4" data-testid="tabs-modules">
          <TabsList className="w-full justify-start" data-testid="tabslist-modules">
            <TabsTrigger value="investments" data-testid="tab-investments">Investments</TabsTrigger>
            <TabsTrigger value="risk" data-testid="tab-risk">Risk Planning</TabsTrigger>
            <TabsTrigger value="education" data-testid="tab-education">Education Planning</TabsTrigger>
            <TabsTrigger value="estate" data-testid="tab-estate">Estate Planning</TabsTrigger>
            <TabsTrigger value="tax" data-testid="tab-tax">Tax Planning</TabsTrigger>
            {isAdvisor && <TabsTrigger value="docs" data-testid="tab-docs">Documents</TabsTrigger>}
          </TabsList>

          <TabsContent value="investments" className="mt-4" data-testid="panel-investments">
            <div className="grid gap-4 lg:grid-cols-[1fr_280px]">
              <Card className="rounded-2xl p-4" data-testid="card-allocation">
                <div className="text-sm font-medium" data-testid="text-allocation-title">Asset allocation</div>
                <div className="mt-3 grid gap-2 text-sm" data-testid="list-allocation">
                  {(() => {
                    const totals: Record<string, number> = {};
                    client.investments.forEach((a) =>
                      a.holdings.forEach((h) => {
                        totals[h.assetClass] = (totals[h.assetClass] ?? 0) + h.value;
                      }),
                    );
                    const sum = Object.values(totals).reduce((a, b) => a + b, 0) || 1;
                    return Object.entries(totals)
                      .sort((a, b) => b[1] - a[1])
                      .map(([k, v]) => (
                        <div key={k} className="rounded-xl border bg-background/60 p-3" data-testid={`row-allocation-${k}`}>
                          <div className="flex items-center justify-between">
                            <div className="text-sm font-medium" data-testid={`text-allocation-label-${k}`}>{k}</div>
                            <div className="text-sm text-muted-foreground" data-testid={`text-allocation-pct-${k}`}>{Math.round((v / sum) * 100)}%</div>
                          </div>
                          <div className="mt-2">
                            <Progress value={Math.round((v / sum) * 100)} data-testid={`progress-allocation-${k}`} />
                          </div>
                        </div>
                      ));
                  })()}
                </div>
              </Card>

              <Card className="rounded-2xl p-4" data-testid="card-investment-summary">
                <div className="text-sm font-medium" data-testid="text-investment-summary">Summary</div>
                <div className="mt-3 grid gap-2 text-sm">
                  <div className="flex items-center justify-between" data-testid="row-total-investments">
                    <span className="text-muted-foreground" data-testid="label-total-investments">Total investments</span>
                    <span className="font-medium" data-testid="value-total-investments">{formatZar(invTotal)}</span>
                  </div>
                  <div className="flex items-center justify-between" data-testid="row-liquid-assets">
                    <span className="text-muted-foreground" data-testid="label-liquid-assets">Liquid assets</span>
                    <span className="font-medium" data-testid="value-liquid-assets">{formatZar(client.household.liquidAssets)}</span>
                  </div>
                </div>
              </Card>
            </div>

            <Card className="mt-4 rounded-2xl p-4" data-testid="card-holdings">
              <div className="text-sm font-medium" data-testid="text-holdings-title">Accounts & holdings</div>
              <div className="mt-3 space-y-4" data-testid="list-accounts">
                {client.investments.map((acc) => (
                  <div key={acc.id} className="rounded-2xl border bg-background/60 p-3" data-testid={`card-account-${acc.id}`}>
                    <div className="flex flex-col gap-1 md:flex-row md:items-center md:justify-between">
                      <div>
                        <div className="font-medium" data-testid={`text-account-name-${acc.id}`}>{acc.name}</div>
                        <div className="text-xs text-muted-foreground" data-testid={`text-account-provider-${acc.id}`}>
                          {acc.provider} · {acc.type}
                        </div>
                      </div>
                      <div className="text-sm font-semibold" data-testid={`text-account-total-${acc.id}`}>
                        {formatZar(acc.holdings.reduce((a, b) => a + b.value, 0))}
                      </div>
                    </div>

                    <div className="mt-3 overflow-hidden rounded-xl border bg-card" data-testid={`table-holdings-${acc.id}`}>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Name</TableHead>
                            <TableHead>Asset class</TableHead>
                            <TableHead className="text-right">Value</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {acc.holdings.map((h) => (
                            <TableRow key={h.id} data-testid={`row-holding-${h.id}`}>
                              <TableCell data-testid={`text-holding-name-${h.id}`}>{h.name}</TableCell>
                              <TableCell data-testid={`text-holding-class-${h.id}`}>{h.assetClass}</TableCell>
                              <TableCell className="text-right" data-testid={`text-holding-value-${h.id}`}>{formatZar(h.value)}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="risk" className="mt-4" data-testid="panel-risk">
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="rounded-2xl p-4" data-testid="card-risk-summary">
                <div className="text-sm font-medium" data-testid="text-risk-title">Cover vs required</div>
                <div className="mt-3 grid gap-2 text-sm" data-testid="list-risk-rows">
                  <div className="flex items-center justify-between" data-testid="row-life">
                    <span className="text-muted-foreground" data-testid="label-life">Life cover</span>
                    <span className="font-medium" data-testid="value-life">{formatZar(client.riskCover.life)}</span>
                  </div>
                  <div className="flex items-center justify-between" data-testid="row-life-req">
                    <span className="text-muted-foreground" data-testid="label-life-req">Required</span>
                    <span className="font-medium" data-testid="value-life-req">{formatZar(lifeReq)}</span>
                  </div>
                  <div className="flex items-center justify-between" data-testid="row-life-gap">
                    <span className="text-muted-foreground" data-testid="label-life-gap">Shortfall</span>
                    <span className="font-semibold" data-testid="value-life-gap">
                      {formatZar(Math.max(0, lifeReq - client.riskCover.life))}
                    </span>
                  </div>

                  <div className="my-2 h-px bg-border" />

                  <div className="flex items-center justify-between" data-testid="row-di">
                    <span className="text-muted-foreground" data-testid="label-di">Disability income (monthly)</span>
                    <span className="font-medium" data-testid="value-di">{formatZar(client.riskCover.disabilityIncomeMonthly)}</span>
                  </div>
                  <div className="flex items-center justify-between" data-testid="row-di-req">
                    <span className="text-muted-foreground" data-testid="label-di-req">Required</span>
                    <span className="font-medium" data-testid="value-di-req">{formatZar(disIncomeReq)}</span>
                  </div>
                  <div className="flex items-center justify-between" data-testid="row-di-gap">
                    <span className="text-muted-foreground" data-testid="label-di-gap">Shortfall</span>
                    <span className="font-semibold" data-testid="value-di-gap">
                      {formatZar(Math.max(0, disIncomeReq - client.riskCover.disabilityIncomeMonthly))}
                    </span>
                  </div>

                  <div className="my-2 h-px bg-border" />

                  <div className="flex items-center justify-between" data-testid="row-dd">
                    <span className="text-muted-foreground" data-testid="label-dd">Dread disease</span>
                    <span className="font-medium" data-testid="value-dd">{formatZar(client.riskCover.dreadDisease)}</span>
                  </div>
                  <div className="flex items-center justify-between" data-testid="row-dd-req">
                    <span className="text-muted-foreground" data-testid="label-dd-req">Target (2× annual spend)</span>
                    <span className="font-medium" data-testid="value-dd-req">{formatZar(annualSpend * 2)}</span>
                  </div>
                  <div className="flex items-center justify-between" data-testid="row-dd-gap">
                    <span className="text-muted-foreground" data-testid="label-dd-gap">Shortfall</span>
                    <span className="font-semibold" data-testid="value-dd-gap">
                      {formatZar(Math.max(0, annualSpend * 2 - client.riskCover.dreadDisease))}
                    </span>
                  </div>
                </div>
              </Card>

              <Card className="rounded-2xl p-4" data-testid="card-risk-notes">
                <div className="text-sm font-medium" data-testid="text-risk-score">Risk adequacy score</div>
                <div className="mt-3 rounded-2xl border bg-background/60 p-4">
                  <div className="flex items-center justify-between" data-testid="row-risk-score">
                    <span className="text-sm text-muted-foreground" data-testid="label-risk-score">Score</span>
                    <span className="text-lg font-semibold" data-testid="value-risk-score">{riskScore}/100</span>
                  </div>
                  <div className="mt-3" data-testid="progress-risk-score">
                    <Progress value={riskScore} />
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground" data-testid="text-risk-hint">
                    Based on life cover, disability income, and dread disease adequacy.
                  </div>
                </div>

                <div className="mt-4 text-xs text-muted-foreground" data-testid="text-risk-coverage">
                  Covers life, disability income, disability lump sum, and dread disease.
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="education" className="mt-4" data-testid="panel-education">
            <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
              <div className="space-y-4">
                {eduFundingPlans.length === 0 && (
                  <Card className="rounded-2xl p-6 text-center text-muted-foreground" data-testid="card-edu-empty">
                    No dependants for education planning.
                  </Card>
                )}
                {eduFundingPlans.map((plan, idx) => {
                  const totalPV = plan.presentValue;
                  const totalFuture = plan.totalFutureCost;
                  return (
                    <Card key={idx} className="rounded-2xl p-4" data-testid={`card-edu-child-${idx}`}>
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-semibold" data-testid={`text-edu-name-${idx}`}>{plan.childName}</div>
                          <div className="text-xs text-muted-foreground" data-testid={`text-edu-age-${idx}`}>Age {plan.childAge} — {plan.yearsRemaining} years of education remaining</div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-[var(--brand-accent)]" data-testid={`text-edu-pv-${idx}`}>{formatZar(totalPV)}</div>
                          <div className="text-xs text-muted-foreground">present value needed</div>
                        </div>
                      </div>

                      <div className="mt-3 grid grid-cols-3 gap-3">
                        <div className="rounded-xl border bg-background/60 p-3 text-center">
                          <div className="text-xs text-muted-foreground">Total future cost</div>
                          <div className="mt-1 text-sm font-semibold" data-testid={`text-edu-future-${idx}`}>{formatZar(totalFuture)}</div>
                        </div>
                        <div className="rounded-xl border bg-background/60 p-3 text-center">
                          <div className="text-xs text-muted-foreground">Monthly savings</div>
                          <div className="mt-1 text-sm font-semibold text-[var(--brand-accent)]" data-testid={`text-edu-monthly-${idx}`}>{formatZar(plan.monthlySavingsNeeded)}</div>
                        </div>
                        <div className="rounded-xl border bg-background/60 p-3 text-center">
                          <div className="text-xs text-muted-foreground">Years remaining</div>
                          <div className="mt-1 text-sm font-semibold" data-testid={`text-edu-years-${idx}`}>{plan.yearsRemaining}</div>
                        </div>
                      </div>

                      <details className="mt-3 group">
                        <summary className="cursor-pointer text-xs text-muted-foreground hover:text-foreground" data-testid={`btn-edu-detail-${idx}`}>
                          Year-by-year breakdown
                        </summary>
                        <div className="mt-2 overflow-hidden rounded-xl border bg-card" data-testid={`table-edu-breakdown-${idx}`}>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Year</TableHead>
                                <TableHead>Age</TableHead>
                                <TableHead>Stage</TableHead>
                                <TableHead className="text-right">Projected cost</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {plan.breakdown.map((row) => (
                                <TableRow key={row.year}>
                                  <TableCell>{row.year}</TableCell>
                                  <TableCell>{row.age}</TableCell>
                                  <TableCell>{row.stage}</TableCell>
                                  <TableCell className="text-right">{formatZar(row.cost)}</TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      </details>
                    </Card>
                  );
                })}

                {eduFundingPlans.length > 0 && (
                  <Card className="rounded-2xl p-4" data-testid="card-edu-totals">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-semibold">Total education funding required</div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-[var(--brand-accent)]" data-testid="text-edu-total-pv">
                          {formatZar(eduFundingPlans.reduce((s, p) => s + p.presentValue, 0))}
                        </div>
                        <div className="text-xs text-muted-foreground">combined present value</div>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Combined monthly savings target</span>
                      <span className="font-semibold" data-testid="text-edu-total-monthly">
                        {formatZar(eduFundingPlans.reduce((s, p) => s + p.monthlySavingsNeeded, 0))}
                      </span>
                    </div>
                  </Card>
                )}
              </div>

              <Card className="rounded-2xl p-4 h-fit" data-testid="card-education-controls">
                <div className="text-sm font-medium" data-testid="text-education-controls">Assumptions</div>
                <div className="mt-3 space-y-4">
                  <div className="rounded-xl border bg-background/60 p-3">
                    <div className="flex items-center justify-between" data-testid="row-inflation">
                      <span className="text-xs text-muted-foreground" data-testid="label-inflation">Education inflation</span>
                      <span className="text-xs font-medium" data-testid="value-inflation">{Math.round(inflation * 100)}%</span>
                    </div>
                    <div className="mt-2" data-testid="slider-inflation">
                      <Slider
                        value={[Math.round(inflation * 100)]}
                        min={0}
                        max={12}
                        step={1}
                        onValueChange={(v) => setOverrides((s) => ({ ...s, educationInflation: (v[0] ?? 0) / 100 }))}
                        disabled={locked}
                        data-testid="input-inflation"
                      />
                    </div>
                  </div>

                  <div className="rounded-xl border bg-background/60 p-3">
                    <div className="flex items-center justify-between" data-testid="row-return-rate">
                      <span className="text-xs text-muted-foreground" data-testid="label-return-rate">Investment return rate</span>
                      <span className="text-xs font-medium" data-testid="value-return-rate">{Math.round(returnRate * 100)}%</span>
                    </div>
                    <div className="mt-2" data-testid="slider-return-rate">
                      <Slider
                        value={[Math.round(returnRate * 100)]}
                        min={0}
                        max={15}
                        step={1}
                        onValueChange={(v) => setOverrides((s) => ({ ...s, investmentReturnRate: (v[0] ?? 0) / 100 }))}
                        disabled={locked}
                        data-testid="input-return-rate"
                      />
                    </div>
                  </div>

                  <div className="rounded-xl border bg-background/60 p-3">
                    <div className="flex items-center justify-between" data-testid="row-primary-cost">
                      <span className="text-xs text-muted-foreground" data-testid="label-primary-cost">Primary school (annual)</span>
                      <span className="text-xs font-medium" data-testid="value-primary-cost">{formatZar(eduPrimary)}</span>
                    </div>
                    <div className="mt-2" data-testid="slider-primary-cost">
                      <Slider
                        value={[eduPrimary]}
                        min={20000}
                        max={200000}
                        step={5000}
                        onValueChange={(v) => setOverrides((s) => ({ ...s, educationCostPrimary: v[0] ?? 65000 }))}
                        disabled={locked}
                        data-testid="input-primary-cost"
                      />
                    </div>
                  </div>

                  <div className="rounded-xl border bg-background/60 p-3">
                    <div className="flex items-center justify-between" data-testid="row-high-cost">
                      <span className="text-xs text-muted-foreground" data-testid="label-high-cost">High school (annual)</span>
                      <span className="text-xs font-medium" data-testid="value-high-cost">{formatZar(eduHigh)}</span>
                    </div>
                    <div className="mt-2" data-testid="slider-high-cost">
                      <Slider
                        value={[eduHigh]}
                        min={30000}
                        max={300000}
                        step={5000}
                        onValueChange={(v) => setOverrides((s) => ({ ...s, educationCostHigh: v[0] ?? 110000 }))}
                        disabled={locked}
                        data-testid="input-high-cost"
                      />
                    </div>
                  </div>

                  <div className="rounded-xl border bg-background/60 p-3">
                    <div className="flex items-center justify-between" data-testid="row-tertiary-cost">
                      <span className="text-xs text-muted-foreground" data-testid="label-tertiary-cost">Tertiary / university (annual)</span>
                      <span className="text-xs font-medium" data-testid="value-tertiary-cost">{formatZar(eduTertiary)}</span>
                    </div>
                    <div className="mt-2" data-testid="slider-tertiary-cost">
                      <Slider
                        value={[eduTertiary]}
                        min={50000}
                        max={500000}
                        step={5000}
                        onValueChange={(v) => setOverrides((s) => ({ ...s, educationCostTertiary: v[0] ?? 165000 }))}
                        disabled={locked}
                        data-testid="input-tertiary-cost"
                      />
                    </div>
                  </div>

                  {isClient && (
                    <div className="text-xs text-muted-foreground" data-testid="text-education-note">
                      Speak with your advisor to adjust assumptions.
                    </div>
                  )}
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="estate" className="mt-4" data-testid="panel-estate">
            <EstateDetail client={client} />
          </TabsContent>

          <TabsContent value="tax" className="mt-4" data-testid="panel-tax">
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="rounded-2xl p-4" data-testid="card-tax-ra">
                <div className="text-sm font-medium" data-testid="text-tax-ra">RA contribution (annual)</div>
                <div className="mt-3 flex items-center justify-between text-sm" data-testid="row-ra">
                  <span className="text-muted-foreground" data-testid="label-ra">Progress</span>
                  <span className="font-medium" data-testid="value-ra">
                    {formatZar(client.tax.raAnnualContribution)} / {formatZar(client.tax.raAnnualLimit)}
                  </span>
                </div>
                <div className="mt-3" data-testid="progress-ra">
                  <Progress
                    value={Math.round((client.tax.raAnnualContribution / client.tax.raAnnualLimit) * 100)}
                  />
                </div>
              </Card>
              <Card className="rounded-2xl p-4" data-testid="card-tax-tfsa">
                <div className="text-sm font-medium" data-testid="text-tax-tfsa">TFSA lifetime</div>
                <div className="mt-3 flex items-center justify-between text-sm" data-testid="row-tfsa">
                  <span className="text-muted-foreground" data-testid="label-tfsa">Progress</span>
                  <span className="font-medium" data-testid="value-tfsa">
                    {formatZar(client.tax.tfsaContributionLifetime)} / {formatZar(client.tax.tfsaLifetimeLimit)}
                  </span>
                </div>
                <div className="mt-3" data-testid="progress-tfsa">
                  <Progress
                    value={Math.round((client.tax.tfsaContributionLifetime / client.tax.tfsaLifetimeLimit) * 100)}
                  />
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="docs" className="mt-4" data-testid="panel-docs">
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="rounded-2xl p-4" data-testid="card-fica">
                <div className="text-sm font-medium" data-testid="text-fica-title">FICA checklist</div>
                <div className="mt-3 grid gap-2 text-sm" data-testid="list-fica">
                  <div className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2" data-testid="row-fica-status">
                    <span className="text-muted-foreground" data-testid="label-fica-status">Status</span>
                    <span className="font-medium" data-testid="value-fica-status">{client.documents.ficaStatus}</span>
                  </div>
                  <div className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2" data-testid="row-fica-updated">
                    <span className="text-muted-foreground" data-testid="label-fica-updated">Last updated</span>
                    <span className="font-medium" data-testid="value-fica-updated">{formatDate(client.documents.lastUpdatedISO)}</span>
                  </div>
                </div>
              </Card>
              <Card className="rounded-2xl p-4" data-testid="card-docs-placeholder">
                <div className="text-sm font-medium" data-testid="text-docs-title">Documents</div>
                <div className="mt-2 text-sm text-muted-foreground" data-testid="text-docs-note">
                  Document management will be available once connected to Elite Wealth CRM.
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {showPrint && (
        <PrintSummary
          client={client}
          assumptions={assumptions}
          overrides={overrides}
          onClose={() => setShowPrint(false)}
        />
      )}
    </div>
  );
}
