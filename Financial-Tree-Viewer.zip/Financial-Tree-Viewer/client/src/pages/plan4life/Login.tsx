import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Shield, TrendingUp, Users, TreePine, ArrowRight, Loader2, ClipboardCheck } from "lucide-react";
import { Link } from "wouter";

function AnimatedTree() {
  return (
    <div className="relative w-full flex items-center justify-center py-6" aria-hidden>
      <svg width="220" height="240" viewBox="0 0 220 240" fill="none" className="drop-shadow-lg">
        <defs>
          <linearGradient id="trunk-grad" x1="110" y1="240" x2="110" y2="140" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="hsl(30 30% 35%)" />
            <stop offset="100%" stopColor="hsl(30 25% 45%)" />
          </linearGradient>
          <linearGradient id="canopy-grad" x1="110" y1="20" x2="110" y2="160" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="hsl(82 25% 45%)" />
            <stop offset="100%" stopColor="hsl(82 22% 35%)" />
          </linearGradient>
          <linearGradient id="canopy-gold" x1="80" y1="40" x2="140" y2="100" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="hsl(38 55% 55%)" />
            <stop offset="100%" stopColor="hsl(38 45% 45%)" />
          </linearGradient>
          <radialGradient id="glow" cx="110" cy="90" r="100" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="hsl(82 30% 50% / 0.2)" />
            <stop offset="100%" stopColor="hsl(82 30% 50% / 0)" />
          </radialGradient>
          <filter id="canopy-shadow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="4" />
          </filter>
        </defs>

        <circle cx="110" cy="95" r="90" fill="url(#glow)" className="animate-pulse" style={{ animationDuration: "4s" }} />

        <path d="M100 240 L100 160 Q100 145 105 140 L105 140" stroke="url(#trunk-grad)" strokeWidth="8" strokeLinecap="round" fill="none" />
        <path d="M120 240 L120 160 Q120 145 115 140 L115 140" stroke="url(#trunk-grad)" strokeWidth="8" strokeLinecap="round" fill="none" />
        <path d="M95 200 Q70 190 55 210" stroke="url(#trunk-grad)" strokeWidth="4" strokeLinecap="round" fill="none" opacity="0.5" />
        <path d="M125 205 Q145 195 155 215" stroke="url(#trunk-grad)" strokeWidth="4" strokeLinecap="round" fill="none" opacity="0.5" />

        <ellipse cx="110" cy="90" rx="80" ry="70" fill="url(#canopy-grad)" opacity="0.15" filter="url(#canopy-shadow)" />

        <ellipse cx="80" cy="100" rx="38" ry="34" fill="url(#canopy-grad)" opacity="0.85" />
        <ellipse cx="140" cy="100" rx="38" ry="34" fill="url(#canopy-grad)" opacity="0.85" />
        <ellipse cx="110" cy="75" rx="42" ry="38" fill="url(#canopy-grad)" opacity="0.9" />
        <ellipse cx="70" cy="80" rx="30" ry="28" fill="url(#canopy-grad)" opacity="0.7" />
        <ellipse cx="150" cy="80" rx="30" ry="28" fill="url(#canopy-grad)" opacity="0.7" />
        <ellipse cx="110" cy="50" rx="35" ry="30" fill="url(#canopy-grad)" opacity="0.8" />
        <ellipse cx="90" cy="55" rx="25" ry="22" fill="url(#canopy-gold)" opacity="0.5" />
        <ellipse cx="130" cy="60" rx="22" ry="20" fill="url(#canopy-gold)" opacity="0.45" />
        <ellipse cx="65" cy="90" rx="14" ry="12" fill="hsl(30 50% 50%)" opacity="0.3" />
        <ellipse cx="155" cy="88" rx="12" ry="10" fill="hsl(30 50% 50%)" opacity="0.25" />
      </svg>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description }: { icon: React.ElementType; title: string; description: string }) {
  return (
    <div className="flex items-start gap-3 rounded-xl border bg-card/60 p-3.5 backdrop-blur-sm transition-all hover:bg-card/90 hover:shadow-sm">
      <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
        <Icon className="h-4.5 w-4.5" />
      </div>
      <div>
        <div className="text-sm font-medium text-foreground">{title}</div>
        <div className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{description}</div>
      </div>
    </div>
  );
}

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
        credentials: "include",
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        setError(body.message || "Login failed");
        setLoading(false);
        return;
      }

      window.location.href = "/";
    } catch {
      setError("Something went wrong. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-dvh bg-gradient-to-br from-[hsl(40_30%_95%)] via-background to-[hsl(82_15%_95%)] dark:from-[hsl(158_18%_8%)] dark:via-background dark:to-[hsl(82_12%_10%)]"
      data-testid="page-login"
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden>
        <div className="absolute -left-20 -top-20 h-[500px] w-[500px] rounded-full bg-[hsl(82_25%_50%/0.08)] blur-[100px]" />
        <div className="absolute -right-20 top-1/4 h-[400px] w-[400px] rounded-full bg-[hsl(38_50%_50%/0.06)] blur-[80px]" />
        <div className="absolute left-1/3 -bottom-20 h-[300px] w-[300px] rounded-full bg-[hsl(158_25%_35%/0.05)] blur-[60px]" />
      </div>

      <div className="relative mx-auto grid min-h-dvh w-full max-w-6xl grid-cols-1 items-center gap-6 px-5 py-8 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
        <div className="order-2 lg:order-1">
          <div className="flex items-center gap-3 mb-2">
            <img src="/images/pfl-logo.jpeg" alt="PFL Financial Advisors" className="h-16 w-auto" data-testid="img-login-brand-logo" />
          </div>

          <h1
            className="mt-8 max-w-lg font-serif text-3xl font-semibold leading-tight tracking-tight text-foreground sm:text-4xl lg:text-[2.65rem] lg:leading-[1.15]"
            data-testid="text-login-title"
          >
            Your Financial Future,{" "}
            <span className="text-[hsl(38_55%_45%)]">Our Personal Commitment</span>
          </h1>
          <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-muted-foreground" data-testid="text-login-subtitle">
            We leverage advanced technology behind the scenes — so you get expert human guidance, not chatbots. Your complete financial picture, at a glance.
          </p>

          <div className="mt-8 grid gap-3 sm:grid-cols-2" data-testid="grid-login-highlights">
            <FeatureCard
              icon={TrendingUp}
              title="Portfolio Overview"
              description="Track investments, retirement funds, and asset allocation in real time."
            />
            <FeatureCard
              icon={Shield}
              title="Risk & Estate Planning"
              description="Life cover adequacy, will status, and beneficiary alignment at a glance."
            />
            <FeatureCard
              icon={Users}
              title="Client Management"
              description="Filter and prioritise clients with smart insights and review scheduling."
            />
            <FeatureCard
              icon={TreePine}
              title="Health Tree View"
              description="Green, amber, and red branches show module readiness instantly."
            />
          </div>

          <div className="mt-8 hidden lg:flex items-center gap-6 text-xs text-muted-foreground/70">
            <span>Trusted by PFL Financial Advisors</span>
            <span className="h-px flex-1 bg-border/60" />
          </div>
        </div>

        <div className="order-1 lg:order-2 flex flex-col items-center">
          <Card className="w-full max-w-sm rounded-2xl border bg-card/90 p-7 shadow-xl backdrop-blur-sm" data-testid="card-login">
            <div className="text-center mb-6">
              <div className="lg:hidden flex justify-center mb-4">
                <img src="/images/pfl-logo.jpeg" alt="PFL Financial Advisors" className="h-20 w-auto" data-testid="img-login-mobile-logo" />
              </div>
              <h2 className="font-serif text-xl font-semibold tracking-tight" data-testid="text-login-form-title">
                Welcome
              </h2>
              <p className="mt-1 text-sm text-muted-foreground" data-testid="text-login-form-subtitle">
                Sign in to access the advisor portal
              </p>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-4" data-testid="form-login">
              <div>
                <label htmlFor="username" className="text-sm font-medium text-foreground">Username</label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username"
                  required
                  autoComplete="username"
                  className="mt-1.5"
                  data-testid="input-username"
                />
              </div>
              <div>
                <label htmlFor="password" className="text-sm font-medium text-foreground">Password</label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  autoComplete="current-password"
                  className="mt-1.5"
                  data-testid="input-password"
                />
              </div>

              {error && (
                <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive" data-testid="text-login-error">
                  {error}
                </div>
              )}

              <Button type="submit" className="w-full h-10 gap-2 font-medium" disabled={loading} data-testid="button-login">
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  <>
                    Sign in
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </Button>
            </form>

            <div className="mt-5 pt-4 border-t">
              <Link href="/risk-profile">
                <button
                  className="w-full flex items-center gap-2 rounded-lg border border-dashed border-primary/30 bg-primary/5 px-3 py-2.5 text-sm text-foreground transition-all hover:bg-primary/10 hover:border-primary/50"
                  data-testid="button-public-risk-profile"
                >
                  <ClipboardCheck className="h-4 w-4 text-primary" />
                  <div className="text-left">
                    <span className="font-medium">Discover Your Risk Profile</span>
                    <span className="block text-xs text-muted-foreground">Free assessment — no login required</span>
                  </div>
                  <ArrowRight className="h-3.5 w-3.5 ml-auto text-muted-foreground" />
                </button>
              </Link>
            </div>

            <div className="mt-4 flex items-center gap-2 justify-center">
              <Shield className="h-3.5 w-3.5 text-muted-foreground/50" />
              <p className="text-[11px] text-muted-foreground/60" data-testid="text-login-footer">
                Secured portal for PFL Financial Advisors
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
