import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Users, Shield, UserCheck, UserX, Save, Plus, Loader2 } from "lucide-react";
import { Link } from "wouter";
import type { User } from "@shared/models/auth";
import type { Client } from "@/lib/plan4life/types";

function apiFetch<T>(url: string, opts?: RequestInit): Promise<T> {
  return fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  }).then(async (res) => {
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.message || `API error ${res.status}`);
    }
    return res.json();
  });
}

function UserRow({ user, clients, onSave }: {
  user: User;
  clients: Client[];
  onSave: (id: string, role: string | null, linkedClientId: string | null) => void;
}) {
  const [role, setRole] = useState<string>(user.role || "none");
  const [linkedClientId, setLinkedClientId] = useState<string>(user.linkedClientId || "none");
  const [dirty, setDirty] = useState(false);

  const handleRoleChange = (val: string) => {
    setRole(val);
    if (val !== "client") setLinkedClientId("none");
    setDirty(true);
  };

  const handleClientChange = (val: string) => {
    setLinkedClientId(val);
    setDirty(true);
  };

  const handleSave = () => {
    onSave(
      user.id,
      role === "none" ? null : role,
      linkedClientId === "none" ? null : linkedClientId
    );
    setDirty(false);
  };

  const roleBadge = user.role === "advisor"
    ? <Badge className="text-xs" data-testid={`badge-role-${user.id}`}>Advisor</Badge>
    : user.role === "client"
      ? <Badge variant="secondary" className="text-xs" data-testid={`badge-role-${user.id}`}>Client</Badge>
      : <Badge variant="outline" className="text-xs text-muted-foreground" data-testid={`badge-role-${user.id}`}>No access</Badge>;

  return (
    <div className="flex flex-col sm:flex-row sm:items-center gap-3 p-4 rounded-xl border bg-card" data-testid={`row-user-${user.id}`}>
      <div className="flex items-center gap-3 flex-1 min-w-0">
        {user.profileImageUrl ? (
          <img src={user.profileImageUrl} alt="" className="h-9 w-9 rounded-full border shrink-0" />
        ) : (
          <div className="h-9 w-9 rounded-full bg-muted grid place-items-center shrink-0">
            <Users className="h-4 w-4 text-muted-foreground" />
          </div>
        )}
        <div className="min-w-0">
          <div className="text-sm font-medium truncate" data-testid={`text-user-name-${user.id}`}>
            {user.firstName || user.username || "Unnamed"} {user.lastName || ""}
          </div>
          <div className="text-xs text-muted-foreground truncate" data-testid={`text-user-email-${user.id}`}>
            {user.username ? `@${user.username}` : ""}{user.email ? ` · ${user.email}` : ""}
          </div>
        </div>
        <div className="hidden sm:block">{roleBadge}</div>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <Select value={role} onValueChange={handleRoleChange}>
          <SelectTrigger className="w-[130px] h-9 text-sm" data-testid={`select-role-${user.id}`}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">No access</SelectItem>
            <SelectItem value="advisor">Advisor</SelectItem>
            <SelectItem value="client">Client</SelectItem>
          </SelectContent>
        </Select>

        {role === "client" && (
          <Select value={linkedClientId} onValueChange={handleClientChange}>
            <SelectTrigger className="w-[180px] h-9 text-sm" data-testid={`select-client-${user.id}`}>
              <SelectValue placeholder="Link to client..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">Not linked</SelectItem>
              {clients.map((c) => (
                <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {dirty && (
          <Button size="sm" className="h-9 gap-1.5" onClick={handleSave} data-testid={`button-save-${user.id}`}>
            <Save className="h-3.5 w-3.5" />
            Save
          </Button>
        )}
      </div>
    </div>
  );
}

function CreateUserForm({ clients, onCreated }: { clients: Client[]; onCreated: () => void }) {
  const [open, setOpen] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("none");
  const [linkedClientId, setLinkedClientId] = useState("none");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const reset = () => {
    setUsername(""); setPassword(""); setFirstName(""); setLastName("");
    setEmail(""); setRole("none"); setLinkedClientId("none"); setError("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await apiFetch("/api/admin/users", {
        method: "POST",
        body: JSON.stringify({
          username,
          password,
          firstName: firstName || null,
          lastName: lastName || null,
          email: email || null,
          role: role === "none" ? null : role,
          linkedClientId: linkedClientId === "none" ? null : linkedClientId,
        }),
      });
      reset();
      setOpen(false);
      onCreated();
    } catch (err: any) {
      setError(err.message || "Failed to create user");
    } finally {
      setLoading(false);
    }
  };

  if (!open) {
    return (
      <Button onClick={() => setOpen(true)} className="gap-2" data-testid="button-create-user">
        <Plus className="h-4 w-4" />
        Create User
      </Button>
    );
  }

  return (
    <Card className="rounded-2xl" data-testid="card-create-user">
      <CardHeader className="pb-2">
        <CardTitle className="text-base font-medium">Create New User</CardTitle>
        <p className="text-xs text-muted-foreground">Create a login account for an advisor or client.</p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="grid gap-3 sm:grid-cols-2">
          <div>
            <label className="text-xs font-medium text-muted-foreground">Username *</label>
            <Input value={username} onChange={(e) => setUsername(e.target.value)} required minLength={3} className="mt-1" data-testid="input-new-username" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Password *</label>
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} className="mt-1" data-testid="input-new-password" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">First name</label>
            <Input value={firstName} onChange={(e) => setFirstName(e.target.value)} className="mt-1" data-testid="input-new-firstname" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Last name</label>
            <Input value={lastName} onChange={(e) => setLastName(e.target.value)} className="mt-1" data-testid="input-new-lastname" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Email</label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1" data-testid="input-new-email" />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Role</label>
            <Select value={role} onValueChange={(v) => { setRole(v); if (v !== "client") setLinkedClientId("none"); }}>
              <SelectTrigger className="mt-1" data-testid="select-new-role"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No access</SelectItem>
                <SelectItem value="advisor">Advisor</SelectItem>
                <SelectItem value="client">Client</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {role === "client" && (
            <div className="sm:col-span-2">
              <label className="text-xs font-medium text-muted-foreground">Linked client record</label>
              <Select value={linkedClientId} onValueChange={setLinkedClientId}>
                <SelectTrigger className="mt-1" data-testid="select-new-client"><SelectValue placeholder="Select client..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Not linked</SelectItem>
                  {clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          {error && (
            <div className="sm:col-span-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive" data-testid="text-create-error">
              {error}
            </div>
          )}
          <div className="sm:col-span-2 flex gap-2 justify-end pt-1">
            <Button type="button" variant="outline" onClick={() => { reset(); setOpen(false); }} data-testid="button-cancel-create">Cancel</Button>
            <Button type="submit" disabled={loading} className="gap-2" data-testid="button-submit-create">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
              Create
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

export default function UserManagement() {
  const queryClient = useQueryClient();

  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    queryFn: () => apiFetch<User[]>("/api/admin/users"),
  });

  const { data: clients = [], isLoading: clientsLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
    queryFn: () => apiFetch<Client[]>("/api/clients"),
  });

  const updateRole = useMutation({
    mutationFn: ({ id, role, linkedClientId }: { id: string; role: string | null; linkedClientId: string | null }) =>
      apiFetch(`/api/admin/users/${id}/role`, {
        method: "PATCH",
        body: JSON.stringify({ role, linkedClientId }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
  });

  const handleSave = (id: string, role: string | null, linkedClientId: string | null) => {
    updateRole.mutate({ id, role, linkedClientId });
  };

  const advisorCount = users.filter((u) => u.role === "advisor").length;
  const clientCount = users.filter((u) => u.role === "client").length;
  const pendingCount = users.filter((u) => !u.role).length;

  const isLoading = usersLoading || clientsLoading;

  return (
    <div className="mx-auto max-w-4xl px-4 py-8" data-testid="page-user-management">
      <div className="flex items-center gap-3 mb-6">
        <Link href="/clients" data-testid="link-back-clients">
          <Button variant="ghost" size="icon" className="h-9 w-9">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div>
          <h1 className="font-serif text-2xl font-semibold" data-testid="text-user-mgmt-title">User Management</h1>
          <p className="text-sm text-muted-foreground">Assign roles and link client accounts</p>
        </div>
      </div>

      <div className="mb-6">
        <CreateUserForm
          clients={clients}
          onCreated={() => queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] })}
        />
      </div>

      <div className="grid grid-cols-3 gap-3 mb-6">
        <Card className="rounded-xl">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-primary/10">
              <Shield className="h-4 w-4 text-primary" />
            </div>
            <div>
              <div className="text-xl font-semibold" data-testid="text-advisor-count">{advisorCount}</div>
              <div className="text-xs text-muted-foreground">Advisors</div>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-xl">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-accent">
              <UserCheck className="h-4 w-4 text-accent-foreground" />
            </div>
            <div>
              <div className="text-xl font-semibold" data-testid="text-client-count">{clientCount}</div>
              <div className="text-xs text-muted-foreground">Clients</div>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-xl">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-lg bg-muted">
              <UserX className="h-4 w-4 text-muted-foreground" />
            </div>
            <div>
              <div className="text-xl font-semibold" data-testid="text-pending-count">{pendingCount}</div>
              <div className="text-xs text-muted-foreground">Pending</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">All Users</CardTitle>
          <p className="text-xs text-muted-foreground">
            Manage user accounts and assign roles to grant access.
          </p>
        </CardHeader>
        <CardContent className="grid gap-2">
          {isLoading ? (
            <div className="py-8 text-center text-sm text-muted-foreground">Loading users...</div>
          ) : users.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">No users have signed in yet.</div>
          ) : (
            users.map((user) => (
              <UserRow key={user.id} user={user} clients={clients} onSave={handleSave} />
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
