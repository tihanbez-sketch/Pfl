import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Shield, ChevronRight, ChevronLeft, CheckCircle, User, Printer, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

interface Question {
  id: string;
  section: "capacity" | "tolerance" | "goals";
  text: string;
  options: { label: string; value: number }[];
}

const QUESTIONS: Question[] = [
  {
    id: "q1",
    section: "capacity",
    text: "How many months of living expenses do you have in an easily accessible emergency fund (savings account, money market)?",
    options: [
      { label: "Less than 1 month", value: 2 },
      { label: "1 – 3 months", value: 4 },
      { label: "3 – 6 months", value: 6 },
      { label: "More than 6 months", value: 8 },
    ],
  },
  {
    id: "q2",
    section: "capacity",
    text: "What percentage of your monthly income are you able to save or invest after all expenses?",
    options: [
      { label: "Less than 5%", value: 2 },
      { label: "5 – 10%", value: 4 },
      { label: "10 – 20%", value: 6 },
      { label: "More than 20%", value: 8 },
    ],
  },
  {
    id: "q3",
    section: "capacity",
    text: "How stable is your primary source of income?",
    options: [
      { label: "Very unstable — irregular or contract-based", value: 2 },
      { label: "Somewhat stable — employed but uncertain industry", value: 4 },
      { label: "Stable — permanent position or established business", value: 6 },
      { label: "Very stable — multiple income streams or guaranteed pension", value: 8 },
    ],
  },
  {
    id: "q4",
    section: "capacity",
    text: "How much total debt (excluding home loan) do you carry relative to your annual income?",
    options: [
      { label: "More than 50% of annual income", value: 2 },
      { label: "25 – 50% of annual income", value: 4 },
      { label: "Less than 25% of annual income", value: 6 },
      { label: "No non-mortgage debt", value: 8 },
    ],
  },
  {
    id: "q5",
    section: "capacity",
    text: "Do you have adequate life, disability, and dread disease cover in place?",
    options: [
      { label: "No cover at all", value: 2 },
      { label: "Some cover but not enough", value: 4 },
      { label: "Adequate cover in most areas", value: 6 },
      { label: "Fully covered across all categories", value: 8 },
    ],
  },
  {
    id: "q6",
    section: "tolerance",
    text: "If your investment portfolio dropped 20% in a single month, what would you most likely do?",
    options: [
      { label: "Sell everything immediately to stop further losses", value: 2 },
      { label: "Sell some holdings to reduce exposure", value: 5 },
      { label: "Do nothing and wait for recovery", value: 8 },
      { label: "Invest more to take advantage of lower prices", value: 12 },
    ],
  },
  {
    id: "q7",
    section: "tolerance",
    text: "When you think about investing, which statement best describes your feelings?",
    options: [
      { label: "I lose sleep over any potential loss — safety is everything", value: 2 },
      { label: "I prefer stability but accept small ups and downs", value: 5 },
      { label: "I'm comfortable with moderate volatility for better returns", value: 8 },
      { label: "I thrive on volatility — big risks mean big rewards", value: 12 },
    ],
  },
  {
    id: "q8",
    section: "tolerance",
    text: "Which of these investment outcomes would you be most comfortable with over a 12-month period?",
    options: [
      { label: "Guaranteed return of 6% (no chance of loss)", value: 2 },
      { label: "Expected return of 10%, but could range from -5% to +25%", value: 5 },
      { label: "Expected return of 15%, but could range from -15% to +40%", value: 8 },
      { label: "Expected return of 25%, but could range from -30% to +60%", value: 12 },
    ],
  },
  {
    id: "q9",
    section: "tolerance",
    text: "How experienced are you with investment products (unit trusts, shares, ETFs, retirement annuities)?",
    options: [
      { label: "No experience — I've only used savings accounts", value: 2 },
      { label: "Some experience — I have a retirement fund through my employer", value: 5 },
      { label: "Moderate experience — I actively invest in unit trusts or ETFs", value: 8 },
      { label: "Very experienced — I invest directly in shares and understand market cycles", value: 14 },
    ],
  },
  {
    id: "q10",
    section: "goals",
    text: "When do you plan to start drawing on the majority of your investments?",
    options: [
      { label: "Within the next 3 years", value: 2 },
      { label: "In 3 – 7 years", value: 5 },
      { label: "In 7 – 15 years", value: 8 },
      { label: "More than 15 years from now", value: 10 },
    ],
  },
  {
    id: "q11",
    section: "goals",
    text: "What is the primary purpose of your investments?",
    options: [
      { label: "Preserve my capital — I cannot afford to lose money", value: 2 },
      { label: "Generate a steady income with minimal risk", value: 5 },
      { label: "Grow my wealth over time, accepting some ups and downs", value: 8 },
      { label: "Maximise long-term growth — I can handle significant volatility", value: 10 },
    ],
  },
  {
    id: "q12",
    section: "goals",
    text: "Which South African scenario concerns you most about your financial future?",
    options: [
      { label: "Load shedding and rising costs eroding my savings", value: 2 },
      { label: "Rand weakness reducing my purchasing power", value: 5 },
      { label: "Not having enough for retirement given SA inflation", value: 8 },
      { label: "Missing out on growth opportunities while being too conservative", value: 10 },
    ],
  },
];

const SECTION_LABELS: Record<string, string> = {
  capacity: "Financial Safety Net",
  tolerance: "Gut Feeling About Risk",
  goals: "Goals & Life Circumstances",
};

const SECTION_MAX: Record<string, number> = {
  capacity: 40,
  tolerance: 50,
  goals: 30,
};

function getProfileLabel(total: number): string {
  if (total <= 40) return "Cautious";
  if (total <= 65) return "Moderately Cautious";
  if (total <= 85) return "Balanced";
  if (total <= 105) return "Moderately Adventurous";
  return "Adventurous";
}

function getProfileColor(label: string): string {
  switch (label) {
    case "Cautious": return "hsl(200, 60%, 50%)";
    case "Moderately Cautious": return "hsl(180, 50%, 45%)";
    case "Balanced": return "hsl(82, 40%, 45%)";
    case "Moderately Adventurous": return "hsl(40, 70%, 50%)";
    case "Adventurous": return "hsl(15, 70%, 55%)";
    default: return "hsl(82, 22%, 42%)";
  }
}

function getProfileDescription(label: string): string {
  switch (label) {
    case "Cautious":
      return "You prefer stability and capital preservation. A portfolio weighted towards income funds, money market, and bonds with minimal equity exposure is recommended.";
    case "Moderately Cautious":
      return "You lean towards safety but can tolerate some market movement. A blend of income-focused and balanced funds with limited equity exposure suits your profile.";
    case "Balanced":
      return "You are comfortable with moderate risk for reasonable growth. A diversified portfolio across equities, bonds, and property with a medium-term horizon is appropriate.";
    case "Moderately Adventurous":
      return "You accept above-average risk for higher potential returns. A portfolio with significant equity exposure, including some offshore allocation, matches your appetite.";
    case "Adventurous":
      return "You embrace volatility and seek maximum long-term growth. A high-equity portfolio with substantial offshore and alternative asset exposure is recommended.";
    default:
      return "";
  }
}

function getAssetAllocation(label: string): { name: string; pct: number; color: string }[] {
  switch (label) {
    case "Cautious":
      return [
        { name: "Money Market / Cash", pct: 30, color: "hsl(200, 60%, 60%)" },
        { name: "Bonds / Income", pct: 40, color: "hsl(200, 50%, 45%)" },
        { name: "Property", pct: 10, color: "hsl(180, 40%, 50%)" },
        { name: "SA Equity", pct: 15, color: "hsl(82, 35%, 50%)" },
        { name: "Offshore", pct: 5, color: "hsl(38, 50%, 50%)" },
      ];
    case "Moderately Cautious":
      return [
        { name: "Money Market / Cash", pct: 15, color: "hsl(200, 60%, 60%)" },
        { name: "Bonds / Income", pct: 35, color: "hsl(200, 50%, 45%)" },
        { name: "Property", pct: 10, color: "hsl(180, 40%, 50%)" },
        { name: "SA Equity", pct: 25, color: "hsl(82, 35%, 50%)" },
        { name: "Offshore", pct: 15, color: "hsl(38, 50%, 50%)" },
      ];
    case "Balanced":
      return [
        { name: "Money Market / Cash", pct: 10, color: "hsl(200, 60%, 60%)" },
        { name: "Bonds / Income", pct: 20, color: "hsl(200, 50%, 45%)" },
        { name: "Property", pct: 10, color: "hsl(180, 40%, 50%)" },
        { name: "SA Equity", pct: 35, color: "hsl(82, 35%, 50%)" },
        { name: "Offshore", pct: 25, color: "hsl(38, 50%, 50%)" },
      ];
    case "Moderately Adventurous":
      return [
        { name: "Money Market / Cash", pct: 5, color: "hsl(200, 60%, 60%)" },
        { name: "Bonds / Income", pct: 10, color: "hsl(200, 50%, 45%)" },
        { name: "Property", pct: 10, color: "hsl(180, 40%, 50%)" },
        { name: "SA Equity", pct: 40, color: "hsl(82, 35%, 50%)" },
        { name: "Offshore", pct: 35, color: "hsl(38, 50%, 50%)" },
      ];
    case "Adventurous":
      return [
        { name: "Money Market / Cash", pct: 5, color: "hsl(200, 60%, 60%)" },
        { name: "Bonds / Income", pct: 5, color: "hsl(200, 50%, 45%)" },
        { name: "Property", pct: 5, color: "hsl(180, 40%, 50%)" },
        { name: "SA Equity", pct: 40, color: "hsl(82, 35%, 50%)" },
        { name: "Offshore", pct: 45, color: "hsl(38, 50%, 50%)" },
      ];
    default:
      return [];
  }
}

type Stage = "details" | "questionnaire" | "result";

export default function PublicRiskProfile() {
  const [stage, setStage] = useState<Stage>("details");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [saving, setSaving] = useState(false);
  const [savedResult, setSavedResult] = useState<any>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStage("questionnaire");
  };

  const handleComplete = async () => {
    const capacityScore = QUESTIONS.filter(q => q.section === "capacity").reduce((sum, q) => sum + (answers[q.id] || 0), 0);
    const toleranceScore = QUESTIONS.filter(q => q.section === "tolerance").reduce((sum, q) => sum + (answers[q.id] || 0), 0);
    const goalsScore = QUESTIONS.filter(q => q.section === "goals").reduce((sum, q) => sum + (answers[q.id] || 0), 0);
    const totalScore = capacityScore + toleranceScore + goalsScore;
    const profileLabel = getProfileLabel(totalScore);

    setSaving(true);
    try {
      const res = await fetch("/api/public/risk-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          firstName, lastName, email, phone,
          answers, capacityScore, toleranceScore, goalsScore, totalScore, profileLabel,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setSavedResult(data);
      } else {
        setSavedResult({ capacityScore, toleranceScore, goalsScore, totalScore, profileLabel });
      }
    } catch {
      setSavedResult({ capacityScore, toleranceScore, goalsScore, totalScore, profileLabel });
    }
    setSaving(false);
    setStage("result");
  };

  const handlePrint = () => {
    window.print();
  };

  if (stage === "result") {
    const r = savedResult;
    const profileColor = getProfileColor(r.profileLabel);
    const allocation = getAssetAllocation(r.profileLabel);

    return (
      <div
        className="min-h-dvh bg-gradient-to-br from-[hsl(40_30%_95%)] via-background to-[hsl(82_15%_95%)] dark:from-[hsl(158_18%_8%)] dark:via-background dark:to-[hsl(82_12%_10%)]"
        data-testid="page-public-risk-result"
      >
        <style>{`
          @media print {
            body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
            .no-print { display: none !important; }
            .print-break { page-break-inside: avoid; }
          }
        `}</style>

        <div className="mx-auto max-w-2xl px-5 py-8" ref={resultRef}>
          <div className="flex items-center gap-3 mb-6 print-break">
            <img src="/images/pfl-logo.jpeg" alt="PFL Financial Advisors" className="h-12 w-auto" />
            <div>
              <h1 className="font-serif text-xl font-semibold text-foreground">Investment Risk Profile</h1>
              <p className="text-sm text-muted-foreground">PFL Financial Advisors</p>
            </div>
          </div>

          <Card className="mb-4 print-break" data-testid="card-result-personal">
            <CardContent className="pt-5">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-muted-foreground">Name</span>
                  <p className="font-medium" data-testid="text-result-name">{firstName} {lastName}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Email</span>
                  <p className="font-medium" data-testid="text-result-email">{email}</p>
                </div>
                {phone && (
                  <div>
                    <span className="text-muted-foreground">Phone</span>
                    <p className="font-medium">{phone}</p>
                  </div>
                )}
                <div>
                  <span className="text-muted-foreground">Date</span>
                  <p className="font-medium">{new Date().toLocaleDateString("en-ZA")}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-4 print-break" data-testid="card-result-profile">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <CheckCircle className="h-4 w-4 text-primary" />
                Your Risk Profile
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="text-center py-3">
                <div
                  className="inline-block rounded-full px-6 py-2.5 text-white font-semibold text-xl"
                  style={{ backgroundColor: profileColor }}
                  data-testid="text-public-profile-label"
                >
                  {r.profileLabel}
                </div>
                <div className="mt-3 text-sm text-muted-foreground max-w-md mx-auto">
                  {getProfileDescription(r.profileLabel)}
                </div>
              </div>

              <div className="space-y-3 text-sm">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-muted-foreground">Financial Safety Net</span>
                    <span className="font-medium">{r.capacityScore} / {SECTION_MAX.capacity}</span>
                  </div>
                  <Progress value={(r.capacityScore / SECTION_MAX.capacity) * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-muted-foreground">Gut Feeling About Risk</span>
                    <span className="font-medium">{r.toleranceScore} / {SECTION_MAX.tolerance}</span>
                  </div>
                  <Progress value={(r.toleranceScore / SECTION_MAX.tolerance) * 100} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-muted-foreground">Goals & Life Circumstances</span>
                    <span className="font-medium">{r.goalsScore} / {SECTION_MAX.goals}</span>
                  </div>
                  <Progress value={(r.goalsScore / SECTION_MAX.goals) * 100} className="h-2" />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between border-t">
                <span className="text-sm font-medium">Total Score</span>
                <span className="text-lg font-semibold font-serif">{r.totalScore} / 120</span>
              </div>
            </CardContent>
          </Card>

          <Card className="mb-4 print-break" data-testid="card-result-allocation">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Indicative Asset Allocation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex rounded-lg overflow-hidden h-8 mb-4">
                {allocation.map((a) => (
                  <div
                    key={a.name}
                    style={{ width: `${a.pct}%`, backgroundColor: a.color }}
                    className="flex items-center justify-center text-xs text-white font-medium"
                    title={`${a.name}: ${a.pct}%`}
                  >
                    {a.pct >= 10 ? `${a.pct}%` : ""}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm">
                {allocation.map((a) => (
                  <div key={a.name} className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-sm shrink-0" style={{ backgroundColor: a.color }} />
                    <span className="text-muted-foreground">{a.name}</span>
                    <span className="ml-auto font-medium">{a.pct}%</span>
                  </div>
                ))}
              </div>
              <p className="mt-4 text-xs text-muted-foreground italic">
                This is an indicative allocation only and does not constitute financial advice. Please consult with a PFL advisor for a personalised investment strategy.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-6 print-break" data-testid="card-result-next">
            <CardContent className="pt-5">
              <h3 className="font-semibold text-sm mb-2">What happens next?</h3>
              <p className="text-sm text-muted-foreground">
                A PFL financial advisor will review your risk profile and reach out to discuss a personalised investment strategy tailored to your unique circumstances. There is no obligation, and the initial consultation is complimentary.
              </p>
              <div className="mt-3 text-sm">
                <p className="text-muted-foreground">Contact us directly:</p>
                <p className="font-medium mt-1">tihan@pfl.co.za &middot; 082 123 4567</p>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-3 no-print" data-testid="actions-result">
            <Button onClick={handlePrint} className="flex-1" data-testid="button-print-result">
              <Printer className="h-4 w-4 mr-2" />
              Print / Save as PDF
            </Button>
            <Link href="/login">
              <Button variant="outline" data-testid="button-back-login">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (stage === "questionnaire") {
    const question = QUESTIONS[currentStep];
    const currentSection = question.section;
    const progress = ((currentStep + 1) / QUESTIONS.length) * 100;

    return (
      <div
        className="min-h-dvh bg-gradient-to-br from-[hsl(40_30%_95%)] via-background to-[hsl(82_15%_95%)] dark:from-[hsl(158_18%_8%)] dark:via-background dark:to-[hsl(82_12%_10%)]"
        data-testid="page-public-risk-questionnaire"
      >
        <div className="mx-auto max-w-lg px-5 py-8">
          <div className="flex items-center gap-3 mb-6">
            <img src="/images/pfl-logo.jpeg" alt="PFL" className="h-10 w-auto" />
            <div>
              <h1 className="font-serif text-lg font-semibold text-foreground">Risk Profile Questionnaire</h1>
              <p className="text-xs text-muted-foreground">For {firstName} {lastName}</p>
            </div>
          </div>

          <Card data-testid="card-public-questionnaire">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                  <Shield className="h-3.5 w-3.5" />
                  {SECTION_LABELS[currentSection]}
                </CardTitle>
                <span className="text-xs text-muted-foreground">
                  {currentStep + 1} of {QUESTIONS.length}
                </span>
              </div>
              <Progress value={progress} className="h-1.5 mt-2" />
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm font-medium leading-relaxed" data-testid="text-public-question">
                {question.text}
              </div>

              <div className="space-y-2">
                {question.options.map((opt, idx) => {
                  const isSelected = answers[question.id] === opt.value;
                  return (
                    <button
                      key={idx}
                      className={`w-full text-left rounded-lg border p-3 text-sm transition-all ${
                        isSelected
                          ? "border-primary bg-primary/10 ring-1 ring-primary/30"
                          : "border-border hover:border-primary/40 hover:bg-muted/50"
                      }`}
                      onClick={() => setAnswers(prev => ({ ...prev, [question.id]: opt.value }))}
                      data-testid={`option-public-${question.id}-${idx}`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (currentStep === 0) {
                      setStage("details");
                    } else {
                      setCurrentStep(s => s - 1);
                    }
                  }}
                  data-testid="button-public-prev"
                >
                  <ChevronLeft className="h-3.5 w-3.5 mr-1" />
                  Back
                </Button>
                <Button
                  size="sm"
                  className="ml-auto"
                  disabled={!answers[question.id] || saving}
                  onClick={() => {
                    if (currentStep < QUESTIONS.length - 1) {
                      setCurrentStep(s => s + 1);
                    } else {
                      handleComplete();
                    }
                  }}
                  data-testid="button-public-next"
                >
                  {currentStep < QUESTIONS.length - 1 ? (
                    <>
                      Next
                      <ChevronRight className="h-3.5 w-3.5 ml-1" />
                    </>
                  ) : saving ? (
                    "Submitting..."
                  ) : (
                    "See My Result"
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-dvh bg-gradient-to-br from-[hsl(40_30%_95%)] via-background to-[hsl(82_15%_95%)] dark:from-[hsl(158_18%_8%)] dark:via-background dark:to-[hsl(82_12%_10%)]"
      data-testid="page-public-risk-details"
    >
      <div className="mx-auto max-w-lg px-5 py-8">
        <div className="flex items-center gap-3 mb-6">
          <img src="/images/pfl-logo.jpeg" alt="PFL Financial Advisors" className="h-12 w-auto" />
          <div>
            <h1 className="font-serif text-xl font-semibold text-foreground">Investment Risk Profile</h1>
            <p className="text-sm text-muted-foreground">PFL Financial Advisors</p>
          </div>
        </div>

        <Card data-testid="card-personal-details">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <User className="h-4 w-4" />
              Your Details
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Complete our quick 12-question assessment to discover your investment risk profile. It takes about 5 minutes, and your personalised result is available immediately.
            </p>

            <form onSubmit={handleDetailsSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="firstName" className="text-sm font-medium">First Name *</label>
                  <Input
                    id="firstName"
                    value={firstName}
                    onChange={e => setFirstName(e.target.value)}
                    required
                    placeholder="e.g. Tihan"
                    className="mt-1"
                    data-testid="input-public-firstname"
                  />
                </div>
                <div>
                  <label htmlFor="lastName" className="text-sm font-medium">Last Name *</label>
                  <Input
                    id="lastName"
                    value={lastName}
                    onChange={e => setLastName(e.target.value)}
                    required
                    placeholder="e.g. Bezuidenhout"
                    className="mt-1"
                    data-testid="input-public-lastname"
                  />
                </div>
              </div>
              <div>
                <label htmlFor="email" className="text-sm font-medium">Email Address *</label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  required
                  placeholder="you@example.com"
                  className="mt-1"
                  data-testid="input-public-email"
                />
              </div>
              <div>
                <label htmlFor="phone" className="text-sm font-medium">Phone Number</label>
                <Input
                  id="phone"
                  type="tel"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="082 123 4567"
                  className="mt-1"
                  data-testid="input-public-phone"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <Link href="/login">
                  <Button type="button" variant="outline" data-testid="button-public-back-login">
                    <ArrowLeft className="h-4 w-4 mr-1" />
                    Back
                  </Button>
                </Link>
                <Button type="submit" className="flex-1" data-testid="button-start-public-questionnaire">
                  Start Questionnaire
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </form>

            <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
              <Shield className="h-3 w-3" />
              Your information is kept confidential and used only to provide your risk profile assessment.
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}