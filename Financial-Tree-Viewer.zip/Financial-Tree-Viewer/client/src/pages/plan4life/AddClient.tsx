import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Plus, Trash2, CheckCircle2, UserPlus, ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";

type DependantRow = { name: string; age: string };
type AssetRow = {
  category: string;
  description: string;
  currency: string;
  baseCost: string;
  marketValue: string;
  ownerShare: string;
  assetClass: string;
  provider: string;
  accountType: string;
  accountName: string;
  beneficiary: string;
};
type LiabilityRow = {
  category: string;
  description: string;
  currency: string;
  amount: string;
  ownerShare: string;
  interestRate: string;
};

const emptyAsset = (): AssetRow => ({
  category: "Other assets",
  description: "",
  currency: "ZAR",
  baseCost: "0",
  marketValue: "0",
  ownerShare: "100",
  assetClass: "Other",
  provider: "",
  accountType: "Other",
  accountName: "",
  beneficiary: "",
});

const emptyLiability = (): LiabilityRow => ({
  category: "Bond",
  description: "",
  currency: "ZAR",
  amount: "0",
  ownerShare: "100",
  interestRate: "",
});

export default function AddClient() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const [newClientId, setNewClientId] = useState<string | null>(null);

  const [form, setForm] = useState({
    name: "",
    initials: "",
    age: "",
    idNumber: "",
    maritalStatus: "Single",
    addressHome: "",
    addressPostal: "",
    contactCell: "",
    contactEmail: "",
    taxReference: "",
    taxOffice: "",
    annualSpend: "",
    monthlySpend: "",
    existingMonthlyIncome: "",
    liquidAssets: "",
    lifeCover: "",
    disabilityIncomeMonthly: "",
    disabilityLumpSum: "",
    dreadDisease: "",
    medicalPlanName: "",
    gapCover: false,
    willStatus: "none",
    executorNamed: false,
    beneficiaryAlignment: "unknown",
    liquidityAdequate: false,
    ficaStatus: "missing",
    raAnnualContribution: "",
    raAnnualLimit: "350000",
    tfsaContributionLifetime: "",
    tfsaLifetimeLimit: "500000",
  });

  const [dependants, setDependants] = useState<DependantRow[]>([]);
  const [assets, setAssets] = useState<AssetRow[]>([]);
  const [liabilities, setLiabilities] = useState<LiabilityRow[]>([]);

  const set = (field: string, value: any) => setForm((p) => ({ ...p, [field]: value }));

  const mutation = useMutation({
    mutationFn: async (payload: any) => {
      const res = await apiRequest("POST", "/api/clients", payload);
      return res.json();
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      setNewClientId(data.id);
      setSubmitted(true);
      toast({ title: "Client added successfully" });
    },
    onError: (e: any) => {
      toast({ title: "Error adding client", description: e.message, variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      toast({ title: "Client name is required", variant: "destructive" });
      return;
    }
    if (!form.age || isNaN(Number(form.age))) {
      toast({ title: "Please enter a valid age", variant: "destructive" });
      return;
    }

    const clientData: any = {
      name: form.name.trim(),
      initials: form.initials.trim(),
      age: parseInt(form.age) || 0,
      idNumber: form.idNumber.trim(),
      maritalStatus: form.maritalStatus,
      addressHome: form.addressHome.trim(),
      addressPostal: form.addressPostal.trim(),
      contactCell: form.contactCell.trim(),
      contactEmail: form.contactEmail.trim(),
      taxReference: form.taxReference.trim(),
      taxOffice: form.taxOffice.trim(),
      annualSpend: parseInt(form.annualSpend) || 0,
      monthlySpend: parseInt(form.monthlySpend) || 0,
      existingMonthlyIncome: parseInt(form.existingMonthlyIncome) || 0,
      liquidAssets: parseInt(form.liquidAssets) || 0,
      lifeCover: parseInt(form.lifeCover) || 0,
      disabilityIncomeMonthly: parseInt(form.disabilityIncomeMonthly) || 0,
      disabilityLumpSum: parseInt(form.disabilityLumpSum) || 0,
      dreadDisease: parseInt(form.dreadDisease) || 0,
      medicalPlanName: form.medicalPlanName.trim(),
      gapCover: form.gapCover,
      willStatus: form.willStatus,
      executorNamed: form.executorNamed,
      beneficiaryAlignment: form.beneficiaryAlignment,
      liquidityAdequate: form.liquidityAdequate,
      ficaStatus: form.ficaStatus,
      raAnnualContribution: parseInt(form.raAnnualContribution) || 0,
      raAnnualLimit: parseInt(form.raAnnualLimit) || 350000,
      tfsaContributionLifetime: parseInt(form.tfsaContributionLifetime) || 0,
      tfsaLifetimeLimit: parseInt(form.tfsaLifetimeLimit) || 500000,
    };

    const depsPayload = dependants
      .filter((d) => d.name.trim())
      .map((d) => ({ name: d.name.trim(), age: parseInt(d.age) || 0 }));

    const assetsPayload = assets
      .filter((a) => a.description.trim())
      .map((a) => ({
        category: a.category,
        description: a.description.trim(),
        currency: a.currency,
        baseCost: parseInt(a.baseCost) || 0,
        marketValue: parseInt(a.marketValue) || 0,
        ownerShare: parseInt(a.ownerShare) || 100,
        included: true,
        assetClass: a.assetClass,
        provider: a.provider.trim(),
        accountType: a.accountType,
        accountName: a.accountName.trim(),
        beneficiary: a.beneficiary.trim(),
      }));

    const liabPayload = liabilities
      .filter((l) => l.description.trim())
      .map((l) => ({
        category: l.category,
        description: l.description.trim(),
        currency: l.currency,
        amount: parseInt(l.amount) || 0,
        ownerShare: parseInt(l.ownerShare) || 100,
        included: true,
        interestRate: l.interestRate ? parseFloat(l.interestRate) : null,
      }));

    mutation.mutate({
      client: clientData,
      dependants: depsPayload,
      assets: assetsPayload,
      liabilities: liabPayload,
    });
  };

  if (submitted) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-12">
        <Card className="rounded-2xl text-center">
          <CardContent className="py-12">
            <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-primary/10">
              <CheckCircle2 className="h-8 w-8 text-primary" />
            </div>
            <h2 className="font-serif text-2xl font-semibold mb-2" data-testid="text-client-added-success">
              Client Added Successfully
            </h2>
            <p className="text-muted-foreground mb-6">
              {form.name} has been added to your client list and is ready for review.
            </p>
            <div className="flex justify-center gap-3">
              {newClientId && (
                <Button onClick={() => navigate(`/client/${newClientId}`)} data-testid="button-view-new-client">
                  View Client
                </Button>
              )}
              <Button variant="outline" onClick={() => navigate("/clients")} data-testid="button-back-to-clients">
                Back to Client List
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setSubmitted(false);
                  setNewClientId(null);
                  setForm({
                    name: "", initials: "", age: "", idNumber: "", maritalStatus: "Single",
                    addressHome: "", addressPostal: "", contactCell: "", contactEmail: "",
                    taxReference: "", taxOffice: "", annualSpend: "", monthlySpend: "",
                    existingMonthlyIncome: "", liquidAssets: "", lifeCover: "",
                    disabilityIncomeMonthly: "", disabilityLumpSum: "", dreadDisease: "",
                    medicalPlanName: "", gapCover: false, willStatus: "none",
                    executorNamed: false, beneficiaryAlignment: "unknown", liquidityAdequate: false,
                    ficaStatus: "missing", raAnnualContribution: "", raAnnualLimit: "350000",
                    tfsaContributionLifetime: "", tfsaLifetimeLimit: "500000",
                  });
                  setDependants([]);
                  setAssets([]);
                  setLiabilities([]);
                }}
                data-testid="button-add-another-client"
              >
                Add Another Client
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="mb-6 flex items-center gap-3">
        <Link href="/clients" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-back-clients">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="font-serif text-2xl font-semibold" data-testid="text-add-client-title">Add New Client</h1>
          <p className="text-sm text-muted-foreground">Enter the client's details below. Fields marked with * are required.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Personal Information</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input id="name" value={form.name} onChange={(e) => set("name", e.target.value)} data-testid="input-client-name" required />
            </div>
            <div>
              <Label htmlFor="initials">Initials</Label>
              <Input id="initials" value={form.initials} onChange={(e) => set("initials", e.target.value)} data-testid="input-client-initials" />
            </div>
            <div>
              <Label htmlFor="age">Age *</Label>
              <Input id="age" type="number" value={form.age} onChange={(e) => set("age", e.target.value)} data-testid="input-client-age" required />
            </div>
            <div>
              <Label htmlFor="idNumber">SA ID Number</Label>
              <Input id="idNumber" value={form.idNumber} onChange={(e) => set("idNumber", e.target.value)} data-testid="input-client-id-number" />
            </div>
            <div>
              <Label>Marital Status</Label>
              <Select value={form.maritalStatus} onValueChange={(v) => set("maritalStatus", v)}>
                <SelectTrigger data-testid="select-marital-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Single">Single</SelectItem>
                  <SelectItem value="Married">Married</SelectItem>
                  <SelectItem value="Divorced">Divorced</SelectItem>
                  <SelectItem value="Widowed">Widowed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Contact Details</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="contactCell">Cell Phone</Label>
              <Input id="contactCell" value={form.contactCell} onChange={(e) => set("contactCell", e.target.value)} data-testid="input-contact-cell" />
            </div>
            <div>
              <Label htmlFor="contactEmail">Email Address</Label>
              <Input id="contactEmail" type="email" value={form.contactEmail} onChange={(e) => set("contactEmail", e.target.value)} data-testid="input-contact-email" />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="addressHome">Home Address</Label>
              <Input id="addressHome" value={form.addressHome} onChange={(e) => set("addressHome", e.target.value)} data-testid="input-address-home" />
            </div>
            <div className="sm:col-span-2">
              <Label htmlFor="addressPostal">Postal Address</Label>
              <Input id="addressPostal" value={form.addressPostal} onChange={(e) => set("addressPostal", e.target.value)} data-testid="input-address-postal" />
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Tax Information</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="taxReference">Tax Reference Number</Label>
              <Input id="taxReference" value={form.taxReference} onChange={(e) => set("taxReference", e.target.value)} data-testid="input-tax-reference" />
            </div>
            <div>
              <Label htmlFor="taxOffice">Tax Office / Branch</Label>
              <Input id="taxOffice" value={form.taxOffice} onChange={(e) => set("taxOffice", e.target.value)} data-testid="input-tax-office" />
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Household Finances</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="monthlySpend">Monthly Expenditure (R)</Label>
              <Input id="monthlySpend" type="number" value={form.monthlySpend} onChange={(e) => set("monthlySpend", e.target.value)} data-testid="input-monthly-spend" />
            </div>
            <div>
              <Label htmlFor="annualSpend">Annual Expenditure (R)</Label>
              <Input id="annualSpend" type="number" value={form.annualSpend} onChange={(e) => set("annualSpend", e.target.value)} data-testid="input-annual-spend" />
            </div>
            <div>
              <Label htmlFor="existingMonthlyIncome">Existing Monthly Income (R)</Label>
              <Input id="existingMonthlyIncome" type="number" value={form.existingMonthlyIncome} onChange={(e) => set("existingMonthlyIncome", e.target.value)} data-testid="input-monthly-income" />
            </div>
            <div>
              <Label htmlFor="liquidAssets">Liquid Assets (R)</Label>
              <Input id="liquidAssets" type="number" value={form.liquidAssets} onChange={(e) => set("liquidAssets", e.target.value)} data-testid="input-liquid-assets" />
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base">Dependants</CardTitle>
            <Button type="button" variant="outline" size="sm" onClick={() => setDependants([...dependants, { name: "", age: "" }])} data-testid="button-add-dependant">
              <Plus className="mr-1 h-4 w-4" /> Add
            </Button>
          </CardHeader>
          <CardContent>
            {dependants.length === 0 && (
              <p className="text-sm text-muted-foreground">No dependants added yet.</p>
            )}
            {dependants.map((dep, i) => (
              <div key={i} className="mb-3 flex items-end gap-3">
                <div className="flex-1">
                  {i === 0 && <Label>Name</Label>}
                  <Input
                    value={dep.name}
                    onChange={(e) => {
                      const next = [...dependants];
                      next[i] = { ...next[i], name: e.target.value };
                      setDependants(next);
                    }}
                    data-testid={`input-dependant-name-${i}`}
                  />
                </div>
                <div className="w-24">
                  {i === 0 && <Label>Age</Label>}
                  <Input
                    type="number"
                    value={dep.age}
                    onChange={(e) => {
                      const next = [...dependants];
                      next[i] = { ...next[i], age: e.target.value };
                      setDependants(next);
                    }}
                    data-testid={`input-dependant-age-${i}`}
                  />
                </div>
                <Button type="button" variant="ghost" size="icon" onClick={() => setDependants(dependants.filter((_, j) => j !== i))} data-testid={`button-remove-dependant-${i}`}>
                  <Trash2 className="h-4 w-4 text-muted-foreground" />
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Risk Cover</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="lifeCover">Life Cover (R)</Label>
              <Input id="lifeCover" type="number" value={form.lifeCover} onChange={(e) => set("lifeCover", e.target.value)} data-testid="input-life-cover" />
            </div>
            <div>
              <Label htmlFor="disabilityIncomeMonthly">Disability Income — Monthly (R)</Label>
              <Input id="disabilityIncomeMonthly" type="number" value={form.disabilityIncomeMonthly} onChange={(e) => set("disabilityIncomeMonthly", e.target.value)} data-testid="input-disability-income" />
            </div>
            <div>
              <Label htmlFor="disabilityLumpSum">Disability Lump Sum (R)</Label>
              <Input id="disabilityLumpSum" type="number" value={form.disabilityLumpSum} onChange={(e) => set("disabilityLumpSum", e.target.value)} data-testid="input-disability-lump" />
            </div>
            <div>
              <Label htmlFor="dreadDisease">Dread Disease / Critical Illness (R)</Label>
              <Input id="dreadDisease" type="number" value={form.dreadDisease} onChange={(e) => set("dreadDisease", e.target.value)} data-testid="input-dread-disease" />
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Medical Aid</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="medicalPlanName">Medical Aid Plan</Label>
              <Input id="medicalPlanName" value={form.medicalPlanName} onChange={(e) => set("medicalPlanName", e.target.value)} data-testid="input-medical-plan" />
            </div>
            <div className="flex items-end gap-2 pb-1">
              <Checkbox id="gapCover" checked={form.gapCover} onCheckedChange={(v) => set("gapCover", !!v)} data-testid="checkbox-gap-cover" />
              <Label htmlFor="gapCover" className="cursor-pointer">Gap Cover in place</Label>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Estate Planning</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label>Will Status</Label>
              <Select value={form.willStatus} onValueChange={(v) => set("willStatus", v)}>
                <SelectTrigger data-testid="select-will-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="in_place">In Place</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="none">None</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end gap-2 pb-1">
              <Checkbox id="executorNamed" checked={form.executorNamed} onCheckedChange={(v) => set("executorNamed", !!v)} data-testid="checkbox-executor" />
              <Label htmlFor="executorNamed" className="cursor-pointer">Executor Named</Label>
            </div>
            <div>
              <Label>Beneficiary Alignment</Label>
              <Select value={form.beneficiaryAlignment} onValueChange={(v) => set("beneficiaryAlignment", v)}>
                <SelectTrigger data-testid="select-beneficiary-alignment"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="aligned">Aligned</SelectItem>
                  <SelectItem value="partial">Partially Aligned</SelectItem>
                  <SelectItem value="unknown">Unknown / Not Reviewed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end gap-2 pb-1">
              <Checkbox id="liquidityAdequate" checked={form.liquidityAdequate} onCheckedChange={(v) => set("liquidityAdequate", !!v)} data-testid="checkbox-liquidity" />
              <Label htmlFor="liquidityAdequate" className="cursor-pointer">Liquidity Adequate</Label>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Compliance & Documents</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label>FICA Status</Label>
              <Select value={form.ficaStatus} onValueChange={(v) => set("ficaStatus", v)}>
                <SelectTrigger data-testid="select-fica-status"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="complete">Complete</SelectItem>
                  <SelectItem value="partial">Partial</SelectItem>
                  <SelectItem value="missing">Missing</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader><CardTitle className="text-base">Tax Planning</CardTitle></CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label htmlFor="raAnnualContribution">RA Annual Contribution (R)</Label>
              <Input id="raAnnualContribution" type="number" value={form.raAnnualContribution} onChange={(e) => set("raAnnualContribution", e.target.value)} data-testid="input-ra-contribution" />
            </div>
            <div>
              <Label htmlFor="raAnnualLimit">RA Annual Limit (R)</Label>
              <Input id="raAnnualLimit" type="number" value={form.raAnnualLimit} onChange={(e) => set("raAnnualLimit", e.target.value)} data-testid="input-ra-limit" />
            </div>
            <div>
              <Label htmlFor="tfsaContributionLifetime">TFSA Lifetime Contribution (R)</Label>
              <Input id="tfsaContributionLifetime" type="number" value={form.tfsaContributionLifetime} onChange={(e) => set("tfsaContributionLifetime", e.target.value)} data-testid="input-tfsa-contribution" />
            </div>
            <div>
              <Label htmlFor="tfsaLifetimeLimit">TFSA Lifetime Limit (R)</Label>
              <Input id="tfsaLifetimeLimit" type="number" value={form.tfsaLifetimeLimit} onChange={(e) => set("tfsaLifetimeLimit", e.target.value)} data-testid="input-tfsa-limit" />
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base">Assets & Investments</CardTitle>
            <Button type="button" variant="outline" size="sm" onClick={() => setAssets([...assets, emptyAsset()])} data-testid="button-add-asset">
              <Plus className="mr-1 h-4 w-4" /> Add Asset
            </Button>
          </CardHeader>
          <CardContent>
            {assets.length === 0 && (
              <p className="text-sm text-muted-foreground">No assets added yet. You can add these later from the client dashboard.</p>
            )}
            {assets.map((asset, i) => (
              <div key={i} className="mb-4 rounded-lg border p-4">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-medium">Asset {i + 1}</span>
                  <Button type="button" variant="ghost" size="icon" onClick={() => setAssets(assets.filter((_, j) => j !== i))} data-testid={`button-remove-asset-${i}`}>
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label>Category</Label>
                    <Select value={asset.category} onValueChange={(v) => { const next = [...assets]; next[i] = { ...next[i], category: v }; setAssets(next); }}>
                      <SelectTrigger data-testid={`select-asset-category-${i}`}><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Retirement funds">Retirement Funds</SelectItem>
                        <SelectItem value="Voluntary investments">Voluntary Investments</SelectItem>
                        <SelectItem value="Business interests">Business Interests</SelectItem>
                        <SelectItem value="Personal effects">Personal Effects</SelectItem>
                        <SelectItem value="Property">Property</SelectItem>
                        <SelectItem value="Other assets">Other Assets</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Description</Label>
                    <Input value={asset.description} onChange={(e) => { const next = [...assets]; next[i] = { ...next[i], description: e.target.value }; setAssets(next); }} data-testid={`input-asset-description-${i}`} />
                  </div>
                  <div>
                    <Label>Market Value (R)</Label>
                    <Input type="number" value={asset.marketValue} onChange={(e) => { const next = [...assets]; next[i] = { ...next[i], marketValue: e.target.value }; setAssets(next); }} data-testid={`input-asset-value-${i}`} />
                  </div>
                  <div>
                    <Label>Base Cost (R)</Label>
                    <Input type="number" value={asset.baseCost} onChange={(e) => { const next = [...assets]; next[i] = { ...next[i], baseCost: e.target.value }; setAssets(next); }} data-testid={`input-asset-base-cost-${i}`} />
                  </div>
                  <div>
                    <Label>Provider</Label>
                    <Input value={asset.provider} onChange={(e) => { const next = [...assets]; next[i] = { ...next[i], provider: e.target.value }; setAssets(next); }} data-testid={`input-asset-provider-${i}`} />
                  </div>
                  <div>
                    <Label>Account Type</Label>
                    <Select value={asset.accountType} onValueChange={(v) => { const next = [...assets]; next[i] = { ...next[i], accountType: v }; setAssets(next); }}>
                      <SelectTrigger data-testid={`select-asset-account-type-${i}`}><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="RA">Retirement Annuity</SelectItem>
                        <SelectItem value="TFSA">Tax-Free Savings</SelectItem>
                        <SelectItem value="Unit Trust">Unit Trust</SelectItem>
                        <SelectItem value="Endowment">Endowment</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Account Name</Label>
                    <Input value={asset.accountName} onChange={(e) => { const next = [...assets]; next[i] = { ...next[i], accountName: e.target.value }; setAssets(next); }} data-testid={`input-asset-account-name-${i}`} />
                  </div>
                  <div>
                    <Label>Beneficiary</Label>
                    <Input value={asset.beneficiary} onChange={(e) => { const next = [...assets]; next[i] = { ...next[i], beneficiary: e.target.value }; setAssets(next); }} data-testid={`input-asset-beneficiary-${i}`} />
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base">Liabilities</CardTitle>
            <Button type="button" variant="outline" size="sm" onClick={() => setLiabilities([...liabilities, emptyLiability()])} data-testid="button-add-liability">
              <Plus className="mr-1 h-4 w-4" /> Add Liability
            </Button>
          </CardHeader>
          <CardContent>
            {liabilities.length === 0 && (
              <p className="text-sm text-muted-foreground">No liabilities added yet. You can add these later from the client dashboard.</p>
            )}
            {liabilities.map((liab, i) => (
              <div key={i} className="mb-4 rounded-lg border p-4">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-medium">Liability {i + 1}</span>
                  <Button type="button" variant="ghost" size="icon" onClick={() => setLiabilities(liabilities.filter((_, j) => j !== i))} data-testid={`button-remove-liability-${i}`}>
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <Label>Category</Label>
                    <Select value={liab.category} onValueChange={(v) => { const next = [...liabilities]; next[i] = { ...next[i], category: v }; setLiabilities(next); }}>
                      <SelectTrigger data-testid={`select-liability-category-${i}`}><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Bond">Home Loan / Bond</SelectItem>
                        <SelectItem value="Vehicle finance">Vehicle Finance</SelectItem>
                        <SelectItem value="Credit card">Credit Card</SelectItem>
                        <SelectItem value="Personal loan">Personal Loan</SelectItem>
                        <SelectItem value="Study loan">Study Loan</SelectItem>
                        <SelectItem value="Other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Description</Label>
                    <Input value={liab.description} onChange={(e) => { const next = [...liabilities]; next[i] = { ...next[i], description: e.target.value }; setLiabilities(next); }} data-testid={`input-liability-description-${i}`} />
                  </div>
                  <div>
                    <Label>Outstanding Amount (R)</Label>
                    <Input type="number" value={liab.amount} onChange={(e) => { const next = [...liabilities]; next[i] = { ...next[i], amount: e.target.value }; setLiabilities(next); }} data-testid={`input-liability-amount-${i}`} />
                  </div>
                  <div>
                    <Label>Interest Rate (%)</Label>
                    <Input type="number" step="0.1" value={liab.interestRate} onChange={(e) => { const next = [...liabilities]; next[i] = { ...next[i], interestRate: e.target.value }; setLiabilities(next); }} data-testid={`input-liability-rate-${i}`} />
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <div className="flex justify-end gap-3 pb-12">
          <Button type="button" variant="outline" onClick={() => navigate("/clients")} data-testid="button-cancel-add-client">
            Cancel
          </Button>
          <Button type="submit" disabled={mutation.isPending} data-testid="button-submit-add-client">
            <UserPlus className="mr-2 h-4 w-4" />
            {mutation.isPending ? "Saving..." : "Add Client"}
          </Button>
        </div>
      </form>
    </div>
  );
}
