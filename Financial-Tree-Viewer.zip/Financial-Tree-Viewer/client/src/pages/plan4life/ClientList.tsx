import React from "react";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UserPlus } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { defaultAssumptions } from "@/lib/plan4life/demoData";
import { useClients } from "@/lib/plan4life/api";
import { AgeAnalysisPanel } from "@/components/plan4life/AgeAnalysisPanel";
import {
  aum,
  estateReadinessBadge,
  ficaDue,
  reviewDue,
  riskHasShortfall,
  sumInvestments,
} from "@/lib/plan4life/compute";
import { formatDate, formatZar } from "@/lib/plan4life/format";

type AumFilter = "all" | "0-500k" | "500k-1.5m" | "1.5m+";

type EstateFilter = "all" | "green" | "amber" | "red";

export default function ClientList() {
  const { data: apiClients, isLoading } = useClients();
  const [query, setQuery] = React.useState("");
  const [aumFilter, setAumFilter] = React.useState<AumFilter>("all");
  const [estateFilter, setEstateFilter] = React.useState<EstateFilter>("all");
  const [filterReviewDue, setFilterReviewDue] = React.useState(false);
  const [filterRiskShortfall, setFilterRiskShortfall] = React.useState(false);
  const [filterFicaDue, setFilterFicaDue] = React.useState(false);

  const normalizedQuery = query.trim().toLowerCase();

  const derived = React.useMemo(() => {
    const rows = (apiClients ?? []).map((c) => {
      const estate = estateReadinessBadge(c);
      const riskShort = riskHasShortfall(c, defaultAssumptions);
      const review = reviewDue(c);
      const fica = ficaDue(c);
      const total = sumInvestments(c);
      return { c, estate, riskShort, review, fica, total };
    });

    const insights = {
      willMissing: rows.filter((r) => r.c.estate.willStatus === "none").length,
      ficaOverdue: rows.filter((r) => r.fica).length,
      riskShortfall: rows.filter((r) => r.riskShort).length,
      estateRed: rows.filter((r) => r.estate === "red").length,
      reviewDue: rows.filter((r) => r.review).length,
    };

    const filtered = rows.filter(({ c, estate, riskShort, review, fica, total }) => {
      if (normalizedQuery && !c.name.toLowerCase().includes(normalizedQuery)) return false;

      if (aumFilter !== "all") {
        if (aumFilter === "0-500k" && !(total < 500000)) return false;
        if (aumFilter === "500k-1.5m" && !(total >= 500000 && total < 1500000)) return false;
        if (aumFilter === "1.5m+" && !(total >= 1500000)) return false;
      }

      if (estateFilter !== "all" && estate !== estateFilter) return false;
      if (filterReviewDue && !review) return false;
      if (filterRiskShortfall && !riskShort) return false;
      if (filterFicaDue && !fica) return false;

      return true;
    });

    return { rows: filtered, insights };
  }, [apiClients, normalizedQuery, aumFilter, estateFilter, filterReviewDue, filterRiskShortfall, filterFicaDue]);

  const pill = (tone: "green" | "amber" | "red") =>
    tone === "green"
      ? "text-primary bg-primary/10 border-primary/15"
      : tone === "amber"
        ? "text-amber-700 bg-amber-500/10 border-amber-500/15"
        : "text-red-700 bg-red-500/10 border-red-500/15";

  const toneBadge = (t: "green" | "amber" | "red") =>
    t === "green" ? "default" : t === "amber" ? "secondary" : "destructive";

  const applyInsight = (key: keyof typeof derived.insights) => {
    if (key === "willMissing") setEstateFilter("all");
    if (key === "ficaOverdue") setFilterFicaDue(true);
    if (key === "riskShortfall") setFilterRiskShortfall(true);
    if (key === "estateRed") setEstateFilter("red");
    if (key === "reviewDue") setFilterReviewDue(true);
  };

  const clearFilters = () => {
    setQuery("");
    setAumFilter("all");
    setEstateFilter("all");
    setFilterReviewDue(false);
    setFilterRiskShortfall(false);
    setFilterFicaDue(false);
  };

  if (isLoading) {
    return (
      <div className="mx-auto w-full max-w-6xl px-4 py-8">
        <div className="text-sm text-muted-foreground">Loading clients...</div>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-8">
      <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="flex items-center gap-4">
            <div className="font-serif text-3xl font-semibold tracking-tight" data-testid="text-clients-title">
              Clients
            </div>
            <Link href="/clients/add">
              <Button size="sm" data-testid="button-add-client">
                <UserPlus className="mr-2 h-4 w-4" /> Add Client
              </Button>
            </Link>
          </div>
          <div className="mt-1 text-sm text-muted-foreground" data-testid="text-clients-subtitle">
            Manage your client book and identify opportunities
          </div>
        </div>

        <div className="flex flex-col gap-2 md:w-[420px]">
          <Input
            type="search"
            placeholder="Search clients..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            data-testid="input-search"
          />
          <div className="text-xs text-muted-foreground" data-testid="text-search-hint">
            Click an insight to auto-filter your client list.
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          <div className="grid gap-3 rounded-2xl border bg-card p-4 shadow-sm p4l-noise md:grid-cols-5">
            <div className="md:col-span-2">
              <div className="text-xs text-muted-foreground" data-testid="text-filter-aum-label">AUM range</div>
              <Select value={aumFilter} onValueChange={(v) => setAumFilter(v as AumFilter)}>
                <SelectTrigger className="mt-2" data-testid="select-aum">
                  <SelectValue placeholder="AUM" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="0-500k">Under R500k</SelectItem>
                  <SelectItem value="500k-1.5m">R500k – R1.5m</SelectItem>
                  <SelectItem value="1.5m+">R1.5m+</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="md:col-span-2">
              <div className="text-xs text-muted-foreground" data-testid="text-filter-estate-label">Estate readiness</div>
              <Select value={estateFilter} onValueChange={(v) => setEstateFilter(v as EstateFilter)}>
                <SelectTrigger className="mt-2" data-testid="select-estate">
                  <SelectValue placeholder="Estate" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="green">Green</SelectItem>
                  <SelectItem value="amber">Amber</SelectItem>
                  <SelectItem value="red">Red</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <button
                className="mt-6 w-full rounded-xl border bg-background px-3 py-2 text-sm hover-elevate transition"
                onClick={clearFilters}
                data-testid="button-clear-filters"
              >
                Clear
              </button>
            </div>

            <div className="md:col-span-5 grid gap-3 pt-2 md:grid-cols-3">
              <label className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2" data-testid="row-filter-review">
                <span className="text-sm" data-testid="text-filter-review">Review due</span>
                <Switch checked={filterReviewDue} onCheckedChange={setFilterReviewDue} data-testid="switch-review-due" />
              </label>
              <label className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2" data-testid="row-filter-risk">
                <span className="text-sm" data-testid="text-filter-risk">Risk shortfall</span>
                <Switch checked={filterRiskShortfall} onCheckedChange={setFilterRiskShortfall} data-testid="switch-risk-shortfall" />
              </label>
              <label className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2" data-testid="row-filter-fica">
                <span className="text-sm" data-testid="text-filter-fica">FICA due</span>
                <Switch checked={filterFicaDue} onCheckedChange={setFilterFicaDue} data-testid="switch-fica-due" />
              </label>
            </div>
          </div>

          <div className="grid gap-3">
            {derived.rows.map(({ c, estate, riskShort, review, fica, total }) => (
              <Link
                key={c.id}
                href={`/client/${c.id}`}
                className="block"
                data-testid={`link-client-${c.id}`}
              >
                <Card className="hover-elevate rounded-2xl p-4 shadow-sm transition" data-testid={`card-client-${c.id}`}>
                  <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <div className="text-base font-medium" data-testid={`text-client-name-${c.id}`}>{c.name}</div>
                        <Badge
                          variant={toneBadge(estate)}
                          className={"border " + pill(estate)}
                          data-testid={`badge-estate-${c.id}`}
                        >
                          Estate: {estate}
                        </Badge>
                        {riskShort && (
                          <Badge
                            variant="secondary"
                            className="border border-amber-500/15 bg-amber-500/10 text-amber-800"
                            data-testid={`badge-risk-${c.id}`}
                          >
                            Risk shortfall
                          </Badge>
                        )}
                      </div>
                      <div className="mt-1 text-sm text-muted-foreground" data-testid={`text-client-meta-${c.id}`}>
                        {c.age} · {c.maritalStatus} · Dependants: {c.dependants.length}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
                      <div className="rounded-xl border bg-background/60 px-3 py-2" data-testid={`stat-aum-${c.id}`}>
                        <div className="text-[11px] text-muted-foreground" data-testid={`label-aum-${c.id}`}>AUM</div>
                        <div className="text-sm font-medium" data-testid={`value-aum-${c.id}`}>{formatZar(aum(c))}</div>
                      </div>
                      <div className="rounded-xl border bg-background/60 px-3 py-2" data-testid={`stat-lastreview-${c.id}`}>
                        <div className="text-[11px] text-muted-foreground" data-testid={`label-lastreview-${c.id}`}>Last review</div>
                        <div className="text-sm font-medium" data-testid={`value-lastreview-${c.id}`}>{formatDate(c.lastReviewISO)}</div>
                      </div>
                      <div className="rounded-xl border bg-background/60 px-3 py-2" data-testid={`stat-reviewdue-${c.id}`}>
                        <div className="text-[11px] text-muted-foreground" data-testid={`label-reviewdue-${c.id}`}>Review due</div>
                        <div className="text-sm font-medium" data-testid={`value-reviewdue-${c.id}`}>{review ? "Yes" : "No"}</div>
                      </div>
                      <div className="rounded-xl border bg-background/60 px-3 py-2" data-testid={`stat-fica-${c.id}`}>
                        <div className="text-[11px] text-muted-foreground" data-testid={`label-fica-${c.id}`}>FICA</div>
                        <div className="text-sm font-medium" data-testid={`value-fica-${c.id}`}>{fica ? "Due" : "OK"}</div>
                      </div>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}

            {!derived.rows.length && (
              <div className="rounded-2xl border bg-card p-6 text-sm text-muted-foreground" data-testid="empty-clients">
                No clients match your filters.
              </div>
            )}
          </div>
        </div>

        <aside className="space-y-3">
          <AgeAnalysisPanel clients={derived.rows.map((r) => r.c)} />

          <div className="rounded-2xl border bg-card p-4 shadow-sm p4l-noise" data-testid="panel-insights">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium" data-testid="text-insights-title">Insights</div>
                <div className="text-xs text-muted-foreground" data-testid="text-insights-subtitle">
                  Servicing opportunities
                </div>
              </div>
              <div className="text-xs text-muted-foreground" data-testid="text-insights-count">
                {(apiClients ?? []).length} clients
              </div>
            </div>

            <div className="mt-4 grid gap-2">
              <button
                className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2 text-left hover-elevate transition"
                onClick={() => applyInsight("willMissing")}
                data-testid="button-insight-will-missing"
              >
                <span className="text-sm" data-testid="text-insight-will">Will missing</span>
                <span className="text-sm font-semibold" data-testid="value-insight-will">{derived.insights.willMissing}</span>
              </button>
              <button
                className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2 text-left hover-elevate transition"
                onClick={() => applyInsight("ficaOverdue")}
                data-testid="button-insight-fica-overdue"
              >
                <span className="text-sm" data-testid="text-insight-fica">FICA overdue</span>
                <span className="text-sm font-semibold" data-testid="value-insight-fica">{derived.insights.ficaOverdue}</span>
              </button>
              <button
                className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2 text-left hover-elevate transition"
                onClick={() => applyInsight("riskShortfall")}
                data-testid="button-insight-risk-shortfall"
              >
                <span className="text-sm" data-testid="text-insight-risk">Risk shortfall</span>
                <span className="text-sm font-semibold" data-testid="value-insight-risk">{derived.insights.riskShortfall}</span>
              </button>
              <button
                className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2 text-left hover-elevate transition"
                onClick={() => applyInsight("estateRed")}
                data-testid="button-insight-estate-red"
              >
                <span className="text-sm" data-testid="text-insight-estate">Estate at risk</span>
                <span className="text-sm font-semibold" data-testid="value-insight-estate">{derived.insights.estateRed}</span>
              </button>
              <button
                className="flex items-center justify-between rounded-xl border bg-background/60 px-3 py-2 text-left hover-elevate transition"
                onClick={() => applyInsight("reviewDue")}
                data-testid="button-insight-review-due"
              >
                <span className="text-sm" data-testid="text-insight-review">Review due</span>
                <span className="text-sm font-semibold" data-testid="value-insight-review">{derived.insights.reviewDue}</span>
              </button>
            </div>
          </div>

          <div className="rounded-2xl border bg-card p-4 text-sm text-muted-foreground" data-testid="panel-notes">
            <div className="font-medium text-foreground" data-testid="text-notes-title">CRM Integration</div>
            <div className="mt-2" data-testid="text-notes-body">
              Client data will sync automatically once connected to Elite Wealth CRM. Contact your administrator to enable the integration.
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
