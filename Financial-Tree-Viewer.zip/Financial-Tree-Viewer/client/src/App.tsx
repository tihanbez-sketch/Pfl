import { Switch, Route, Redirect, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { ModeProvider } from "@/lib/plan4life/mode";
import { TopNav } from "@/components/plan4life/TopNav";
import ClientList from "@/pages/plan4life/ClientList";
import ClientOverview from "@/pages/plan4life/ClientOverview";
import AddClient from "@/pages/plan4life/AddClient";
import UserManagement from "@/pages/plan4life/UserManagement";
import Login from "@/pages/plan4life/Login";
import PublicRiskProfile from "@/pages/plan4life/PublicRiskProfile";
import AccessDenied from "@/pages/plan4life/AccessDenied";
import { useAuth } from "@/hooks/use-auth";

function AdvisorRoutes() {
  return (
    <Switch>
      <Route path="/" component={() => <Redirect to="/clients" />} />
      <Route path="/clients" component={ClientList} />
      <Route path="/clients/add" component={AddClient} />
      <Route path="/client/:id" component={ClientOverview} />
      <Route path="/admin/users" component={UserManagement} />
      <Route component={NotFound} />
    </Switch>
  );
}

function ClientRoutes({ linkedClientId }: { linkedClientId: string }) {
  return (
    <Switch>
      <Route path={`/client/${linkedClientId}`}>
        {() => <ClientOverview params={{ id: linkedClientId }} />}
      </Route>
      <Route>{() => <Redirect to={`/client/${linkedClientId}`} />}</Route>
    </Switch>
  );
}

function AppContent() {
  const { user, isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-dvh flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          <p className="text-sm text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/risk-profile" component={PublicRiskProfile} />
        <Route component={() => <Redirect to="/login" />} />
      </Switch>
    );
  }

  const role = user?.role;

  if (!role) {
    return <AccessDenied email={user?.email} />;
  }

  if (role === "client") {
    const linkedClientId = user?.linkedClientId;
    if (!linkedClientId) {
      return <AccessDenied email={user?.email} />;
    }
    return (
      <div className="min-h-dvh bg-[radial-gradient(1200px_600px_at_20%_-10%,hsl(var(--primary)/0.18),transparent_55%),radial-gradient(900px_600px_at_110%_10%,hsl(var(--chart-4)/0.14),transparent_55%)]">
        <TopNav user={user} />
        <main>
          <ClientRoutes linkedClientId={linkedClientId} />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-[radial-gradient(1200px_600px_at_20%_-10%,hsl(var(--primary)/0.18),transparent_55%),radial-gradient(900px_600px_at_110%_10%,hsl(var(--chart-4)/0.14),transparent_55%)]">
      <TopNav user={user} />
      <main>
        <AdvisorRoutes />
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <ModeProvider>
          <AppContent />
        </ModeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
